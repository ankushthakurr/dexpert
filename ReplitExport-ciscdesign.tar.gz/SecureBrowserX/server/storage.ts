import { type User, type InsertUser, type SupportTicket, type InsertSupportTicket, type SupportTicketResponse, type InsertSupportTicketResponse, users, supportTickets, supportTicketResponses } from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Support ticket methods
  createSupportTicket(ticket: InsertSupportTicket): Promise<SupportTicket>;
  getSupportTicket(id: string): Promise<SupportTicket | undefined>;
  getSupportTicketByNumber(ticketNumber: string): Promise<SupportTicket | undefined>;
  getSupportTicketsByUser(userId: string): Promise<SupportTicket[]>;
  getAllSupportTickets(): Promise<SupportTicket[]>;
  updateSupportTicketStatus(id: string, status: string): Promise<void>;
  
  // Support ticket response methods
  addSupportTicketResponse(response: InsertSupportTicketResponse): Promise<SupportTicketResponse>;
  getSupportTicketResponses(ticketId: string): Promise<SupportTicketResponse[]>;
}


export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  // Support ticket methods
  async createSupportTicket(ticket: InsertSupportTicket): Promise<SupportTicket> {
    // Generate ticket number
    const ticketNumber = 'MST-' + Date.now().toString().slice(-6) + Math.random().toString(36).substring(2, 5).toUpperCase();
    
    const [createdTicket] = await db
      .insert(supportTickets)
      .values({
        ...ticket,
        ticketNumber,
      })
      .returning();
    return createdTicket;
  }

  async getSupportTicket(id: string): Promise<SupportTicket | undefined> {
    const [ticket] = await db.select().from(supportTickets).where(eq(supportTickets.id, id));
    return ticket || undefined;
  }

  async getSupportTicketByNumber(ticketNumber: string): Promise<SupportTicket | undefined> {
    const [ticket] = await db.select().from(supportTickets).where(eq(supportTickets.ticketNumber, ticketNumber));
    return ticket || undefined;
  }

  async getSupportTicketsByUser(userId: string): Promise<SupportTicket[]> {
    return await db.select().from(supportTickets).where(eq(supportTickets.userId, userId)).orderBy(desc(supportTickets.createdAt));
  }

  async getAllSupportTickets(): Promise<SupportTicket[]> {
    return await db.select().from(supportTickets).orderBy(desc(supportTickets.createdAt));
  }

  async updateSupportTicketStatus(id: string, status: string): Promise<void> {
    await db
      .update(supportTickets)
      .set({ status, updatedAt: new Date() })
      .where(eq(supportTickets.id, id));
  }

  // Support ticket response methods
  async addSupportTicketResponse(response: InsertSupportTicketResponse): Promise<SupportTicketResponse> {
    const [createdResponse] = await db
      .insert(supportTicketResponses)
      .values(response)
      .returning();
    return createdResponse;
  }

  async getSupportTicketResponses(ticketId: string): Promise<SupportTicketResponse[]> {
    return await db
      .select()
      .from(supportTicketResponses)
      .where(eq(supportTicketResponses.ticketId, ticketId))
      .orderBy(supportTicketResponses.createdAt);
  }
}

export const storage = new DatabaseStorage();
