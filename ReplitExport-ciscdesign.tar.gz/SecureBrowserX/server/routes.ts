import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertSupportTicketSchema, insertSupportTicketResponseSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Support ticket routes

  // Create a new support ticket
  app.post("/api/support/tickets", async (req, res) => {
    try {
      const ticketData = insertSupportTicketSchema.parse(req.body);
      const ticket = await storage.createSupportTicket(ticketData);
      res.json(ticket);
    } catch (error) {
      console.error("Error creating support ticket:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid ticket data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to create support ticket" });
    }
  });

  // Get support ticket by ticket number
  app.get("/api/support/tickets/:ticketNumber", async (req, res) => {
    try {
      const ticket = await storage.getSupportTicketByNumber(req.params.ticketNumber);
      if (!ticket) {
        return res.status(404).json({ error: "Ticket not found" });
      }
      
      // Get responses for this ticket
      const responses = await storage.getSupportTicketResponses(ticket.id);
      res.json({ ticket, responses });
    } catch (error) {
      console.error("Error fetching support ticket:", error);
      res.status(500).json({ error: "Failed to fetch support ticket" });
    }
  });

  // Get all support tickets for a user
  app.get("/api/support/tickets/user/:userId", async (req, res) => {
    try {
      const tickets = await storage.getSupportTicketsByUser(req.params.userId);
      res.json(tickets);
    } catch (error) {
      console.error("Error fetching user tickets:", error);
      res.status(500).json({ error: "Failed to fetch user tickets" });
    }
  });

  // Add response to support ticket
  app.post("/api/support/tickets/:ticketId/responses", async (req, res) => {
    try {
      const responseData = insertSupportTicketResponseSchema.parse({
        ...req.body,
        ticketId: req.params.ticketId
      });
      const response = await storage.addSupportTicketResponse(responseData);
      res.json(response);
    } catch (error) {
      console.error("Error adding ticket response:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid response data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to add response" });
    }
  });

  // Update support ticket status
  app.patch("/api/support/tickets/:ticketId/status", async (req, res) => {
    try {
      const { status } = req.body;
      if (!status) {
        return res.status(400).json({ error: "Status is required" });
      }
      
      await storage.updateSupportTicketStatus(req.params.ticketId, status);
      res.json({ success: true });
    } catch (error) {
      console.error("Error updating ticket status:", error);
      res.status(500).json({ error: "Failed to update ticket status" });
    }
  });

  // Get all support tickets (for admin)
  app.get("/api/support/tickets", async (req, res) => {
    try {
      const tickets = await storage.getAllSupportTickets();
      res.json(tickets);
    } catch (error) {
      console.error("Error fetching all tickets:", error);
      res.status(500).json({ error: "Failed to fetch tickets" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
