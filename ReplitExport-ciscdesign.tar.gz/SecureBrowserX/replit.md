# replit.md

## Overview

This is a full-stack web application that mimics the McAfee security software website. It's built as a React frontend with Express backend, styled to look like the original McAfee website with similar color themes and functionality. The application includes features like user authentication, account management, subscription handling, and security update systems. The project appears to be designed as a support-focused security software interface with modal-based interactions for various user scenarios.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack React Query for server state management
- **UI Components**: Radix UI primitives with shadcn/ui component library
- **Styling**: Tailwind CSS with custom McAfee-inspired color scheme and CSS variables
- **Build Tool**: Vite with custom configuration for development and production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Structure**: RESTful API with `/api` prefix routing
- **Storage**: In-memory storage implementation with interface for future database integration
- **Development Server**: Vite middleware integration for seamless development experience

### Database Schema
- **ORM**: Drizzle ORM configured for PostgreSQL
- **Schema Location**: Shared schema definition in `shared/schema.ts`
- **User Model**: Includes authentication fields, subscription status, auto-renewal settings, and activity tracking
- **Migration**: Drizzle Kit for database migrations and schema management

### Authentication & Authorization
- **Session Management**: Designed for cookie-based sessions with PostgreSQL session store
- **User States**: Supports active/inactive users with subscription status tracking
- **Security Features**: Password-based authentication with email verification workflow

### Component Architecture
- **Design System**: shadcn/ui components with custom McAfee theming
- **Modal System**: Comprehensive modal system for user interactions (login, account disabled, auto-renew warnings, update errors)
- **Responsive Design**: Mobile-first approach with adaptive navigation and layouts
- **Custom Hooks**: Utility hooks for mobile detection and toast notifications

### Development Workflow
- **Type Safety**: Full TypeScript coverage across frontend, backend, and shared code
- **Code Organization**: Monorepo structure with clear separation of concerns
- **Development Tools**: Hot module replacement, runtime error overlay, and development banner integration
- **Build Process**: Optimized production builds with static asset handling

## External Dependencies

### Core Technologies
- **Database**: Configured for Neon serverless PostgreSQL
- **UI Framework**: Radix UI for accessible component primitives
- **Styling**: Tailwind CSS for utility-first styling
- **Icons**: Lucide React for consistent iconography

### Development Dependencies
- **Build Tools**: Vite for fast development and optimized builds
- **Database Tools**: Drizzle Kit for schema management and migrations
- **Type System**: Full TypeScript support with strict configuration
- **Code Quality**: ESM modules with modern JavaScript features

### Third-Party Integrations
- **Session Storage**: PostgreSQL-compatible session management
- **Form Handling**: React Hook Form with Zod validation
- **Query Management**: TanStack React Query for efficient data fetching
- **Component Library**: Comprehensive UI component system based on Radix primitives

### Deployment Configuration
- **Production Build**: ESBuild for server bundling with external package handling
- **Static Assets**: Vite-optimized asset bundling and serving
- **Environment**: Environment variable configuration for database connections
- **Server**: Express.js with production-ready middleware and error handling