import { Link } from "wouter";
import { Shield, ShieldQuestion, Wifi, Download, Smartphone, CreditCard, Headphones, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Home() {
  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="gradient-bg text-primary-foreground overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center">
            <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight animate-fade-in" data-testid="text-hero-title">
              Freedom to enjoy<br />
              <span className="text-orange-300 animate-glow">your life online</span>
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-primary-foreground/90 max-w-4xl mx-auto animate-fade-in stagger-animation" style={{ animationDelay: '0.2s' }} data-testid="text-hero-subtitle">
              All-in-one protection to safeguard your privacy and identity with award-winning antivirus so you can enjoy life online.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in stagger-animation" style={{ animationDelay: '0.4s' }}>
              <Button className="mcafee-button-orange animate-scale-hover animate-bounce-soft" data-testid="button-get-protection">
                Get protection now
              </Button>
              <Link href="/update">
                <Button
                  variant="outline"
                  className="bg-white/10 backdrop-blur text-primary-foreground border-2 border-white/30 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-white/20 transition-all duration-300 hover:scale-105 hover:shadow-lg"
                  data-testid="button-update"
                >
                  Update Security
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-foreground mb-4" data-testid="text-features-title">
              Complete Online Protection
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto" data-testid="text-features-subtitle">
              Comprehensive security solutions to keep you safe from all online threats
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <div className="text-center p-8 rounded-xl border border-border hover:shadow-lg transition-shadow" data-testid="card-antivirus">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <Shield className="text-primary" size={32} />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-4">Antivirus Protection</h3>
              <p className="text-muted-foreground">
                Advanced threat detection and real-time protection against malware, viruses, and ransomware.
              </p>
            </div>

            {/* Feature 2 */}
            <div className="text-center p-8 rounded-xl border border-border hover:shadow-lg transition-shadow" data-testid="card-identity">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <ShieldQuestion className="text-primary" size={32} />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-4">Identity Protection</h3>
              <p className="text-muted-foreground">
                Monitor and protect your personal information from identity theft and data breaches.
              </p>
            </div>

            {/* Feature 3 */}
            <div className="text-center p-8 rounded-xl border border-border hover:shadow-lg transition-shadow" data-testid="card-vpn">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <Wifi className="text-primary" size={32} />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-4">Secure VPN</h3>
              <p className="text-muted-foreground">
                Browse anonymously and securely with our encrypted VPN connection worldwide.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Platform Support */}
      <section className="py-20 bg-muted">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-foreground mb-8" data-testid="text-platform-title">
            Works on all your devices
          </h2>
          <div className="flex justify-center items-center space-x-8 flex-wrap gap-6">
            <div className="flex items-center space-x-2 text-muted-foreground" data-testid="platform-windows">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <span className="font-bold text-lg text-primary">W</span>
              </div>
              <span className="font-medium">Windows</span>
            </div>
            <div className="flex items-center space-x-2 text-muted-foreground" data-testid="platform-mac">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <span className="font-bold text-lg text-primary">M</span>
              </div>
              <span className="font-medium">Mac</span>
            </div>
            <div className="flex items-center space-x-2 text-muted-foreground" data-testid="platform-android">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <span className="font-bold text-lg text-primary">A</span>
              </div>
              <span className="font-medium">Android</span>
            </div>
            <div className="flex items-center space-x-2 text-muted-foreground" data-testid="platform-ios">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <Smartphone className="text-primary" size={20} />
              </div>
              <span className="font-medium">iOS</span>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
