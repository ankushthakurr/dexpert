import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertSupportTicketSchema, type InsertSupportTicket, type SupportTicket } from "@shared/schema";
import { z } from "zod";
import { Phone, MessageCircle, Mail, Search, Clock, CheckCircle, AlertTriangle, User } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const contactFormSchema = insertSupportTicketSchema.extend({
  category: z.enum(["technical", "billing", "general"]),
  priority: z.enum(["low", "medium", "high"]).default("medium"),
});

type ContactFormData = z.infer<typeof contactFormSchema>;

export default function Support() {
  const [ticketNumber, setTicketNumber] = useState("");
  const { toast } = useToast();

  const form = useForm<ContactFormData>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      name: "",
      email: "",
      subject: "",
      message: "",
      category: "general",
      priority: "medium",
    },
  });

  // Create support ticket mutation
  const createTicketMutation = useMutation({
    mutationFn: async (data: InsertSupportTicket) => {
      const res = await apiRequest("POST", "/api/support/tickets", data);
      return res.json();
    },
    onSuccess: (ticket: SupportTicket) => {
      toast({
        title: "Support Ticket Created",
        description: `Your ticket ${ticket.ticketNumber} has been created successfully.`,
      });
      form.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/support/tickets"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create support ticket. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Ticket lookup query
  const { data: ticketData, isLoading: ticketLoading } = useQuery({
    queryKey: ["/api/support/tickets", ticketNumber],
    enabled: !!ticketNumber && ticketNumber.length >= 6,
  });

  const onSubmit = (data: ContactFormData) => {
    createTicketMutation.mutate(data);
  };

  const handleTicketLookup = () => {
    if (ticketNumber.trim()) {
      // This will trigger the query through the enabled condition
      return;
    }
    toast({
      title: "Ticket Number Required",
      description: "Please enter a valid ticket number.",
      variant: "destructive",
    });
  };

  const getStatusBadge = (status: string) => {
    const variants = {
      open: "bg-blue-100 text-blue-800",
      "in-progress": "bg-yellow-100 text-yellow-800", 
      resolved: "bg-green-100 text-green-800",
      closed: "bg-gray-100 text-gray-800",
    };
    return variants[status as keyof typeof variants] || variants.open;
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "open":
        return <AlertTriangle size={16} />;
      case "in-progress":
        return <Clock size={16} />;
      case "resolved":
      case "closed":
        return <CheckCircle size={16} />;
      default:
        return <AlertTriangle size={16} />;
    }
  };

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="gradient-bg text-primary-foreground">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6" data-testid="text-support-title">
              How Can We Help You?
            </h1>
            <p className="text-xl text-primary-foreground/90 max-w-3xl mx-auto mb-8" data-testid="text-support-subtitle">
              Get the support you need with our comprehensive help center and expert technical support team.
            </p>
          </div>
        </div>
      </section>

      {/* Quick Contact Options */}
      <section className="py-12 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            <Card className="text-center p-6 border-2 border-border hover:border-primary/50 transition-colors" data-testid="card-phone-support">
              <Phone className="text-primary mx-auto mb-4" size={32} />
              <h3 className="text-lg font-semibold mb-2">Phone Support</h3>
              <p className="text-muted-foreground mb-4">Speak directly with our technical experts</p>
              <p className="font-bold text-primary">1-800-MSUPPORT</p>
              <p className="text-sm text-muted-foreground">24/7 Available</p>
            </Card>

            <Card className="text-center p-6 border-2 border-border hover:border-primary/50 transition-colors" data-testid="card-live-chat">
              <MessageCircle className="text-primary mx-auto mb-4" size={32} />
              <h3 className="text-lg font-semibold mb-2">Live Chat</h3>
              <p className="text-muted-foreground mb-4">Chat with our support team instantly</p>
              <Button className="mcafee-button-primary">Start Chat</Button>
            </Card>

            <Card className="text-center p-6 border-2 border-border hover:border-primary/50 transition-colors" data-testid="card-email-support">
              <Mail className="text-primary mx-auto mb-4" size={32} />
              <h3 className="text-lg font-semibold mb-2">Email Support</h3>
              <p className="text-muted-foreground mb-4">Submit a ticket for detailed assistance</p>
              <p className="font-bold text-primary">support@msupport.com</p>
              <p className="text-sm text-muted-foreground">Response within 24 hours</p>
            </Card>
          </div>
        </div>
      </section>

      {/* Support Tabs */}
      <section className="py-12 bg-muted">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <Tabs defaultValue="contact" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-8">
              <TabsTrigger value="contact" data-testid="tab-contact">Submit a Ticket</TabsTrigger>
              <TabsTrigger value="lookup" data-testid="tab-lookup">Check Ticket Status</TabsTrigger>
            </TabsList>

            {/* Contact Form Tab */}
            <TabsContent value="contact">
              <Card data-testid="card-contact-form">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <User className="text-primary" size={24} />
                    Submit a Support Ticket
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="name"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Full Name</FormLabel>
                              <FormControl>
                                <Input placeholder="Enter your full name" {...field} data-testid="input-name" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="email"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Email Address</FormLabel>
                              <FormControl>
                                <Input type="email" placeholder="Enter your email" {...field} data-testid="input-email-contact" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="category"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Category</FormLabel>
                              <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                  <SelectTrigger data-testid="select-category">
                                    <SelectValue placeholder="Select a category" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="technical">Technical Support</SelectItem>
                                  <SelectItem value="billing">Billing & Account</SelectItem>
                                  <SelectItem value="general">General Inquiry</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="priority"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Priority</FormLabel>
                              <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                  <SelectTrigger data-testid="select-priority">
                                    <SelectValue placeholder="Select priority" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="low">Low</SelectItem>
                                  <SelectItem value="medium">Medium</SelectItem>
                                  <SelectItem value="high">High</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={form.control}
                        name="subject"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Subject</FormLabel>
                            <FormControl>
                              <Input placeholder="Brief description of your issue" {...field} data-testid="input-subject" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="message"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Message</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="Please provide detailed information about your issue..."
                                className="min-h-32"
                                {...field}
                                data-testid="textarea-message"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <Button
                        type="submit"
                        className="w-full mcafee-button-primary"
                        disabled={createTicketMutation.isPending}
                        data-testid="button-submit-ticket"
                      >
                        {createTicketMutation.isPending ? "Submitting..." : "Submit Support Ticket"}
                      </Button>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Ticket Lookup Tab */}
            <TabsContent value="lookup">
              <Card data-testid="card-ticket-lookup">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Search className="text-primary" size={24} />
                    Check Ticket Status
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex gap-2">
                    <Input
                      placeholder="Enter your ticket number (e.g., MST-123456)"
                      value={ticketNumber}
                      onChange={(e) => setTicketNumber(e.target.value)}
                      className="flex-1"
                      data-testid="input-ticket-number"
                    />
                    <Button
                      onClick={handleTicketLookup}
                      disabled={ticketLoading}
                      data-testid="button-lookup-ticket"
                    >
                      {ticketLoading ? "Searching..." : "Search"}
                    </Button>
                  </div>

                  {ticketData && (ticketData as any).ticket && (
                    <Card className="border-2 border-primary/20" data-testid="card-ticket-details">
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-lg">Ticket #{(ticketData as any).ticket.ticketNumber}</CardTitle>
                          <Badge className={getStatusBadge((ticketData as any).ticket.status)}>
                            <span className="flex items-center gap-1">
                              {getStatusIcon((ticketData as any).ticket.status)}
                              {(ticketData as any).ticket.status.charAt(0).toUpperCase() + (ticketData as any).ticket.status.slice(1).replace('-', ' ')}
                            </span>
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div>
                          <h4 className="font-medium mb-1">Subject</h4>
                          <p className="text-muted-foreground" data-testid="text-ticket-subject">{(ticketData as any).ticket.subject}</p>
                        </div>
                        <div>
                          <h4 className="font-medium mb-1">Category</h4>
                          <Badge variant="outline" className="capitalize" data-testid="badge-ticket-category">
                            {(ticketData as any).ticket.category}
                          </Badge>
                        </div>
                        <div>
                          <h4 className="font-medium mb-1">Created</h4>
                          <p className="text-muted-foreground" data-testid="text-ticket-date">
                            {new Date((ticketData as any).ticket.createdAt!).toLocaleDateString()}
                          </p>
                        </div>
                        <div>
                          <h4 className="font-medium mb-1">Message</h4>
                          <p className="text-muted-foreground text-sm bg-muted p-3 rounded-lg" data-testid="text-ticket-message">
                            {(ticketData as any).ticket.message}
                          </p>
                        </div>

                        {(ticketData as any).responses && (ticketData as any).responses.length > 0 && (
                          <div>
                            <h4 className="font-medium mb-2">Responses</h4>
                            <div className="space-y-2" data-testid="list-ticket-responses">
                              {(ticketData as any).responses.map((response: any) => (
                                <div
                                  key={response.id}
                                  className={`p-3 rounded-lg text-sm ${
                                    response.isStaffResponse 
                                      ? 'bg-blue-50 border-l-4 border-blue-500' 
                                      : 'bg-gray-50 border-l-4 border-gray-300'
                                  }`}
                                >
                                  <div className="flex items-center gap-2 mb-1">
                                    <Badge variant={response.isStaffResponse ? "default" : "secondary"} className="text-xs">
                                      {response.isStaffResponse ? "Support Team" : "You"}
                                    </Badge>
                                    <span className="text-xs text-muted-foreground">
                                      {new Date(response.createdAt).toLocaleDateString()}
                                    </span>
                                  </div>
                                  <p>{response.message}</p>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  )}

                  {ticketNumber && ticketNumber.length >= 6 && !ticketLoading && !(ticketData as any)?.ticket && (
                    <Card className="border-2 border-destructive/20" data-testid="card-ticket-not-found">
                      <CardContent className="p-6 text-center">
                        <AlertTriangle className="text-destructive mx-auto mb-2" size={32} />
                        <p className="text-destructive font-medium">Ticket not found</p>
                        <p className="text-muted-foreground text-sm">
                          Please check your ticket number and try again.
                        </p>
                      </CardContent>
                    </Card>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-background">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4" data-testid="text-faq-title">
              Frequently Asked Questions
            </h2>
            <p className="text-xl text-muted-foreground">
              Quick answers to common questions
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[
              {
                question: "How do I download and install MSupport?",
                answer: "Visit your account dashboard and click 'Download Software' to get the latest installer for your operating system."
              },
              {
                question: "What should I do if my subscription expires?",
                answer: "Contact our billing support immediately to renew your subscription and maintain continuous protection."
              },
              {
                question: "How do I update my payment information?",
                answer: "Log into your account and go to the 'Update Payment' section to change your billing details securely."
              },
              {
                question: "Is 24/7 technical support included?",
                answer: "Yes, all MSupport customers receive 24/7 technical support via phone, chat, and email for any security-related issues."
              }
            ].map((faq, index) => (
              <Card key={index} className="hover:shadow-md transition-shadow" data-testid={`card-faq-${index}`}>
                <CardHeader>
                  <CardTitle className="text-lg">{faq.question}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{faq.answer}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}