import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { AlertTriangle, RefreshCw } from "lucide-react";
import { useLocation } from "wouter";
import UpdateErrorModal from "@/components/modals/update-error-modal";

export default function Update() {
  const [, navigate] = useLocation();
  const [isUpdating, setIsUpdating] = useState(false);
  const [progress, setProgress] = useState(0);
  const [showError, setShowError] = useState(false);

  const startUpdate = () => {
    setIsUpdating(true);
    setProgress(0);
    setShowError(false);

    // Simulate update progress
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 30) {
          clearInterval(interval);
          setTimeout(() => {
            setIsUpdating(false);
            setShowError(true);
          }, 1000);
          return prev;
        }
        return prev + Math.random() * 5;
      });
    }, 200);
  };

  return (
    <div className="pt-16 min-h-screen bg-background">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-4" data-testid="text-update-title">
            Security Update Center
          </h1>
          <p className="text-xl text-muted-foreground" data-testid="text-update-subtitle">
            Keep your protection up to date with the latest security definitions
          </p>
        </div>

        <Card className="max-w-2xl mx-auto" data-testid="card-update">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <RefreshCw className="text-primary" size={24} />
              Update Security Software
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {!isUpdating && !showError && (
              <>
                <div className="text-center space-y-4">
                  <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
                    <RefreshCw className="text-primary" size={32} />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-foreground mb-2">
                      Update Available
                    </h3>
                    <p className="text-muted-foreground" data-testid="text-update-description">
                      A new security update is available to enhance your protection against the latest threats.
                      Click below to start the update process.
                    </p>
                  </div>
                </div>
                <Button
                  onClick={startUpdate}
                  className="w-full mcafee-button-primary"
                  data-testid="button-start-update"
                >
                  Start Update
                </Button>
              </>
            )}

            {isUpdating && (
              <div className="space-y-4" data-testid="card-updating">
                <div className="text-center">
                  <h3 className="text-lg font-semibold text-foreground mb-2">
                    Updating Security Software...
                  </h3>
                  <p className="text-muted-foreground" data-testid="text-updating-description">
                    Please wait while we download and install the latest security updates.
                  </p>
                </div>
                <div className="space-y-2">
                  <Progress value={progress} className="w-full" data-testid="progress-update" />
                  <p className="text-sm text-muted-foreground text-center" data-testid="text-progress">
                    {Math.round(progress)}% Complete
                  </p>
                </div>
                <div className="bg-muted p-4 rounded-lg">
                  <p className="text-sm text-muted-foreground" data-testid="text-update-status">
                    {progress < 10 && "Initializing update process..."}
                    {progress >= 10 && progress < 20 && "Downloading security definitions..."}
                    {progress >= 20 && progress < 30 && "Verifying update integrity..."}
                    {progress >= 30 && "Finalizing update..."}
                  </p>
                </div>
              </div>
            )}

            {showError && (
              <div className="text-center space-y-4" data-testid="card-error">
                <div className="w-16 h-16 bg-destructive/10 rounded-full flex items-center justify-center mx-auto">
                  <AlertTriangle className="text-destructive" size={32} />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-destructive mb-2">
                    Update Failed
                  </h3>
                  <p className="text-muted-foreground" data-testid="text-error-description">
                    The update process has encountered an error. Your current protection may be outdated.
                  </p>
                </div>
                <div className="space-y-2">
                  <Button
                    onClick={() => setShowError(false)}
                    variant="outline"
                    className="w-full"
                    data-testid="button-try-again"
                  >
                    Try Again
                  </Button>
                  <Button
                    onClick={() => navigate("/")}
                    variant="outline"
                    className="w-full"
                    data-testid="button-back-home"
                  >
                    Back to Home
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <UpdateErrorModal open={showError} onOpenChange={setShowError} />
    </div>
  );
}
