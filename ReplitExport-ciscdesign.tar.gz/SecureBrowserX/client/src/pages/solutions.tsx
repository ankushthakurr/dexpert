import { Building2, Users, Shield, Laptop, Server, Globe } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function Solutions() {
  const businessSolutions = [
    {
      icon: Building2,
      title: "Enterprise Security",
      description: "Complete endpoint protection for large organizations with centralized management and advanced threat detection.",
      features: ["Centralized Management", "Advanced Threat Detection", "Compliance Reporting", "24/7 SOC Support"],
      color: "text-blue-600",
      bgColor: "bg-blue-50"
    },
    {
      icon: Users,
      title: "Small Business Protection", 
      description: "Affordable security solutions designed for small and medium businesses with easy deployment.",
      features: ["Easy Deployment", "Multi-device Support", "Email Security", "Web Protection"],
      color: "text-green-600",
      bgColor: "bg-green-50"
    },
    {
      icon: Server,
      title: "Server Security",
      description: "Dedicated server protection with real-time monitoring and automated response capabilities.",
      features: ["Real-time Monitoring", "Automated Response", "Server Hardening", "Vulnerability Scanning"],
      color: "text-purple-600",
      bgColor: "bg-purple-50"
    }
  ];

  const consumerSolutions = [
    {
      icon: Laptop,
      title: "Home Office Security",
      description: "Comprehensive protection for remote workers and home offices with VPN and identity protection.",
      features: ["VPN Protection", "Identity Monitoring", "Secure File Storage", "Parental Controls"],
      color: "text-orange-600",
      bgColor: "bg-orange-50"
    },
    {
      icon: Shield,
      title: "Family Protection",
      description: "Keep your entire family safe online with parental controls and device management features.",
      features: ["Parental Controls", "Device Management", "Safe Browsing", "Screen Time Limits"],
      color: "text-red-600", 
      bgColor: "bg-red-50"
    },
    {
      icon: Globe,
      title: "Mobile Security",
      description: "Advanced mobile protection for smartphones and tablets with anti-theft and privacy features.",
      features: ["Anti-theft Protection", "App Privacy Scanner", "Wi-Fi Security", "Battery Optimizer"],
      color: "text-indigo-600",
      bgColor: "bg-indigo-50"
    }
  ];

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="gradient-bg text-primary-foreground">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6" data-testid="text-solutions-title">
              Security Solutions for Every Need
            </h1>
            <p className="text-xl text-primary-foreground/90 max-w-3xl mx-auto mb-8" data-testid="text-solutions-subtitle">
              From individual users to enterprise organizations, we provide tailored security solutions 
              that protect what matters most to you.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button className="mcafee-button-orange" data-testid="button-contact-sales">
                Contact Sales
              </Button>
              <Button
                variant="outline" 
                className="bg-white/10 backdrop-blur text-primary-foreground border-2 border-white/30 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-white/20 transition-colors"
                data-testid="button-free-trial"
              >
                Start Free Trial
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Business Solutions */}
      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <Badge className="mb-4 bg-blue-100 text-blue-800">For Business</Badge>
            <h2 className="text-4xl font-bold text-foreground mb-4" data-testid="text-business-title">
              Enterprise & Business Solutions
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="text-business-subtitle">
              Scalable security solutions designed to protect your business operations and sensitive data
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {businessSolutions.map((solution, index) => {
              const IconComponent = solution.icon;
              return (
                <Card 
                  key={index} 
                  className="border-2 border-border hover:border-primary/50 hover:shadow-lg transition-all duration-300"
                  data-testid={`card-business-${index}`}
                >
                  <CardHeader>
                    <div className={`w-16 h-16 ${solution.bgColor} rounded-full flex items-center justify-center mb-4`}>
                      <IconComponent className={solution.color} size={32} />
                    </div>
                    <CardTitle className="text-xl font-bold">{solution.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-muted-foreground">{solution.description}</p>
                    <ul className="space-y-2">
                      {solution.features.map((feature, featureIndex) => (
                        <li key={featureIndex} className="flex items-center space-x-2 text-sm">
                          <div className="w-2 h-2 bg-primary rounded-full"></div>
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                    <Button 
                      variant="outline" 
                      className="w-full"
                      data-testid={`button-learn-more-business-${index}`}
                    >
                      Learn More
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Consumer Solutions */}
      <section className="py-20 bg-muted">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <Badge className="mb-4 bg-green-100 text-green-800">For Consumers</Badge>
            <h2 className="text-4xl font-bold text-foreground mb-4" data-testid="text-consumer-title">
              Personal & Family Solutions
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="text-consumer-subtitle">
              Comprehensive protection for individuals and families in the digital age
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {consumerSolutions.map((solution, index) => {
              const IconComponent = solution.icon;
              return (
                <Card 
                  key={index} 
                  className="border-2 border-border hover:border-primary/50 hover:shadow-lg transition-all duration-300"
                  data-testid={`card-consumer-${index}`}
                >
                  <CardHeader>
                    <div className={`w-16 h-16 ${solution.bgColor} rounded-full flex items-center justify-center mb-4`}>
                      <IconComponent className={solution.color} size={32} />
                    </div>
                    <CardTitle className="text-xl font-bold">{solution.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-muted-foreground">{solution.description}</p>
                    <ul className="space-y-2">
                      {solution.features.map((feature, featureIndex) => (
                        <li key={featureIndex} className="flex items-center space-x-2 text-sm">
                          <div className="w-2 h-2 bg-primary rounded-full"></div>
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                    <Button 
                      variant="outline" 
                      className="w-full"
                      data-testid={`button-learn-more-consumer-${index}`}
                    >
                      Learn More
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Industry Focus */}
      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-foreground mb-4" data-testid="text-industries-title">
              Specialized Industry Solutions
            </h2>
            <p className="text-xl text-muted-foreground">
              Tailored security for specific industry requirements
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { name: "Healthcare", desc: "HIPAA compliance and patient data protection" },
              { name: "Finance", desc: "Banking-grade security and fraud prevention" },
              { name: "Education", desc: "Student data protection and network security" },
              { name: "Government", desc: "High-security solutions for public sector" }
            ].map((industry, index) => (
              <Card key={index} className="text-center p-6 hover:shadow-lg transition-shadow" data-testid={`card-industry-${index}`}>
                <h3 className="font-semibold text-lg mb-2">{industry.name}</h3>
                <p className="text-sm text-muted-foreground mb-4">{industry.desc}</p>
                <Button variant="outline" size="sm">
                  Explore Solutions
                </Button>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 gradient-bg text-primary-foreground">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4" data-testid="text-cta-title">
            Ready to Secure Your Organization?
          </h2>
          <p className="text-xl text-primary-foreground/90 mb-8">
            Contact our security experts to find the perfect solution for your needs
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button className="mcafee-button-orange" data-testid="button-get-quote">
              Get Custom Quote
            </Button>
            <Button 
              variant="outline"
              className="bg-white/10 backdrop-blur text-primary-foreground border-2 border-white/30 hover:bg-white/20"
              data-testid="button-schedule-demo"
            >
              Schedule Demo
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}