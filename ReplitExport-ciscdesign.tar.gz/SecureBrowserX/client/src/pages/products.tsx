import { Link } from "wouter";
import { Shield, ShieldQuestion, Wifi, Download, Check, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function Products() {
  const products = [
    {
      id: "antivirus",
      name: "MSupport Antivirus",
      subtitle: "Essential Protection",
      price: "$39.99/year",
      originalPrice: "$59.99",
      icon: Shield,
      color: "text-blue-600",
      bgColor: "bg-blue-50",
      features: [
        "Real-time antivirus protection",
        "Malware and ransomware defense",
        "Web protection and safe browsing",
        "Email security",
        "Automatic updates"
      ],
      devices: "Protect 1 device"
    },
    {
      id: "total-protection", 
      name: "MSupport Total Protection",
      subtitle: "Complete Security Suite",
      price: "$99.99/year",
      originalPrice: "$149.99",
      icon: ShieldQuestion,
      color: "text-green-600",
      bgColor: "bg-green-50",
      popular: true,
      features: [
        "All Antivirus features",
        "Identity theft protection",
        "Password manager",
        "Encrypted file storage", 
        "VPN with unlimited data",
        "PC optimization tools",
        "24/7 customer support"
      ],
      devices: "Protect unlimited devices"
    },
    {
      id: "vpn-plus",
      name: "MSupport VPN Plus",
      subtitle: "Privacy & Anonymity",
      price: "$79.99/year",
      originalPrice: "$99.99",
      icon: Wifi,
      color: "text-purple-600",
      bgColor: "bg-purple-50",
      features: [
        "Unlimited VPN access",
        "Access to 50+ countries",
        "No-logs policy",
        "Kill switch protection",
        "5 simultaneous connections",
        "24/7 customer support"
      ],
      devices: "5 devices simultaneously"
    }
  ];

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="gradient-bg text-primary-foreground">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6" data-testid="text-products-title">
              Choose Your Protection Plan
            </h1>
            <p className="text-xl text-primary-foreground/90 max-w-3xl mx-auto mb-8" data-testid="text-products-subtitle">
              Comprehensive security solutions designed to keep you safe from all online threats. 
              Choose the plan that fits your needs.
            </p>
          </div>
        </div>
      </section>

      {/* Products Grid */}
      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {products.map((product) => {
              const IconComponent = product.icon;
              return (
                <Card 
                  key={product.id} 
                  className={`relative border-2 hover:shadow-xl transition-all duration-300 ${
                    product.popular ? 'border-primary scale-105' : 'border-border hover:border-primary/50'
                  }`}
                  data-testid={`card-product-${product.id}`}
                >
                  {product.popular && (
                    <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                      <Badge className="bg-primary text-primary-foreground px-4 py-1 text-sm font-semibold">
                        Most Popular
                      </Badge>
                    </div>
                  )}
                  
                  <CardHeader className="text-center pb-4">
                    <div className={`w-16 h-16 ${product.bgColor} rounded-full flex items-center justify-center mx-auto mb-4`}>
                      <IconComponent className={product.color} size={32} />
                    </div>
                    <CardTitle className="text-2xl font-bold">{product.name}</CardTitle>
                    <p className="text-muted-foreground">{product.subtitle}</p>
                  </CardHeader>

                  <CardContent className="space-y-6">
                    {/* Pricing */}
                    <div className="text-center">
                      <div className="flex items-center justify-center space-x-2 mb-2">
                        <span className="text-3xl font-bold text-foreground" data-testid={`text-price-${product.id}`}>
                          {product.price}
                        </span>
                        <span className="text-lg text-muted-foreground line-through">
                          {product.originalPrice}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground" data-testid={`text-devices-${product.id}`}>
                        {product.devices}
                      </p>
                    </div>

                    {/* Features */}
                    <ul className="space-y-3">
                      {product.features.map((feature, index) => (
                        <li key={index} className="flex items-start space-x-3">
                          <Check className="text-green-600 flex-shrink-0 mt-0.5" size={16} />
                          <span className="text-sm text-muted-foreground">{feature}</span>
                        </li>
                      ))}
                    </ul>

                    {/* CTA Button */}
                    <Button 
                      className={`w-full ${
                        product.popular 
                          ? 'mcafee-button-orange' 
                          : 'mcafee-button-primary'
                      }`}
                      data-testid={`button-get-${product.id}`}
                    >
                      Get Protected Now
                    </Button>

                    <p className="text-xs text-center text-muted-foreground">
                      30-day money-back guarantee
                    </p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Feature Comparison */}
      <section className="py-20 bg-muted">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4" data-testid="text-comparison-title">
              Compare All Features
            </h2>
            <p className="text-xl text-muted-foreground">
              See what's included with each protection plan
            </p>
          </div>

          <div className="bg-card rounded-xl shadow-lg overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-muted">
                  <tr>
                    <th className="text-left p-4 font-semibold">Features</th>
                    <th className="text-center p-4 font-semibold">Antivirus</th>
                    <th className="text-center p-4 font-semibold bg-primary/10">Total Protection</th>
                    <th className="text-center p-4 font-semibold">VPN Plus</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    ["Antivirus Protection", true, true, false],
                    ["Real-time Scanning", true, true, false],
                    ["Web Protection", true, true, false], 
                    ["Identity Protection", false, true, false],
                    ["Password Manager", false, true, false],
                    ["VPN Access", false, true, true],
                    ["File Encryption", false, true, false],
                    ["PC Optimization", false, true, false],
                    ["24/7 Support", false, true, true]
                  ].map(([feature, basic, total, vpn], index) => (
                    <tr key={index} className="border-t border-border">
                      <td className="p-4 font-medium">{feature as string}</td>
                      <td className="p-4 text-center">
                        {basic ? <Check className="text-green-600 mx-auto" size={20} /> : "—"}
                      </td>
                      <td className="p-4 text-center bg-primary/5">
                        {total ? <Check className="text-green-600 mx-auto" size={20} /> : "—"}
                      </td>
                      <td className="p-4 text-center">
                        {vpn ? <Check className="text-green-600 mx-auto" size={20} /> : "—"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>

      {/* Trust Indicators */}
      <section className="py-16 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl font-bold text-foreground mb-8" data-testid="text-trust-title">
            Trusted by millions worldwide
          </h2>
          <div className="flex justify-center items-center space-x-8 flex-wrap gap-6">
            <div className="flex items-center space-x-2" data-testid="trust-rating">
              <div className="flex space-x-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star key={star} className="text-yellow-400 fill-current" size={20} />
                ))}
              </div>
              <span className="font-medium text-muted-foreground">4.8/5 Rating</span>
            </div>
            <div className="text-muted-foreground" data-testid="trust-users">
              <span className="font-bold text-2xl text-primary">500M+</span>
              <span className="ml-2">Protected Users</span>
            </div>
            <div className="text-muted-foreground" data-testid="trust-awards">
              <span className="font-bold text-2xl text-primary">40+</span>
              <span className="ml-2">Security Awards</span>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}