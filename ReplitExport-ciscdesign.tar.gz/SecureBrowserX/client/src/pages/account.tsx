import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Download, Smartphone, CreditCard, Headphones, CheckCircle, History, Shield, Monitor, Trash2, Edit3, Plus } from "lucide-react";
import AutoRenewModal from "@/components/modals/auto-renew-modal";

export default function Account() {
  const [autoRenew, setAutoRenew] = useState(true);
  const [showAutoRenewModal, setShowAutoRenewModal] = useState(false);

  const handleAutoRenewToggle = (checked: boolean) => {
    if (!checked) {
      setShowAutoRenewModal(true);
    } else {
      setAutoRenew(checked);
    }
  };

  return (
    <div className="pt-16 min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-2" data-testid="text-account-title">
            My Account
          </h1>
          <p className="text-muted-foreground" data-testid="text-account-subtitle">
            Manage your subscription and account settings
          </p>
        </div>

        {/* Account Overview */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Subscription Details */}
          <div className="lg:col-span-2">
            <Card data-testid="card-subscription">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-2xl">Active Subscription</CardTitle>
                  <Badge className="bg-green-100 text-green-800" data-testid="badge-active">
                    Active
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex justify-between items-center py-4 border-b border-border">
                  <div>
                    <h3 className="font-semibold text-card-foreground" data-testid="text-subscription-name">
                      MSupport Total Protection
                    </h3>
                    <p className="text-muted-foreground text-sm" data-testid="text-subscription-description">
                      Complete antivirus and identity protection
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-card-foreground" data-testid="text-subscription-price">
                      $99.99/year
                    </p>
                    <p className="text-muted-foreground text-sm" data-testid="text-subscription-devices">
                      Unlimited devices
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="text-sm font-medium text-card-foreground">
                      Subscription Start Date
                    </label>
                    <p className="text-muted-foreground" data-testid="text-start-date">
                      January 15, 2024
                    </p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-card-foreground">
                      Next Billing Date
                    </label>
                    <p className="text-muted-foreground" data-testid="text-billing-date">
                      January 15, 2025
                    </p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-card-foreground">
                      Payment Method
                    </label>
                    <p className="text-muted-foreground" data-testid="text-payment-method">
                      •••• •••• •••• 4532
                    </p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-card-foreground">
                      Devices Protected
                    </label>
                    <p className="text-muted-foreground" data-testid="text-devices-protected">
                      5 of unlimited
                    </p>
                  </div>
                </div>

                {/* Auto-Renewal Toggle */}
                <div className="flex items-center justify-between p-4 bg-muted rounded-lg" data-testid="card-auto-renewal">
                  <div>
                    <h4 className="font-medium text-card-foreground">Auto-Renewal</h4>
                    <p className="text-sm text-muted-foreground">
                      Automatically renew your subscription
                    </p>
                  </div>
                  <Switch
                    checked={autoRenew}
                    onCheckedChange={handleAutoRenewToggle}
                    data-testid="switch-auto-renewal"
                  />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Quick Actions */}
          <div className="space-y-6">
            <Card data-testid="card-quick-actions">
              <CardHeader>
                <CardTitle className="text-lg">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  data-testid="button-download-software"
                >
                  <Download className="mr-3 text-primary" size={16} />
                  Download Software
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  data-testid="button-manage-devices"
                >
                  <Smartphone className="mr-3 text-primary" size={16} />
                  Manage Devices
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  data-testid="button-update-payment"
                >
                  <CreditCard className="mr-3 text-primary" size={16} />
                  Update Payment
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  data-testid="button-contact-support"
                >
                  <Headphones className="mr-3 text-primary" size={16} />
                  Contact Support
                </Button>
              </CardContent>
            </Card>

            {/* Protection Status */}
            <Card data-testid="card-protection-status">
              <CardHeader>
                <CardTitle className="text-lg">Protection Status</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-card-foreground">Real-time Scanning</span>
                  <span className="text-green-600 text-sm font-medium flex items-center">
                    <CheckCircle size={16} className="mr-1" />
                    Active
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-card-foreground">Firewall</span>
                  <span className="text-green-600 text-sm font-medium flex items-center">
                    <CheckCircle size={16} className="mr-1" />
                    Enabled
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-card-foreground">VPN</span>
                  <span className="text-green-600 text-sm font-medium flex items-center">
                    <CheckCircle size={16} className="mr-1" />
                    Connected
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-card-foreground">Last Scan</span>
                  <span className="text-muted-foreground text-sm" data-testid="text-last-scan">
                    2 hours ago
                  </span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Payment History Section */}
        <div className="mt-12">
          <Card data-testid="card-payment-history">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <History className="text-primary" size={24} />
                Payment History
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { date: "2024-01-15", amount: "$99.99", method: "•••• 4532", status: "Paid", invoice: "INV-2024-001" },
                  { date: "2023-01-15", amount: "$99.99", method: "•••• 4532", status: "Paid", invoice: "INV-2023-001" },
                  { date: "2022-01-15", amount: "$79.99", method: "•••• 4532", status: "Paid", invoice: "INV-2022-001" },
                ].map((payment, index) => (
                  <div key={index} className="flex items-center justify-between py-3 border-b border-border last:border-b-0" data-testid={`payment-${index}`}>
                    <div className="flex-1">
                      <div className="flex items-center gap-4">
                        <div>
                          <p className="font-medium text-card-foreground">{payment.date}</p>
                          <p className="text-sm text-muted-foreground">{payment.method}</p>
                        </div>
                        <Badge className="bg-green-100 text-green-800">{payment.status}</Badge>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-card-foreground">{payment.amount}</p>
                      <Button variant="link" size="sm" className="text-primary p-0 h-auto">
                        Download Invoice
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Device Management Section */}
        <div className="mt-8">
          <Card data-testid="card-device-management">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Monitor className="text-primary" size={24} />
                  Device Management
                </CardTitle>
                <Button variant="outline" size="sm" data-testid="button-add-device">
                  <Plus size={16} className="mr-2" />
                  Add Device
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { name: "MacBook Pro", type: "macOS", status: "Protected", lastSeen: "2 hours ago", version: "v10.8.2" },
                  { name: "iPhone 15", type: "iOS", status: "Protected", lastSeen: "1 hour ago", version: "v10.8.1" },
                  { name: "Work Laptop", type: "Windows", status: "Protected", lastSeen: "5 hours ago", version: "v10.8.2" },
                  { name: "iPad Air", type: "iOS", status: "Offline", lastSeen: "3 days ago", version: "v10.7.9" },
                  { name: "Gaming PC", type: "Windows", status: "Protected", lastSeen: "12 hours ago", version: "v10.8.2" },
                ].map((device, index) => (
                  <div key={index} className="flex items-center justify-between py-3 border-b border-border last:border-b-0" data-testid={`device-${index}`}>
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                        {device.type === "macOS" && <span className="font-bold text-primary text-lg">M</span>}
                        {device.type === "iOS" && <Smartphone className="text-primary" size={20} />}
                        {device.type === "Windows" && <Monitor className="text-primary" size={20} />}
                      </div>
                      <div>
                        <p className="font-medium text-card-foreground">{device.name}</p>
                        <p className="text-sm text-muted-foreground">{device.type} • {device.version}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="text-right">
                        <Badge className={device.status === "Protected" ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"}>
                          {device.status}
                        </Badge>
                        <p className="text-sm text-muted-foreground mt-1">Last seen: {device.lastSeen}</p>
                      </div>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="sm" data-testid={`button-edit-device-${index}`}>
                          <Edit3 size={16} />
                        </Button>
                        <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive" data-testid={`button-remove-device-${index}`}>
                          <Trash2 size={16} />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Subscription Upgrade Options */}
        <div className="mt-8">
          <Card data-testid="card-upgrade-options">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="text-primary" size={24} />
                Upgrade Your Protection
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card className="border-2 border-orange-200 bg-orange-50">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">Premium Plus</CardTitle>
                      <Badge className="bg-orange-100 text-orange-800">Recommended</Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-baseline gap-2">
                      <span className="text-2xl font-bold">$149.99</span>
                      <span className="text-muted-foreground">/year</span>
                    </div>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-center gap-2">
                        <CheckCircle size={16} className="text-green-600" />
                        All Total Protection features
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle size={16} className="text-green-600" />
                        Priority 24/7 phone support
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle size={16} className="text-green-600" />
                        Advanced identity monitoring
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle size={16} className="text-green-600" />
                        $1M identity theft insurance
                      </li>
                    </ul>
                    <Button className="w-full mcafee-button-orange" data-testid="button-upgrade-premium">
                      Upgrade Now
                    </Button>
                  </CardContent>
                </Card>

                <Card className="border-2 border-border">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg">Business Security</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-baseline gap-2">
                      <span className="text-2xl font-bold">$199.99</span>
                      <span className="text-muted-foreground">/year</span>
                    </div>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-center gap-2">
                        <CheckCircle size={16} className="text-green-600" />
                        All Premium Plus features
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle size={16} className="text-green-600" />
                        Centralized admin console
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle size={16} className="text-green-600" />
                        Advanced threat intelligence
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle size={16} className="text-green-600" />
                        Compliance reporting
                      </li>
                    </ul>
                    <Button variant="outline" className="w-full" data-testid="button-upgrade-business">
                      Learn More
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <AutoRenewModal
        open={showAutoRenewModal}
        onOpenChange={setShowAutoRenewModal}
        onConfirm={() => setShowAutoRenewModal(false)}
      />
    </div>
  );
}
