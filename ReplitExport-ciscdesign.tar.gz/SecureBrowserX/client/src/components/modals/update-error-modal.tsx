import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { AlertTriangle, Phone, MessageCircle, Shield } from "lucide-react";

interface UpdateErrorModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function UpdateErrorModal({
  open,
  onOpenChange,
}: UpdateErrorModalProps) {
  const handleCallSupport = () => {
    alert("Calling tech support for update assistance...");
  };

  const handleChatSupport = () => {
    alert("Opening chat with tech support...");
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md" data-testid="modal-update-error">
        <div className="text-center space-y-6">
          <div className="w-16 h-16 bg-destructive/10 rounded-full flex items-center justify-center mx-auto">
            <Shield className="text-destructive" size={32} />
          </div>
          
          <div>
            <h2 className="text-2xl font-bold text-destructive mb-4" data-testid="text-error-title">
              ⚠️ Security Alert
            </h2>
            <p className="text-muted-foreground mb-4" data-testid="text-error-message">
              Your security is outdated! You need to get the new version of security software.
            </p>
            <p className="text-sm text-muted-foreground" data-testid="text-error-help">
              Call the tech support team and they will help you install the new version.
            </p>
          </div>
          
          <div className="space-y-3">
            <Button
              onClick={handleCallSupport}
              className="w-full mcafee-button-red flex items-center justify-center gap-2"
              data-testid="button-call-tech-error"
            >
              <Phone size={16} />
              Call Tech Support
            </Button>
            <Button
              onClick={handleChatSupport}
              variant="outline"
              className="w-full flex items-center justify-center gap-2 border-destructive text-destructive hover:bg-destructive hover:text-white"
              data-testid="button-chat-tech-error"
            >
              <MessageCircle size={16} />
              Chat With Tech
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
