import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { AlertTriangle, Phone } from "lucide-react";

interface AccountDisabledModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function AccountDisabledModal({
  open,
  onOpenChange,
}: AccountDisabledModalProps) {
  const handleCallSupport = () => {
    // In a real app, this would open the phone dialer
    alert("Calling 1-800-MSUPPORT...");
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md" data-testid="modal-account-disabled">
        <div className="text-center space-y-6">
          <div className="w-16 h-16 bg-destructive/10 rounded-full flex items-center justify-center mx-auto">
            <AlertTriangle className="text-destructive" size={32} />
          </div>
          
          <div>
            <h2 className="text-2xl font-bold text-card-foreground mb-4" data-testid="text-modal-title">
              Account Disabled
            </h2>
            <p className="text-muted-foreground mb-2" data-testid="text-modal-message">
              Your Account is Disabled because of not logging in.
            </p>
            <p className="text-muted-foreground mb-2" data-testid="text-subscription-info">
              Your subscription is active and tomorrow it will renew.
            </p>
            <p className="text-muted-foreground" data-testid="text-payment-update">
              Please update your payment card.
            </p>
          </div>
          
          <div className="space-y-3">
            <Button
              onClick={handleCallSupport}
              className="w-full mcafee-button-primary flex items-center justify-center gap-2"
              data-testid="button-call-support"
            >
              <Phone size={16} />
              Call Support: 1-800-MSUPPORT
            </Button>
            <Button
              onClick={() => onOpenChange(false)}
              variant="outline"
              className="w-full"
              data-testid="button-close"
            >
              Close
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
