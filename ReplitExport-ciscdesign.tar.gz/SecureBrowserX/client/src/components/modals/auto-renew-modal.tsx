import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { AlertTriangle, Phone, MessageCircle } from "lucide-react";

interface AutoRenewModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onConfirm: () => void;
}

export default function AutoRenewModal({
  open,
  onOpenChange,
  onConfirm,
}: AutoRenewModalProps) {
  const handleCallSupport = () => {
    alert("Calling tech support...");
  };

  const handleChatSupport = () => {
    alert("Opening chat with tech support...");
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md" data-testid="modal-auto-renew">
        <div className="text-center space-y-6">
          <div className="w-16 h-16 bg-destructive/10 rounded-full flex items-center justify-center mx-auto">
            <AlertTriangle className="text-destructive" size={32} />
          </div>
          
          <div>
            <h2 className="text-2xl font-bold text-card-foreground mb-4" data-testid="text-modal-title">
              Cannot Disable Auto-Renewal
            </h2>
            <p className="text-muted-foreground mb-4" data-testid="text-modal-message">
              Can't disable it. It's already due - you need to pay the bill for this month's subscription.
            </p>
          </div>
          
          <div className="space-y-3">
            <Button
              onClick={handleCallSupport}
              className="w-full mcafee-button-primary flex items-center justify-center gap-2"
              data-testid="button-call-tech"
            >
              <Phone size={16} />
              Call Tech For Help
            </Button>
            <Button
              onClick={handleChatSupport}
              variant="outline"
              className="w-full flex items-center justify-center gap-2"
              data-testid="button-chat-tech"
            >
              <MessageCircle size={16} />
              Chat With Tech
            </Button>
            <Button
              onClick={onConfirm}
              variant="outline"
              className="w-full"
              data-testid="button-ok"
            >
              OK
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
