import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertPetSchema, insertChatMessageSchema, insertUserProgressSchema } from "@shared/schema";
import { ZodError } from "zod";
import crypto from "crypto";

function handleZodError(err: ZodError, res: Response) {
  const errorMessage = err.errors.map(e => `${e.path.join('.')}: ${e.message}`).join(', ');
  return res.status(400).json({ message: `Validation error: ${errorMessage}` });
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Prefix all routes with /api

  // Auth routes
  app.post("/api/auth/register", async (req: Request, res: Response) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user with the email already exists
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(400).json({ message: "User with this email already exists" });
      }
      
      // Simple password hashing for demo (use bcrypt in a real app)
      const hashedPassword = crypto.createHash('sha256').update(userData.password).digest('hex');
      
      const user = await storage.createUser({
        ...userData,
        password: hashedPassword
      });
      
      // Remove password from the response
      const { password, ...userWithoutPassword } = user;
      
      res.status(201).json(userWithoutPassword);
    } catch (err) {
      if (err instanceof ZodError) {
        return handleZodError(err, res);
      }
      res.status(500).json({ message: "Server error while registering" });
    }
  });

  app.post("/api/auth/login", async (req: Request, res: Response) => {
    try {
      const { email, password } = req.body;
      
      if (!email || !password) {
        return res.status(400).json({ message: "Email and password are required" });
      }
      
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      // Simple password checking for demo
      const hashedPassword = crypto.createHash('sha256').update(password).digest('hex');
      
      if (user.password !== hashedPassword) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      // Remove password from the response
      const { password: _, ...userWithoutPassword } = user;
      
      res.status(200).json(userWithoutPassword);
    } catch (err) {
      res.status(500).json({ message: "Server error while logging in" });
    }
  });

  // Pet routes
  app.post("/api/pets", async (req: Request, res: Response) => {
    try {
      const petData = insertPetSchema.parse(req.body);
      const pet = await storage.createPet(petData);
      res.status(201).json(pet);
    } catch (err) {
      if (err instanceof ZodError) {
        return handleZodError(err, res);
      }
      res.status(500).json({ message: "Server error while creating pet" });
    }
  });

  app.get("/api/pets/user/:userId", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const pets = await storage.getPetsByUserId(userId);
      res.status(200).json(pets);
    } catch (err) {
      res.status(500).json({ message: "Server error while fetching pets" });
    }
  });

  app.get("/api/pets/:id", async (req: Request, res: Response) => {
    try {
      const petId = parseInt(req.params.id);
      if (isNaN(petId)) {
        return res.status(400).json({ message: "Invalid pet ID" });
      }
      
      const pet = await storage.getPet(petId);
      if (!pet) {
        return res.status(404).json({ message: "Pet not found" });
      }
      
      res.status(200).json(pet);
    } catch (err) {
      res.status(500).json({ message: "Server error while fetching pet" });
    }
  });

  app.put("/api/pets/:id", async (req: Request, res: Response) => {
    try {
      const petId = parseInt(req.params.id);
      if (isNaN(petId)) {
        return res.status(400).json({ message: "Invalid pet ID" });
      }
      
      const pet = await storage.getPet(petId);
      if (!pet) {
        return res.status(404).json({ message: "Pet not found" });
      }
      
      const updatedPet = await storage.updatePet(petId, req.body);
      res.status(200).json(updatedPet);
    } catch (err) {
      res.status(500).json({ message: "Server error while updating pet" });
    }
  });

  // Training module routes
  app.get("/api/training/modules", async (_req: Request, res: Response) => {
    try {
      const modules = await storage.getAllTrainingModules();
      res.status(200).json(modules);
    } catch (err) {
      res.status(500).json({ message: "Server error while fetching training modules" });
    }
  });

  app.get("/api/training/modules/:id", async (req: Request, res: Response) => {
    try {
      const moduleId = parseInt(req.params.id);
      if (isNaN(moduleId)) {
        return res.status(400).json({ message: "Invalid module ID" });
      }
      
      const module = await storage.getTrainingModule(moduleId);
      if (!module) {
        return res.status(404).json({ message: "Training module not found" });
      }
      
      res.status(200).json(module);
    } catch (err) {
      res.status(500).json({ message: "Server error while fetching training module" });
    }
  });

  app.get("/api/training/modules/:id/lessons", async (req: Request, res: Response) => {
    try {
      const moduleId = parseInt(req.params.id);
      if (isNaN(moduleId)) {
        return res.status(400).json({ message: "Invalid module ID" });
      }
      
      const lessons = await storage.getLessonsByModuleId(moduleId);
      res.status(200).json(lessons);
    } catch (err) {
      res.status(500).json({ message: "Server error while fetching lessons" });
    }
  });

  app.get("/api/training/lessons/:id", async (req: Request, res: Response) => {
    try {
      const lessonId = parseInt(req.params.id);
      if (isNaN(lessonId)) {
        return res.status(400).json({ message: "Invalid lesson ID" });
      }
      
      const lesson = await storage.getTrainingLesson(lessonId);
      if (!lesson) {
        return res.status(404).json({ message: "Lesson not found" });
      }
      
      res.status(200).json(lesson);
    } catch (err) {
      res.status(500).json({ message: "Server error while fetching lesson" });
    }
  });

  // User progress routes
  app.post("/api/progress", async (req: Request, res: Response) => {
    try {
      const progressData = insertUserProgressSchema.parse(req.body);
      
      // Check if progress already exists
      const existingProgress = await storage.getUserProgress(
        progressData.userId,
        progressData.petId,
        progressData.moduleId
      );
      
      if (existingProgress) {
        // Update existing progress
        const updatedProgress = await storage.updateUserProgress(existingProgress.id, progressData);
        return res.status(200).json(updatedProgress);
      }
      
      // Create new progress
      const progress = await storage.createUserProgress(progressData);
      res.status(201).json(progress);
    } catch (err) {
      if (err instanceof ZodError) {
        return handleZodError(err, res);
      }
      res.status(500).json({ message: "Server error while saving progress" });
    }
  });

  app.get("/api/progress/user/:userId/pet/:petId", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      const petId = parseInt(req.params.petId);
      
      if (isNaN(userId) || isNaN(petId)) {
        return res.status(400).json({ message: "Invalid user ID or pet ID" });
      }
      
      const progress = await storage.getUserProgressByModule(userId, petId);
      res.status(200).json(progress);
    } catch (err) {
      res.status(500).json({ message: "Server error while fetching progress" });
    }
  });

  // Achievement routes
  app.get("/api/achievements", async (_req: Request, res: Response) => {
    try {
      const achievements = await storage.getAllAchievements();
      res.status(200).json(achievements);
    } catch (err) {
      res.status(500).json({ message: "Server error while fetching achievements" });
    }
  });

  app.get("/api/achievements/user/:userId/pet/:petId", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      const petId = parseInt(req.params.petId);
      
      if (isNaN(userId) || isNaN(petId)) {
        return res.status(400).json({ message: "Invalid user ID or pet ID" });
      }
      
      const userAchievements = await storage.getUserAchievements(userId, petId);
      res.status(200).json(userAchievements);
    } catch (err) {
      res.status(500).json({ message: "Server error while fetching user achievements" });
    }
  });

  // Chat routes
  app.post("/api/chat", async (req: Request, res: Response) => {
    try {
      const messageData = insertChatMessageSchema.parse(req.body);
      const message = await storage.createChatMessage(messageData);
      
      // If it's a user message, generate an AI response
      if (messageData.isUserMessage) {
        // Simple AI response logic (in a real app, this would call an actual AI service)
        const aiResponses = [
          "That's a common behavior for pets! Here are some solutions you can try...",
          "Great question! Let me explain how you can address this issue...",
          "I understand your concern. Based on your pet's breed and age, I would recommend...",
          "This is normal at this stage of development. Here's what you should know...",
          "I'd be happy to help with that. The most effective approach would be to..."
        ];
        
        const randomResponse = aiResponses[Math.floor(Math.random() * aiResponses.length)];
        
        const aiMessage = await storage.createChatMessage({
          userId: messageData.userId,
          petId: messageData.petId,
          message: randomResponse,
          isUserMessage: false
        });
        
        return res.status(201).json([message, aiMessage]);
      }
      
      res.status(201).json(message);
    } catch (err) {
      if (err instanceof ZodError) {
        return handleZodError(err, res);
      }
      res.status(500).json({ message: "Server error while sending message" });
    }
  });

  app.get("/api/chat/user/:userId/pet/:petId", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      const petId = parseInt(req.params.petId);
      
      if (isNaN(userId) || isNaN(petId)) {
        return res.status(400).json({ message: "Invalid user ID or pet ID" });
      }
      
      const messages = await storage.getChatMessages(userId, petId);
      res.status(200).json(messages);
    } catch (err) {
      res.status(500).json({ message: "Server error while fetching messages" });
    }
  });

  // Subscription routes (mock for demo)
  app.post("/api/subscription/select", async (req: Request, res: Response) => {
    try {
      const { userId, plan } = req.body;
      
      if (!userId || !plan) {
        return res.status(400).json({ message: "User ID and plan are required" });
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Update user with selected plan
      const updatedUser = await storage.updateUser(userId, { subscriptionPlan: plan });
      
      // Remove password from the response
      if (updatedUser) {
        const { password, ...userWithoutPassword } = updatedUser;
        return res.status(200).json(userWithoutPassword);
      }
      
      res.status(500).json({ message: "Failed to update subscription" });
    } catch (err) {
      res.status(500).json({ message: "Server error while selecting plan" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
