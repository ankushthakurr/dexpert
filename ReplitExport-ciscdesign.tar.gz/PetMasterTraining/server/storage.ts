import {
  User, InsertUser, Pet, InsertPet, TrainingModule, InsertTrainingModule,
  TrainingLesson, InsertTrainingLesson, UserProgress, InsertUserProgress,
  Achievement, InsertAchievement, UserAchievement, InsertUserAchievement,
  ChatMessage, InsertChatMessage
} from "@shared/schema";

// Define the interface for storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User | undefined>;

  // Pet operations
  getPet(id: number): Promise<Pet | undefined>;
  getPetsByUserId(userId: number): Promise<Pet[]>;
  createPet(pet: InsertPet): Promise<Pet>;
  updatePet(id: number, updates: Partial<Pet>): Promise<Pet | undefined>;

  // Training module operations
  getTrainingModule(id: number): Promise<TrainingModule | undefined>;
  getAllTrainingModules(): Promise<TrainingModule[]>;
  getTrainingModulesByLevel(level: number): Promise<TrainingModule[]>;
  createTrainingModule(module: InsertTrainingModule): Promise<TrainingModule>;

  // Training lesson operations
  getTrainingLesson(id: number): Promise<TrainingLesson | undefined>;
  getLessonsByModuleId(moduleId: number): Promise<TrainingLesson[]>;
  createTrainingLesson(lesson: InsertTrainingLesson): Promise<TrainingLesson>;

  // User progress operations
  getUserProgress(userId: number, petId: number, moduleId: number): Promise<UserProgress | undefined>;
  getUserProgressByModule(userId: number, petId: number): Promise<UserProgress[]>;
  createUserProgress(progress: InsertUserProgress): Promise<UserProgress>;
  updateUserProgress(id: number, updates: Partial<UserProgress>): Promise<UserProgress | undefined>;

  // Achievement operations
  getAchievement(id: number): Promise<Achievement | undefined>;
  getAllAchievements(): Promise<Achievement[]>;
  createAchievement(achievement: InsertAchievement): Promise<Achievement>;

  // User achievement operations
  getUserAchievements(userId: number, petId: number): Promise<(UserAchievement & { achievement: Achievement })[]>;
  createUserAchievement(userAchievement: InsertUserAchievement): Promise<UserAchievement>;

  // Chat operations
  getChatMessages(userId: number, petId?: number): Promise<ChatMessage[]>;
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
  
  // Initializes default data like training modules and achievements
  initializeDefaultData(): Promise<void>;
}

// In-memory implementation of the storage interface
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private pets: Map<number, Pet>;
  private trainingModules: Map<number, TrainingModule>;
  private trainingLessons: Map<number, TrainingLesson>;
  private userProgress: Map<number, UserProgress>;
  private achievements: Map<number, Achievement>;
  private userAchievements: Map<number, UserAchievement>;
  private chatMessages: Map<number, ChatMessage>;

  private currentUserId: number;
  private currentPetId: number;
  private currentTrainingModuleId: number;
  private currentTrainingLessonId: number;
  private currentUserProgressId: number;
  private currentAchievementId: number;
  private currentUserAchievementId: number;
  private currentChatMessageId: number;

  constructor() {
    this.users = new Map();
    this.pets = new Map();
    this.trainingModules = new Map();
    this.trainingLessons = new Map();
    this.userProgress = new Map();
    this.achievements = new Map();
    this.userAchievements = new Map();
    this.chatMessages = new Map();

    this.currentUserId = 1;
    this.currentPetId = 1;
    this.currentTrainingModuleId = 1;
    this.currentTrainingLessonId = 1;
    this.currentUserProgressId = 1;
    this.currentAchievementId = 1;
    this.currentUserAchievementId = 1;
    this.currentChatMessageId = 1;
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase()
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email.toLowerCase() === email.toLowerCase()
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const now = new Date();
    // Set trial end date to 7 days from now
    const trialEndDate = new Date();
    trialEndDate.setDate(trialEndDate.getDate() + 7);
    
    const user: User = { 
      ...insertUser, 
      id, 
      createdAt: now,
      trialEndDate,
      subscriptionPlan: "free"
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;

    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Pet operations
  async getPet(id: number): Promise<Pet | undefined> {
    return this.pets.get(id);
  }

  async getPetsByUserId(userId: number): Promise<Pet[]> {
    return Array.from(this.pets.values()).filter(
      (pet) => pet.userId === userId
    );
  }

  async createPet(insertPet: InsertPet): Promise<Pet> {
    const id = this.currentPetId++;
    const now = new Date();
    const pet: Pet = { ...insertPet, id, createdAt: now };
    this.pets.set(id, pet);
    return pet;
  }

  async updatePet(id: number, updates: Partial<Pet>): Promise<Pet | undefined> {
    const pet = await this.getPet(id);
    if (!pet) return undefined;

    const updatedPet = { ...pet, ...updates };
    this.pets.set(id, updatedPet);
    return updatedPet;
  }

  // Training module operations
  async getTrainingModule(id: number): Promise<TrainingModule | undefined> {
    return this.trainingModules.get(id);
  }

  async getAllTrainingModules(): Promise<TrainingModule[]> {
    return Array.from(this.trainingModules.values()).sort((a, b) => a.order - b.order);
  }

  async getTrainingModulesByLevel(level: number): Promise<TrainingModule[]> {
    return Array.from(this.trainingModules.values())
      .filter((module) => module.level === level)
      .sort((a, b) => a.order - b.order);
  }

  async createTrainingModule(module: InsertTrainingModule): Promise<TrainingModule> {
    const id = this.currentTrainingModuleId++;
    const now = new Date();
    const trainingModule: TrainingModule = { ...module, id, createdAt: now };
    this.trainingModules.set(id, trainingModule);
    return trainingModule;
  }

  // Training lesson operations
  async getTrainingLesson(id: number): Promise<TrainingLesson | undefined> {
    return this.trainingLessons.get(id);
  }

  async getLessonsByModuleId(moduleId: number): Promise<TrainingLesson[]> {
    return Array.from(this.trainingLessons.values())
      .filter((lesson) => lesson.moduleId === moduleId)
      .sort((a, b) => a.order - b.order);
  }

  async createTrainingLesson(lesson: InsertTrainingLesson): Promise<TrainingLesson> {
    const id = this.currentTrainingLessonId++;
    const now = new Date();
    const trainingLesson: TrainingLesson = { ...lesson, id, createdAt: now };
    this.trainingLessons.set(id, trainingLesson);
    return trainingLesson;
  }

  // User progress operations
  async getUserProgress(userId: number, petId: number, moduleId: number): Promise<UserProgress | undefined> {
    return Array.from(this.userProgress.values()).find(
      (progress) => progress.userId === userId && progress.petId === petId && progress.moduleId === moduleId
    );
  }

  async getUserProgressByModule(userId: number, petId: number): Promise<UserProgress[]> {
    return Array.from(this.userProgress.values()).filter(
      (progress) => progress.userId === userId && progress.petId === petId
    );
  }

  async createUserProgress(progress: InsertUserProgress): Promise<UserProgress> {
    const id = this.currentUserProgressId++;
    const now = new Date();
    const userProgress: UserProgress = { ...progress, id, updatedAt: now };
    this.userProgress.set(id, userProgress);
    return userProgress;
  }

  async updateUserProgress(id: number, updates: Partial<UserProgress>): Promise<UserProgress | undefined> {
    const progress = this.userProgress.get(id);
    if (!progress) return undefined;

    const now = new Date();
    const updatedProgress = { ...progress, ...updates, updatedAt: now };
    this.userProgress.set(id, updatedProgress);
    return updatedProgress;
  }

  // Achievement operations
  async getAchievement(id: number): Promise<Achievement | undefined> {
    return this.achievements.get(id);
  }

  async getAllAchievements(): Promise<Achievement[]> {
    return Array.from(this.achievements.values());
  }

  async createAchievement(achievement: InsertAchievement): Promise<Achievement> {
    const id = this.currentAchievementId++;
    const now = new Date();
    const newAchievement: Achievement = { ...achievement, id, createdAt: now };
    this.achievements.set(id, newAchievement);
    return newAchievement;
  }

  // User achievement operations
  async getUserAchievements(userId: number, petId: number): Promise<(UserAchievement & { achievement: Achievement })[]> {
    const userAchievements = Array.from(this.userAchievements.values()).filter(
      (userAchievement) => userAchievement.userId === userId && userAchievement.petId === petId
    );

    return userAchievements.map((userAchievement) => {
      const achievement = this.achievements.get(userAchievement.achievementId);
      if (!achievement) {
        throw new Error(`Achievement with id ${userAchievement.achievementId} not found`);
      }
      return {
        ...userAchievement,
        achievement,
      };
    });
  }

  async createUserAchievement(userAchievement: InsertUserAchievement): Promise<UserAchievement> {
    const id = this.currentUserAchievementId++;
    const now = new Date();
    const newUserAchievement: UserAchievement = { ...userAchievement, id, earnedAt: now };
    this.userAchievements.set(id, newUserAchievement);
    return newUserAchievement;
  }

  // Chat operations
  async getChatMessages(userId: number, petId?: number): Promise<ChatMessage[]> {
    return Array.from(this.chatMessages.values())
      .filter((message) => {
        if (petId) {
          return message.userId === userId && message.petId === petId;
        }
        return message.userId === userId;
      })
      .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
  }

  async createChatMessage(message: InsertChatMessage): Promise<ChatMessage> {
    const id = this.currentChatMessageId++;
    const now = new Date();
    const chatMessage: ChatMessage = { ...message, id, createdAt: now };
    this.chatMessages.set(id, chatMessage);
    return chatMessage;
  }

  // Initialize default data
  async initializeDefaultData(): Promise<void> {
    // Training Modules
    const houseTraining = await this.createTrainingModule({
      title: "House Training",
      description: "Learn the basics of house training for your pet",
      level: 1,
      icon: "home",
      color: "#10B981", // accent
      requiresSubscription: "free",
      moduleType: "house-training",
      order: 1,
    });

    const basicCommands = await this.createTrainingModule({
      title: "Basic Commands",
      description: "Teach your pet essential commands",
      level: 1,
      icon: "clipboard-list",
      color: "#4F46E5", // primary
      requiresSubscription: "free",
      moduleType: "basic-commands",
      order: 2,
    });

    const leashTraining = await this.createTrainingModule({
      title: "Leash Training",
      description: "Train your pet to walk properly on a leash",
      level: 2,
      icon: "link",
      color: "#EC4899", // secondary
      requiresSubscription: "basic",
      moduleType: "leash-training",
      order: 3,
    });

    const socialization = await this.createTrainingModule({
      title: "Socialization",
      description: "Help your pet interact with others",
      level: 3,
      icon: "users",
      color: "#CCCCCC", // gray
      requiresSubscription: "advanced",
      moduleType: "socialization",
      order: 4,
    });

    // Training Lessons for Basic Commands
    await this.createTrainingLesson({
      moduleId: basicCommands.id,
      title: "Teaching 'Sit' Command",
      description: "Learn how to teach your pet to sit on command",
      videoUrl: "/videos/sit-command.mp4",
      duration: 204, // 3:24
      instructions: [
        "Start with your dog in a standing position",
        "Hold a treat close to your dog's nose",
        "Move your hand up, causing their head to follow the treat and their bottom to lower",
        "Once they're in a sitting position, say 'Sit'",
        "Give them the treat and praise",
        "Repeat several times, gradually removing the treat"
      ],
      tips: [
        {
          title: "Consistency is Key",
          description: "Short, consistent practice sessions are more effective than long, infrequent ones. Try to practice for 5 minutes, 3 times a day."
        }
      ],
      order: 1,
    });

    await this.createTrainingLesson({
      moduleId: basicCommands.id,
      title: "Advanced 'Stay' Command",
      description: "Build on basic commands with duration and distance",
      videoUrl: "/videos/stay-command.mp4",
      duration: 600, // 10:00
      instructions: [
        "Start with your dog in a sitting position",
        "Hold your hand out in front of you, palm facing the dog",
        "Say 'Stay' firmly",
        "Take a step back",
        "If your dog stays, reward them",
        "Gradually increase the distance and duration"
      ],
      tips: [
        {
          title: "Patience is Essential",
          description: "This command takes time to master. Start with very short durations and slowly build up."
        }
      ],
      order: 2,
    });

    // Training Lessons for House Training
    await this.createTrainingLesson({
      moduleId: houseTraining.id,
      title: "Potty Training Basics",
      description: "Learn the fundamentals of potty training your pet",
      videoUrl: "/videos/potty-training.mp4",
      duration: 540, // 9:00
      instructions: [
        "Establish a routine for feeding times",
        "Take your pet outside first thing in the morning",
        "Take them out after meals and naps",
        "Reward them immediately after they go in the right place",
        "Never punish accidents, just clean thoroughly"
      ],
      tips: [
        {
          title: "Consistency in Schedule",
          description: "A regular schedule helps your pet learn when it's time to go outside."
        }
      ],
      order: 1,
    });

    // Achievements
    await this.createAchievement({
      title: "First Sit",
      description: "Successfully taught your pet to sit",
      icon: "badge-check",
      color: "#F59E0B", // yellow
      requiredAction: "complete_sit_lesson",
    });

    await this.createAchievement({
      title: "3 Day Streak",
      description: "Trained for 3 consecutive days",
      icon: "chart-bar",
      color: "#4F46E5", // primary
      requiredAction: "streak_3_days",
    });

    await this.createAchievement({
      title: "House Training Pro",
      description: "Completed the house training module",
      icon: "home",
      color: "#10B981", // accent
      requiredAction: "complete_house_training",
    });
  }
}

export const storage = new MemStorage();
storage.initializeDefaultData();
