// Subscription Plans
export const SUBSCRIPTION_PLANS = {
  FREE: 'free',
  BASIC: 'basic',
  ADVANCED: 'advanced'
};

// Pet Types
export const PET_TYPES = {
  DOG: 'dog',
  CAT: 'cat'
};

// Training Levels
export const TRAINING_LEVELS = {
  BEGINNER: 'beginner',
  INTERMEDIATE: 'intermediate',
  ADVANCED: 'advanced'
};

// Module Types
export const MODULE_TYPES = {
  HOUSE_TRAINING: 'house-training',
  BASIC_COMMANDS: 'basic-commands',
  LEASH_TRAINING: 'leash-training',
  SOCIALIZATION: 'socialization'
};

// Age Units
export const AGE_UNITS = {
  MONTHS: 'months',
  YEARS: 'years'
};

// Error Messages
export const ERROR_MESSAGES = {
  AUTH_REQUIRED: 'Authentication required',
  PET_REQUIRED: 'Please select a pet',
  NETWORK_ERROR: 'Network error, please try again',
  INVALID_CREDENTIALS: 'Invalid credentials',
  SUBSCRIPTION_REQUIRED: 'This feature requires a subscription'
};

// Success Messages
export const SUCCESS_MESSAGES = {
  LOGIN_SUCCESS: 'Login successful',
  REGISTRATION_SUCCESS: 'Account created successfully',
  PET_REGISTRATION_SUCCESS: 'Pet registered successfully',
  PROGRESS_UPDATED: 'Progress updated successfully',
  SUBSCRIPTION_UPDATED: 'Subscription updated successfully'
};

// UI Elements
export const UI = {
  COLORS: {
    PRIMARY: '#4F46E5',
    SECONDARY: '#EC4899',
    ACCENT: '#10B981',
    SUCCESS: '#22C55E',
    ERROR: '#EF4444',
    WARNING: '#F59E0B'
  },
  ANIMATION_DURATION: '200ms'
};

// Local Storage Keys
export const STORAGE_KEYS = {
  USER: 'user',
  PET: 'pet',
  ONBOARDING_COMPLETE: 'hasCompletedOnboarding'
};

// Default Trial Length (days)
export const DEFAULT_TRIAL_LENGTH = 7;
