import { useState } from 'react';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { User } from '@/App';

interface UseSubscriptionProps {
  user: User | null;
  setUser: (user: User) => void;
}

export function useSubscription({ user, setUser }: UseSubscriptionProps) {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  // Select subscription plan
  const selectPlan = async (plan: string) => {
    if (!user) {
      toast({
        title: 'Authentication required',
        description: 'Please login to select a subscription plan',
        variant: 'destructive',
      });
      return null;
    }

    setIsLoading(true);
    try {
      const res = await apiRequest('POST', '/api/subscription/select', {
        userId: user.id,
        plan
      });
      
      const updatedUser: User = await res.json();
      
      // Update user in context and localStorage
      setUser(updatedUser);
      localStorage.setItem('user', JSON.stringify(updatedUser));
      
      toast({
        title: 'Subscription Updated',
        description: `You are now on the ${updatedUser.subscriptionPlan} plan`,
      });
      
      return updatedUser;
    } catch (error) {
      console.error('Subscription selection error:', error);
      toast({
        title: 'Failed to update subscription',
        description: error instanceof Error ? error.message : 'Please try again',
        variant: 'destructive',
      });
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  // Check if trial is active
  const isTrialActive = () => {
    if (!user || !user.trialEndDate) return false;
    
    const trialEndDate = new Date(user.trialEndDate);
    return trialEndDate > new Date();
  };

  // Calculate days remaining in trial
  const getDaysRemainingInTrial = () => {
    if (!user || !user.trialEndDate) return 0;
    
    const trialEndDate = new Date(user.trialEndDate);
    const today = new Date();
    
    // Return 0 if trial has ended
    if (trialEndDate < today) return 0;
    
    // Calculate days remaining
    const diffTime = trialEndDate.getTime() - today.getTime();
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  };

  return {
    subscription: user?.subscriptionPlan,
    selectPlan,
    isTrialActive,
    daysRemainingInTrial: getDaysRemainingInTrial(),
    isLoading
  };
}
