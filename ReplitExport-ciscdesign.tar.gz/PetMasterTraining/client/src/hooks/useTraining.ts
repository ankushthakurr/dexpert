import { useState } from 'react';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { User, Pet } from '@/App';

interface UseTrainingProps {
  user: User | null;
  pet: Pet | null;
}

export function useTraining({ user, pet }: UseTrainingProps) {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  // Update progress function
  const updateProgress = async (moduleId: number, lessonId: number, progress: number, checklist: any[] = []) => {
    if (!user || !pet) {
      toast({
        title: 'Authentication required',
        description: 'Please login and select a pet to track progress',
        variant: 'destructive',
      });
      return null;
    }

    setIsLoading(true);
    try {
      const res = await apiRequest('POST', '/api/progress', {
        userId: user.id,
        petId: pet.id,
        moduleId,
        lessonId,
        progress,
        checklist,
      });
      
      const progressData = await res.json();
      
      // Invalidate related queries
      queryClient.invalidateQueries({ queryKey: [`/api/progress/user/${user.id}/pet/${pet.id}`] });
      queryClient.invalidateQueries({ queryKey: ['/api/progress/user', user.id, 'pet', pet.id] });
      
      toast({
        title: 'Progress updated',
        description: `Training progress: ${progress}%`,
      });
      
      return progressData;
    } catch (error) {
      console.error('Progress update error:', error);
      toast({
        title: 'Failed to update progress',
        description: error instanceof Error ? error.message : 'Please try again',
        variant: 'destructive',
      });
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  // Check if a module is accessible based on subscription
  const canAccessModule = (moduleSubscription: string, userSubscription: string) => {
    if (moduleSubscription === 'free') return true;
    if (moduleSubscription === 'basic' && (userSubscription === 'basic' || userSubscription === 'advanced')) return true;
    if (moduleSubscription === 'advanced' && userSubscription === 'advanced') return true;
    return false;
  };

  // Complete a training module (100% progress)
  const completeModule = async (moduleId: number, lessonId: number) => {
    return updateProgress(moduleId, lessonId, 100);
  };

  return {
    updateProgress,
    completeModule,
    canAccessModule,
    isLoading
  };
}
