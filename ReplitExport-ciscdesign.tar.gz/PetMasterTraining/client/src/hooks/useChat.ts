import { useState } from 'react';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { User, Pet } from '@/App';

interface UseChatProps {
  user: User | null;
  pet: Pet | null;
}

export function useChat({ user, pet }: UseChatProps) {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  // Send message function
  const sendMessage = async (message: string) => {
    if (!user || !pet) {
      toast({
        title: 'Authentication required',
        description: 'Please login and select a pet to use the chat',
        variant: 'destructive',
      });
      return null;
    }

    setIsLoading(true);
    try {
      const res = await apiRequest('POST', '/api/chat', {
        userId: user.id,
        petId: pet.id,
        message,
        isUserMessage: true
      });
      
      const response = await res.json();
      
      // Invalidate chat messages query
      queryClient.invalidateQueries({ queryKey: ['/api/chat/user', user.id, 'pet', pet.id] });
      
      return response;
    } catch (error) {
      console.error('Message send error:', error);
      toast({
        title: 'Failed to send message',
        description: error instanceof Error ? error.message : 'Please try again',
        variant: 'destructive',
      });
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  // Send AI message (for system-initiated messages)
  const sendAIMessage = async (message: string) => {
    if (!user || !pet) {
      return null;
    }

    try {
      const res = await apiRequest('POST', '/api/chat', {
        userId: user.id,
        petId: pet.id,
        message,
        isUserMessage: false
      });
      
      const response = await res.json();
      
      // Invalidate chat messages query
      queryClient.invalidateQueries({ queryKey: ['/api/chat/user', user.id, 'pet', pet.id] });
      
      return response;
    } catch (error) {
      console.error('AI message send error:', error);
      return null;
    }
  };

  return {
    sendMessage,
    sendAIMessage,
    isLoading
  };
}
