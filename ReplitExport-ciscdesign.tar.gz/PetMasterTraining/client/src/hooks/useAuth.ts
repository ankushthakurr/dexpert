import { useState, useEffect } from 'react';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { User } from '@/App';

interface UseAuthProps {
  initialUser: User | null;
  setUser: (user: User | null) => void;
}

export function useAuth({ initialUser, setUser }: UseAuthProps) {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  // Login function
  const login = async (email: string, password: string) => {
    setIsLoading(true);
    try {
      const res = await apiRequest('POST', '/api/auth/login', { email, password });
      const userData: User = await res.json();
      
      // Store user in context and localStorage
      setUser(userData);
      localStorage.setItem('user', JSON.stringify(userData));
      
      toast({
        title: 'Login successful',
        description: 'Welcome back to PetTrainer Pro',
      });
      
      return userData;
    } catch (error) {
      console.error('Login error:', error);
      toast({
        title: 'Login failed',
        description: error instanceof Error ? error.message : 'Invalid credentials',
        variant: 'destructive',
      });
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  // Register function
  const register = async (registerData: { username: string; email: string; password: string; name?: string }) => {
    setIsLoading(true);
    try {
      const res = await apiRequest('POST', '/api/auth/register', registerData);
      const userData: User = await res.json();
      
      // Store user in context and localStorage
      setUser(userData);
      localStorage.setItem('user', JSON.stringify(userData));
      
      toast({
        title: 'Account created!',
        description: 'Welcome to PetTrainer Pro',
      });
      
      return userData;
    } catch (error) {
      console.error('Registration error:', error);
      toast({
        title: 'Registration failed',
        description: error instanceof Error ? error.message : 'Please try again',
        variant: 'destructive',
      });
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  // Logout function
  const logout = () => {
    setUser(null);
    localStorage.removeItem('user');
    localStorage.removeItem('pet');
    localStorage.removeItem('hasCompletedOnboarding');
    
    toast({
      title: 'Logged out',
      description: 'You have been successfully logged out',
    });
  };

  // Check if user is authenticated
  const isAuthenticated = () => {
    return !!initialUser;
  };

  return { user: initialUser, login, register, logout, isAuthenticated, isLoading };
}
