import { useState } from 'react';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Pet, User } from '@/App';

interface UsePetProps {
  user: User | null;
  initialPet: Pet | null;
  setPet: (pet: Pet | null) => void;
}

export function usePet({ user, initialPet, setPet }: UsePetProps) {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  // Register pet function
  const registerPet = async (petData: Omit<Pet, 'id' | 'userId'>) => {
    if (!user) {
      toast({
        title: 'Authentication required',
        description: 'Please login to register a pet',
        variant: 'destructive',
      });
      return null;
    }

    setIsLoading(true);
    try {
      const res = await apiRequest('POST', '/api/pets', {
        ...petData,
        userId: user.id,
      });
      
      const pet: Pet = await res.json();
      
      // Store pet in context and localStorage
      setPet(pet);
      localStorage.setItem('pet', JSON.stringify(pet));
      
      toast({
        title: 'Pet registered',
        description: `${pet.name} has been added to your profile`,
      });
      
      return pet;
    } catch (error) {
      console.error('Pet registration error:', error);
      toast({
        title: 'Registration failed',
        description: error instanceof Error ? error.message : 'Please try again',
        variant: 'destructive',
      });
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  // Update pet function
  const updatePet = async (petId: number, updates: Partial<Pet>) => {
    if (!user) {
      toast({
        title: 'Authentication required',
        description: 'Please login to update pet information',
        variant: 'destructive',
      });
      return null;
    }

    setIsLoading(true);
    try {
      const res = await apiRequest('PUT', `/api/pets/${petId}`, updates);
      const updatedPet: Pet = await res.json();
      
      // Update pet in context and localStorage
      setPet(updatedPet);
      localStorage.setItem('pet', JSON.stringify(updatedPet));
      
      toast({
        title: 'Pet updated',
        description: `${updatedPet.name}'s information has been updated`,
      });
      
      return updatedPet;
    } catch (error) {
      console.error('Pet update error:', error);
      toast({
        title: 'Update failed',
        description: error instanceof Error ? error.message : 'Please try again',
        variant: 'destructive',
      });
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  // Fetch pet function
  const fetchPet = async (petId: number) => {
    setIsLoading(true);
    try {
      const res = await fetch(`/api/pets/${petId}`);
      if (!res.ok) {
        throw new Error('Failed to fetch pet');
      }
      
      const pet: Pet = await res.json();
      
      // Store pet in context and localStorage
      setPet(pet);
      localStorage.setItem('pet', JSON.stringify(pet));
      
      return pet;
    } catch (error) {
      console.error('Pet fetch error:', error);
      toast({
        title: 'Failed to fetch pet information',
        description: error instanceof Error ? error.message : 'Please try again',
        variant: 'destructive',
      });
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  // Fetch user's pets
  const fetchUserPets = async () => {
    if (!user) {
      return [];
    }

    setIsLoading(true);
    try {
      const res = await fetch(`/api/pets/user/${user.id}`);
      if (!res.ok) {
        throw new Error('Failed to fetch pets');
      }
      
      const pets: Pet[] = await res.json();
      
      // If user has at least one pet but none selected, select the first one
      if (pets.length > 0 && !initialPet) {
        setPet(pets[0]);
        localStorage.setItem('pet', JSON.stringify(pets[0]));
      }
      
      return pets;
    } catch (error) {
      console.error('Pets fetch error:', error);
      toast({
        title: 'Failed to fetch pets',
        description: error instanceof Error ? error.message : 'Please try again',
        variant: 'destructive',
      });
      return [];
    } finally {
      setIsLoading(false);
    }
  };

  return { 
    pet: initialPet,
    registerPet,
    updatePet,
    fetchPet,
    fetchUserPets,
    isLoading
  };
}
