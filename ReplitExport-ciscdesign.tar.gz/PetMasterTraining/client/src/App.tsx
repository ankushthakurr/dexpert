import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import AuthScreen from "@/components/auth/AuthScreen";
import OnboardingScreen from "@/components/onboarding/OnboardingScreen";
import HomeScreen from "@/components/home/HomeScreen";
import TrainingScreen from "@/components/training/TrainingScreen";
import AIChatScreen from "@/components/chat/AIChatScreen";
import SubscriptionScreen from "@/components/subscription/SubscriptionScreen";
import ProfileScreen from "@/components/profile/ProfileScreen";
import BottomNavigation from "@/components/layout/BottomNavigation";
import { useState, useEffect } from "react";

// For simplicity, we'll use a simple state to track auth status
// In a real app, this would use a proper auth system with secure tokens
export type User = {
  id: number;
  email: string;
  name?: string;
  username: string;
  subscriptionPlan: string;
  trialEndDate: string;
};

export type Pet = {
  id: number;
  userId: number;
  name: string;
  type: string;
  breed?: string;
  age?: number;
  ageUnit?: string;
  trainingLevel?: string;
  imageUrl?: string;
  healthNotes?: string;
};

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [pet, setPet] = useState<Pet | null>(null);
  const [hasCompletedOnboarding, setHasCompletedOnboarding] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // Check for stored auth on mount
  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    const storedPet = localStorage.getItem('pet');
    const storedOnboarding = localStorage.getItem('hasCompletedOnboarding');
    
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
    
    if (storedPet) {
      setPet(JSON.parse(storedPet));
    }
    
    if (storedOnboarding === 'true') {
      setHasCompletedOnboarding(true);
    }
    
    setIsLoading(false);
  }, []);

  // Save auth state changes to localStorage
  useEffect(() => {
    if (user) {
      localStorage.setItem('user', JSON.stringify(user));
    } else {
      localStorage.removeItem('user');
    }
  }, [user]);

  useEffect(() => {
    if (pet) {
      localStorage.setItem('pet', JSON.stringify(pet));
    } else {
      localStorage.removeItem('pet');
    }
  }, [pet]);

  useEffect(() => {
    localStorage.setItem('hasCompletedOnboarding', hasCompletedOnboarding.toString());
  }, [hasCompletedOnboarding]);

  const handleLogin = (userData: User) => {
    setUser(userData);
  };

  const handleLogout = () => {
    setUser(null);
    setPet(null);
    setHasCompletedOnboarding(false);
  };

  const handlePetRegistration = (petData: Pet) => {
    setPet(petData);
    setHasCompletedOnboarding(true);
  };

  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  return (
    <QueryClientProvider client={queryClient}>
      <div className="min-h-screen max-w-md mx-auto bg-white shadow-lg relative">
        {!user ? (
          <AuthScreen onLogin={handleLogin} />
        ) : !hasCompletedOnboarding ? (
          <OnboardingScreen user={user} onComplete={handlePetRegistration} />
        ) : (
          <div className="pb-16">
            <Switch>
              <Route path="/" exact>
                <HomeScreen user={user} pet={pet} />
              </Route>
              <Route path="/training/:moduleId?" component={TrainingScreen} />
              <Route path="/chat">
                <AIChatScreen user={user} pet={pet} />
              </Route>
              <Route path="/subscription">
                <SubscriptionScreen user={user} setUser={setUser} />
              </Route>
              <Route path="/profile">
                <ProfileScreen user={user} pet={pet} onLogout={handleLogout} />
              </Route>
              <Route component={NotFound} />
            </Switch>
            <BottomNavigation />
          </div>
        )}
      </div>
    </QueryClientProvider>
  );
}

export default App;
