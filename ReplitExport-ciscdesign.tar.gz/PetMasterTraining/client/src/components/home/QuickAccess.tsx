import { useLocation } from 'wouter';

const QuickAccess = () => {
  const [_, navigate] = useLocation();

  const handleNavigation = (path: string) => {
    navigate(path);
  };

  return (
    <div>
      <h2 className="text-lg font-semibold text-gray-900 mb-4">Quick Access</h2>
      
      <div className="grid grid-cols-2 gap-3">
        <div 
          className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm flex flex-col items-center text-center cursor-pointer"
          onClick={() => handleNavigation('/chat')}
        >
          <div className="h-12 w-12 bg-secondary bg-opacity-10 rounded-full flex items-center justify-center mb-2">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-secondary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
            </svg>
          </div>
          <span className="font-medium text-gray-900">Ask Pet Doctor</span>
          <span className="text-xs text-gray-500">AI Assistant</span>
        </div>
        
        <div 
          className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm flex flex-col items-center text-center cursor-pointer"
          onClick={() => handleNavigation('/subscription')}
        >
          <div className="h-12 w-12 bg-accent bg-opacity-10 rounded-full flex items-center justify-center mb-2">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-accent" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
            </svg>
          </div>
          <span className="font-medium text-gray-900">Live Training</span>
          <span className="text-xs text-gray-500">Book a Session</span>
        </div>
        
        <div 
          className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm flex flex-col items-center text-center cursor-pointer"
          onClick={() => handleNavigation('/training')}
        >
          <div className="h-12 w-12 bg-blue-100 rounded-full flex items-center justify-center mb-2">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
            </svg>
          </div>
          <span className="font-medium text-gray-900">Progress</span>
          <span className="text-xs text-gray-500">Track Growth</span>
        </div>
        
        <div className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm flex flex-col items-center text-center cursor-pointer">
          <div className="h-12 w-12 bg-gray-100 rounded-full flex items-center justify-center mb-2">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" />
            </svg>
          </div>
          <span className="font-medium text-gray-900">Resources</span>
          <span className="text-xs text-gray-500">Tips & Guides</span>
        </div>
      </div>
    </div>
  );
};

export default QuickAccess;
