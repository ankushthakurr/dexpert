import { useLocation } from 'wouter';

interface TrainingModulesProps {
  modules: any[];
  progressData: any[];
  userSubscription: string;
}

const TrainingModules = ({ modules, progressData, userSubscription }: TrainingModulesProps) => {
  const [_, navigate] = useLocation();

  // Sort modules by order
  const sortedModules = [...(modules || [])].sort((a, b) => a.order - b.order);

  // Function to check if user can access a module based on subscription
  const canAccessModule = (moduleSubscription: string) => {
    if (moduleSubscription === 'free') return true;
    if (moduleSubscription === 'basic' && (userSubscription === 'basic' || userSubscription === 'advanced')) return true;
    if (moduleSubscription === 'advanced' && userSubscription === 'advanced') return true;
    return false;
  };

  const getModuleProgress = (moduleId: number) => {
    const progress = progressData?.find(p => p.moduleId === moduleId);
    return progress?.progress || 0;
  };

  const getModuleIcon = (iconName: string) => {
    switch (iconName) {
      case 'home':
        return (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
          </svg>
        );
      case 'clipboard-list':
        return (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
          </svg>
        );
      case 'link':
        return (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101" />
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.172 13.828a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
          </svg>
        );
      case 'users':
        return (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
          </svg>
        );
      default:
        return (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
          </svg>
        );
    }
  };

  return (
    <div className="mb-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold text-gray-900">Training Modules</h2>
        <a href="#" className="text-primary text-sm">View All</a>
      </div>
      
      <div className="space-y-4">
        {sortedModules.map(module => {
          const progress = getModuleProgress(module.id);
          const isAccessible = canAccessModule(module.requiresSubscription);
          
          return (
            <div key={module.id} className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm">
              <div className="flex justify-between items-start">
                <div className="flex items-center">
                  <div 
                    className="h-12 w-12 rounded-xl flex items-center justify-center text-white mr-3 flex-shrink-0"
                    style={{ backgroundColor: isAccessible ? module.color : '#CCCCCC' }}
                  >
                    {getModuleIcon(module.icon)}
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-900">{module.title}</h3>
                    <div className="flex items-center">
                      <div className="h-1.5 w-24 bg-gray-200 rounded-full mr-2">
                        <div 
                          className="h-1.5 rounded-full" 
                          style={{ 
                            width: `${progress}%`,
                            backgroundColor: isAccessible ? module.color : '#CCCCCC' 
                          }}
                        ></div>
                      </div>
                      <span className="text-xs text-gray-500">
                        {isAccessible ? `${progress}%` : 'Locked'}
                      </span>
                    </div>
                  </div>
                </div>
                <button 
                  className="h-8 w-8 rounded-full flex items-center justify-center bg-gray-100 text-gray-500"
                  onClick={() => {
                    if (isAccessible) {
                      navigate(`/training/${module.id}`);
                    } else {
                      navigate('/subscription');
                    }
                  }}
                >
                  {isAccessible ? (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  ) : (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                    </svg>
                  )}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default TrainingModules;
