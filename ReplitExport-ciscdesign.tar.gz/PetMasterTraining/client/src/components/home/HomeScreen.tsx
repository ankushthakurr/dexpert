import { User, Pet } from '@/App';
import ProgressOverview from './ProgressOverview';
import TrainingModules from './TrainingModules';
import Achievements from './Achievements';
import QuickAccess from './QuickAccess';
import { useQuery } from '@tanstack/react-query';

interface HomeScreenProps {
  user: User;
  pet: Pet | null;
}

const HomeScreen = ({ user, pet }: HomeScreenProps) => {
  // Fetch user progress for the current pet
  const { data: progressData, isLoading: progressLoading } = useQuery({
    queryKey: ['/api/progress/user', user.id, 'pet', pet?.id],
    queryFn: async () => {
      if (!pet) return [];
      return fetch(`/api/progress/user/${user.id}/pet/${pet.id}`).then(res => res.json());
    },
    enabled: !!pet,
  });

  // Fetch training modules
  const { data: trainingModules, isLoading: modulesLoading } = useQuery({
    queryKey: ['/api/training/modules'],
    queryFn: async () => {
      return fetch('/api/training/modules').then(res => res.json());
    },
  });

  // Fetch user achievements
  const { data: achievements, isLoading: achievementsLoading } = useQuery({
    queryKey: ['/api/achievements/user', user.id, 'pet', pet?.id],
    queryFn: async () => {
      if (!pet) return [];
      return fetch(`/api/achievements/user/${user.id}/pet/${pet.id}`).then(res => res.json());
    },
    enabled: !!pet,
  });

  // Loading state
  if (!pet || progressLoading || modulesLoading || achievementsLoading) {
    return (
      <div className="p-6">
        <div className="animate-pulse">
          <div className="h-6 bg-gray-200 rounded w-3/4 mb-2"></div>
          <div className="h-4 bg-gray-200 rounded w-1/2 mb-6"></div>
          <div className="h-40 bg-gray-200 rounded-2xl mb-6"></div>
          <div className="h-6 bg-gray-200 rounded w-1/4 mb-4"></div>
          <div className="h-20 bg-gray-200 rounded-xl mb-3"></div>
          <div className="h-20 bg-gray-200 rounded-xl mb-3"></div>
          <div className="h-20 bg-gray-200 rounded-xl mb-6"></div>
        </div>
      </div>
    );
  }

  // Get the userName from the user object
  const userName = user.name || user.username;

  return (
    <>
      {/* Header */}
      <header className="p-6 pb-0">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-xl font-bold text-gray-900">Hi, {userName}!</h1>
            <p className="text-gray-600">{pet.name}'s training journey</p>
          </div>
          <div className="relative">
            {pet.imageUrl ? (
              <img src={pet.imageUrl} className="w-12 h-12 rounded-full object-cover border-2 border-primary" alt="Pet profile" />
            ) : (
              <div className="w-12 h-12 rounded-full bg-primary flex items-center justify-center border-2 border-primary">
                <span className="text-white font-semibold">{pet.name.charAt(0)}</span>
              </div>
            )}
            <div className="absolute -bottom-1 -right-1 bg-success text-white rounded-full p-1">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
          </div>
        </div>
      </header>
      
      <div className="p-6">
        {/* Progress Overview */}
        <ProgressOverview progressData={progressData} modules={trainingModules} />
        
        {/* Training Modules */}
        <TrainingModules 
          modules={trainingModules} 
          progressData={progressData}
          userSubscription={user.subscriptionPlan}
        />
        
        {/* Achievements */}
        <Achievements achievements={achievements || []} />
        
        {/* Quick Access */}
        <QuickAccess />
      </div>
    </>
  );
};

export default HomeScreen;
