interface AchievementsProps {
  achievements: any[];
}

const Achievements = ({ achievements }: AchievementsProps) => {
  // Helper function to render achievement icon
  const renderIcon = (iconName: string) => {
    switch (iconName) {
      case 'badge-check':
        return (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
          </svg>
        );
      case 'chart-bar':
        return (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
          </svg>
        );
      case 'home':
        return (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
          </svg>
        );
      default:
        return (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
          </svg>
        );
    }
  };

  // Default "coming soon" achievements to show if user has less than 4 achievements
  const comingSoonAchievements = [
    { id: 'coming-1', title: 'Coming Soon' },
    { id: 'coming-2', title: 'Coming Soon' },
    { id: 'coming-3', title: 'Coming Soon' },
    { id: 'coming-4', title: 'Coming Soon' }
  ];
  
  // Combine earned achievements with placeholders if needed
  const displayAchievements = [...achievements];
  if (achievements.length < 4) {
    const neededPlaceholders = 4 - achievements.length;
    displayAchievements.push(...comingSoonAchievements.slice(0, neededPlaceholders));
  }

  return (
    <div className="mb-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold text-gray-900">Recent Achievements</h2>
        <a href="#" className="text-primary text-sm">All Badges</a>
      </div>
      
      <div className="flex space-x-4 overflow-x-auto pb-2">
        {displayAchievements.map((item, index) => {
          const isEarned = 'achievement' in item;
          const achievement = isEarned ? item.achievement : item;
          
          return (
            <div key={isEarned ? item.id : `placeholder-${index}`} className="flex flex-col items-center w-20 flex-shrink-0">
              <div className={`h-16 w-16 ${isEarned ? `bg-${achievement.color.substring(1)}-100` : 'bg-gray-100'} rounded-full flex items-center justify-center`}>
                <div 
                  className={`h-12 w-12 ${isEarned ? `bg-${achievement.color}` : 'bg-gray-300'} rounded-full flex items-center justify-center`}
                  style={{ backgroundColor: isEarned ? achievement.color : undefined }}
                >
                  {isEarned ? (
                    renderIcon(achievement.icon)
                  ) : (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                    </svg>
                  )}
                </div>
              </div>
              <span className="text-xs text-gray-700 mt-2 text-center">{achievement.title}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Achievements;
