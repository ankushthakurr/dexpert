import { useLocation } from 'wouter';

interface ProgressOverviewProps {
  progressData: any[];
  modules: any[];
}

const ProgressOverview = ({ progressData, modules }: ProgressOverviewProps) => {
  const [_, navigate] = useLocation();

  // Find the module with the highest progress that's not completed
  const getCurrentModule = () => {
    if (!progressData || !modules || progressData.length === 0 || modules.length === 0) {
      return modules?.[0] || null;
    }

    // Group progress by module and get the maximum progress for each
    const moduleProgress = new Map();
    progressData.forEach(progress => {
      const current = moduleProgress.get(progress.moduleId) || 0;
      moduleProgress.set(progress.moduleId, Math.max(current, progress.progress));
    });

    // Find incomplete modules, sorted by progress (highest first)
    const incompleteModules = Array.from(moduleProgress.entries())
      .filter(([moduleId, progress]) => progress < 100)
      .sort(([moduleIdA, a], [moduleIdB, b]) => b - a);

    if (incompleteModules.length > 0) {
      const [moduleId] = incompleteModules[0];
      return modules.find(module => module.id === moduleId);
    }

    // If all modules complete or no progress, return the first module
    return modules[0];
  };

  const currentModule = getCurrentModule();
  
  if (!currentModule) {
    return (
      <div className="bg-primary rounded-2xl p-5 text-white mb-6">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-semibold">No modules available</h2>
        </div>
        <p className="mb-3">Start your training journey by selecting a module.</p>
      </div>
    );
  }

  // Get the progress for the current module
  const moduleProgress = progressData?.find(p => p.moduleId === currentModule.id);
  const progress = moduleProgress?.progress || 0;
  const level = currentModule?.level || 1;
  
  // Calculate completed tasks (for display only)
  const tasksCompleted = Math.round(progress / 20); // Assuming 5 tasks per module
  const totalTasks = 5;

  return (
    <div className="bg-primary rounded-2xl p-5 text-white mb-6">
      <div className="flex items-center justify-between mb-3">
        <h2 className="font-semibold">Current Progress</h2>
        <span className="text-xs bg-white bg-opacity-20 py-1 px-2 rounded-full">Level {level}</span>
      </div>
      
      <div className="flex items-center mb-3">
        <div className="relative h-16 w-16 mr-4">
          <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
            <path className="stroke-white stroke-2 opacity-25 fill-none" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
            <path 
              className="stroke-white stroke-2 fill-none" 
              strokeDasharray={`${progress}, 100`} 
              d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" 
            />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center text-lg font-semibold">{progress}%</div>
        </div>
        <div>
          <h3 className="font-medium">{currentModule.title}</h3>
          <p className="text-sm text-white text-opacity-80">{tasksCompleted} of {totalTasks} tasks completed</p>
          <div className="mt-1">
            {Array.from({ length: totalTasks }).map((_, i) => (
              <span 
                key={i}
                className={`inline-block ${i < tasksCompleted ? 'bg-yellow-400' : 'bg-white bg-opacity-30'} h-5 w-5 rounded-full mr-1`}
              ></span>
            ))}
          </div>
        </div>
      </div>
      
      <button 
        className="w-full bg-white text-primary font-medium py-2 px-4 rounded-xl transition duration-200 mt-2"
        onClick={() => navigate(`/training/${currentModule.id}`)}
      >
        Continue Training
      </button>
    </div>
  );
};

export default ProgressOverview;
