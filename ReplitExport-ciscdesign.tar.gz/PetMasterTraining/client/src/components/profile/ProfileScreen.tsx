import { useLocation } from 'wouter';
import { useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import { User, Pet } from '@/App';
import UserProfile from './UserProfile';
import PetProfile from './PetProfile';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";

interface ProfileScreenProps {
  user: User;
  pet: Pet | null;
  onLogout: () => void;
}

const ProfileScreen = ({ user, pet, onLogout }: ProfileScreenProps) => {
  const [_, navigate] = useLocation();
  const { toast } = useToast();
  
  const handleEditProfile = () => {
    toast({
      title: "Feature coming soon",
      description: "Profile editing will be available in the next update"
    });
  };

  const handleEditPet = () => {
    toast({
      title: "Feature coming soon",
      description: "Pet profile editing will be available in the next update"
    });
  };

  const handleSettingsClick = (setting: string) => {
    toast({
      title: `${setting} settings`,
      description: "This feature will be available in the next update"
    });
  };

  return (
    <div className="p-6">
      <h1 className="text-xl font-semibold text-gray-900 mb-6">Profile</h1>
      
      {/* User Profile */}
      <UserProfile 
        user={user} 
        onEdit={handleEditProfile} 
      />
      
      {/* Pet Profile */}
      {pet && (
        <PetProfile 
          pet={pet}
          onEdit={handleEditPet}
        />
      )}
      
      {/* Settings */}
      <div className="mb-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Settings</h2>
        
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
          <div className="border-b border-gray-200">
            <button 
              className="flex justify-between items-center w-full p-4 text-left"
              onClick={() => handleSettingsClick('Notifications')}
            >
              <span className="text-gray-900">Notifications</span>
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </div>
          
          <div className="border-b border-gray-200">
            <button 
              className="flex justify-between items-center w-full p-4 text-left"
              onClick={() => handleSettingsClick('Payment Methods')}
            >
              <span className="text-gray-900">Payment Methods</span>
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </div>
          
          <div className="border-b border-gray-200">
            <button 
              className="flex justify-between items-center w-full p-4 text-left"
              onClick={() => navigate('/subscription')}
            >
              <span className="text-gray-900">Subscription</span>
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </div>
          
          <div>
            <button 
              className="flex justify-between items-center w-full p-4 text-left"
              onClick={() => handleSettingsClick('Help & Support')}
            >
              <span className="text-gray-900">Help & Support</span>
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </div>
        </div>
      </div>
      
      {/* Logout Button */}
      <AlertDialog>
        <AlertDialogTrigger asChild>
          <button className="w-full bg-white hover:bg-gray-50 text-red-500 font-medium py-3 px-4 rounded-xl border border-gray-300 transition duration-200">
            Log Out
          </button>
        </AlertDialogTrigger>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure you want to log out?</AlertDialogTitle>
            <AlertDialogDescription>
              You will need to log in again to access your account.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={onLogout} className="bg-red-500 hover:bg-red-600">
              Log Out
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default ProfileScreen;
