import { User } from '@/App';
import { formatDistanceToNow } from 'date-fns';

interface UserProfileProps {
  user: User;
  onEdit: () => void;
}

const UserProfile = ({ user, onEdit }: UserProfileProps) => {
  // Format the trial end date
  const formatTrialEnd = () => {
    if (!user.trialEndDate) return 'No trial';
    
    const trialEndDate = new Date(user.trialEndDate);
    const now = new Date();
    
    if (trialEndDate < now) {
      return 'Trial ended';
    }
    
    return `${formatDistanceToNow(trialEndDate, { addSuffix: true })}`;
  };

  return (
    <div className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm mb-6">
      <div className="flex items-center mb-4">
        <div className="h-16 w-16 bg-primary rounded-full flex items-center justify-center text-white mr-4">
          <span className="text-xl font-bold">{user.name?.charAt(0) || user.username.charAt(0)}</span>
        </div>
        <div>
          <h2 className="font-semibold text-gray-900">{user.name || user.username}</h2>
          <p className="text-gray-600">{user.email}</p>
          <div className="flex items-center mt-1">
            <span className={`text-xs bg-primary bg-opacity-10 text-primary py-0.5 px-2 rounded-full`}>
              {user.subscriptionPlan.charAt(0).toUpperCase() + user.subscriptionPlan.slice(1)} Plan
            </span>
            {user.trialEndDate && (
              <span className="text-xs text-gray-500 ml-2">{formatTrialEnd()}</span>
            )}
          </div>
        </div>
      </div>
      
      <button 
        className="w-full bg-gray-100 hover:bg-gray-200 text-gray-700 font-medium py-2 px-4 rounded-lg transition duration-200"
        onClick={onEdit}
      >
        Edit Profile
      </button>
    </div>
  );
};

export default UserProfile;
