import { Pet } from '@/App';

interface PetProfileProps {
  pet: Pet;
  onEdit: () => void;
}

const PetProfile = ({ pet, onEdit }: PetProfileProps) => {
  // Format pet age
  const formatAge = () => {
    if (!pet.age) return 'Age not specified';
    
    return `${pet.age} ${pet.ageUnit || 'months'}`;
  };

  // Capitalize training level
  const formatTrainingLevel = () => {
    if (!pet.trainingLevel) return 'Not specified';
    
    return pet.trainingLevel.charAt(0).toUpperCase() + pet.trainingLevel.slice(1);
  };

  return (
    <div className="mb-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold text-gray-900">Pet Profile</h2>
        <button className="text-primary text-sm" onClick={onEdit}>Edit</button>
      </div>
      
      <div className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm">
        <div className="flex items-center mb-4">
          {pet.imageUrl ? (
            <img 
              src={pet.imageUrl} 
              className="h-20 w-20 rounded-full object-cover mr-4" 
              alt={`${pet.name}'s profile`} 
            />
          ) : (
            <div className={`h-20 w-20 rounded-full mr-4 flex items-center justify-center text-white bg-${pet.type === 'dog' ? 'blue-500' : 'amber-500'}`}>
              <span className="text-xl font-bold">{pet.name.charAt(0)}</span>
            </div>
          )}
          <div>
            <h3 className="font-semibold text-gray-900">{pet.name}</h3>
            <p className="text-gray-600">{pet.breed || pet.type}</p>
          </div>
        </div>
        
        <div className="space-y-3 text-sm">
          <div className="flex">
            <span className="text-gray-500 w-24">Age:</span>
            <span className="text-gray-900">{formatAge()}</span>
          </div>
          <div className="flex">
            <span className="text-gray-500 w-24">Training Level:</span>
            <span className="text-gray-900">{formatTrainingLevel()}</span>
          </div>
          <div className="flex">
            <span className="text-gray-500 w-24">Health:</span>
            <span className="text-gray-900">{pet.healthNotes || 'Good condition'}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PetProfile;
