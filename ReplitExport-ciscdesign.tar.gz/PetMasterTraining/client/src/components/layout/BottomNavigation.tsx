import { useLocation } from 'wouter';
import { useMemo } from 'react';
import { motion } from 'framer-motion';

const BottomNavigation = () => {
  const [location, navigate] = useLocation();

  // Get the active path
  const activeRoute = useMemo(() => {
    if (location === '/') return 'home';
    if (location.startsWith('/training')) return 'training';
    if (location === '/chat') return 'chat';
    if (location === '/profile') return 'profile';
    return '';
  }, [location]);
  
  // Animation for the active indicator
  const activeIndicator = {
    home: { left: '12.5%' },
    training: { left: '37.5%' },
    chat: { left: '62.5%' },
    profile: { left: '87.5%' }
  };

  return (
    <motion.div 
      className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex items-center mx-auto max-w-md shadow-lg"
      initial={{ y: 100 }}
      animate={{ y: 0 }}
      transition={{ type: 'spring', stiffness: 260, damping: 20 }}
    >
      {/* Active tab indicator */}
      <motion.div 
        className="absolute top-0 w-1/4 h-1 bg-primary rounded-b-full"
        animate={activeRoute as any}
        variants={activeIndicator}
        initial={false}
        transition={{ type: "spring", stiffness: 500, damping: 30 }}
        style={{ left: '12.5%', transform: 'translateX(-50%)' }}
      />
      
      <NavButton 
        isActive={activeRoute === 'home'}
        label="Home"
        onClick={() => navigate('/')}
        icon={(active) => (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={active ? 2.5 : 2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
          </svg>
        )}
      />
      
      <NavButton 
        isActive={activeRoute === 'training'}
        label="Training"
        onClick={() => navigate('/training')}
        icon={(active) => (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={active ? 2.5 : 2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
          </svg>
        )}
      />
      
      <NavButton 
        isActive={activeRoute === 'chat'}
        label="Chat"
        onClick={() => navigate('/chat')}
        icon={(active) => (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={active ? 2.5 : 2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
          </svg>
        )}
      />
      
      <NavButton 
        isActive={activeRoute === 'profile'}
        label="Profile"
        onClick={() => navigate('/profile')}
        icon={(active) => (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={active ? 2.5 : 2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
          </svg>
        )}
      />
    </motion.div>
  );
};

// Individual nav button component
interface NavButtonProps {
  icon: (active: boolean) => React.ReactNode;
  label: string;
  isActive: boolean;
  onClick: () => void;
}

const NavButton = ({ icon, label, isActive, onClick }: NavButtonProps) => {
  return (
    <motion.button
      className={`flex-1 py-3 flex flex-col items-center justify-center relative ${isActive ? 'text-primary' : 'text-gray-500'}`}
      onClick={onClick}
      whileTap={{ scale: 0.9 }}
    >
      <motion.div
        animate={isActive ? { y: -5, scale: 1.1 } : { y: 0, scale: 1 }}
        transition={{ type: "spring", stiffness: 500, damping: 30 }}
      >
        {icon(isActive)}
      </motion.div>
      
      <motion.span 
        className="text-xs mt-1 font-medium"
        animate={isActive ? { opacity: 1 } : { opacity: 0.7 }}
      >
        {label}
      </motion.span>
      
      {isActive && (
        <motion.div
          className="absolute -bottom-3 h-1 w-8 bg-primary rounded-t-full opacity-0"
          initial={{ opacity: 0, scale: 0 }}
          animate={{ opacity: 0, scale: 0 }}
          exit={{ opacity: 0, scale: 0 }}
          transition={{ duration: 0.2 }}
        />
      )}
    </motion.button>
  );
};

export default BottomNavigation;
