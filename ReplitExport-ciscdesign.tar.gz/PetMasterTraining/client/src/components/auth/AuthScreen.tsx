import { useState } from 'react';
import SignUpForm from './SignUpForm';
import LoginForm from './LoginForm';
import { User } from '@/App';

interface AuthScreenProps {
  onLogin: (user: User) => void;
}

const AuthScreen = ({ onLogin }: AuthScreenProps) => {
  const [showSignUp, setShowSignUp] = useState(false);
  const [showLogin, setShowLogin] = useState(false);

  const handleSignUp = () => {
    setShowSignUp(true);
    setShowLogin(false);
  };

  const handleLogin = () => {
    setShowLogin(true);
    setShowSignUp(false);
  };

  const handleBackToMain = () => {
    setShowSignUp(false);
    setShowLogin(false);
  };

  // Main auth screen with buttons
  if (!showSignUp && !showLogin) {
    return (
      <div className="min-h-screen flex flex-col justify-between">
        {/* Logo & Intro */}
        <div className="p-6 pt-12 text-center">
          <div className="w-24 h-24 bg-primary rounded-full flex items-center justify-center mx-auto mb-6">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 10h4.764a2 2 0 011.789 2.894l-3.5 7A2 2 0 0115.263 21h-4.017c-.163 0-.326-.02-.485-.06L7 20m7-10V5a2 2 0 00-2-2h-.095c-.5 0-.905.405-.905.905a3.61 3.61 0 01-.608 2.006L7 11v9m7-10h-2M7 20H5a2 2 0 01-2-2v-6a2 2 0 012-2h2.5" />
            </svg>
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">PetTrainer Pro</h1>
          <p className="text-gray-600 mb-8">Your pet's training journey starts here!</p>
          
          <div className="bg-gray-100 rounded-xl p-4 mb-8">
            <div className="flex items-center mb-3">
              <div className="h-10 w-10 rounded-full bg-accent flex items-center justify-center flex-shrink-0">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <div className="ml-3">
                <h3 className="font-semibold text-gray-800">7-Day Free Trial</h3>
                <p className="text-sm text-gray-600">Try all features without commitment</p>
              </div>
            </div>
          </div>
        </div>
        
        {/* Auth Buttons */}
        <div className="p-6 pb-10">
          <button 
            className="w-full bg-primary hover:bg-blue-700 text-white font-medium py-3 px-4 rounded-xl mb-3 transition duration-200 shadow-sm"
            onClick={handleSignUp}
          >
            Sign up with email
          </button>
          <button 
            className="w-full bg-white hover:bg-gray-50 text-gray-700 font-medium py-3 px-4 rounded-xl border border-gray-300 mb-6 transition duration-200"
            onClick={handleLogin}
          >
            Login
          </button>
          
          <p className="text-sm text-center text-gray-500">
            By signing up, you agree to our <a href="#" className="text-primary">Terms</a> and <a href="#" className="text-primary">Privacy Policy</a>
          </p>
        </div>
      </div>
    );
  }

  // Show the appropriate form
  return (
    <div className="min-h-screen">
      {showSignUp && <SignUpForm onLogin={onLogin} onBackClick={handleBackToMain} />}
      {showLogin && <LoginForm onLogin={onLogin} onBackClick={handleBackToMain} />}
    </div>
  );
};

export default AuthScreen;
