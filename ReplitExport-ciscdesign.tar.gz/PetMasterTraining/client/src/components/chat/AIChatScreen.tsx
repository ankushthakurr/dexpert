import { useState, useEffect, useRef } from 'react';
import { useLocation } from 'wouter';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import ChatInput from './ChatInput';
import { User, Pet } from '@/App';

interface AIChatScreenProps {
  user: User;
  pet: Pet | null;
}

interface Message {
  id: number;
  userId: number;
  petId: number | null;
  message: string;
  isUserMessage: boolean;
  createdAt: string;
}

const AIChatScreen = ({ user, pet }: AIChatScreenProps) => {
  const [_, navigate] = useLocation();
  const { toast } = useToast();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [inputMessage, setInputMessage] = useState('');

  // Fetch chat messages
  const { data: messages, isLoading } = useQuery({
    queryKey: ['/api/chat/user', user.id, 'pet', pet?.id],
    queryFn: async () => {
      if (!pet) return [];
      return fetch(`/api/chat/user/${user.id}/pet/${pet.id}`).then(res => res.json());
    },
    enabled: !!pet,
  });

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (message: string) => {
      if (!pet) throw new Error('No pet selected');
      return apiRequest('POST', '/api/chat', {
        userId: user.id,
        petId: pet.id,
        message,
        isUserMessage: true
      });
    },
    onSuccess: () => {
      // Clear input and refetch messages
      setInputMessage('');
      queryClient.invalidateQueries({ queryKey: ['/api/chat/user', user.id, 'pet', pet?.id] });
    },
    onError: (error) => {
      toast({
        title: 'Failed to send message',
        description: error instanceof Error ? error.message : 'Please try again',
        variant: 'destructive',
      });
    }
  });

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Handle send message
  const handleSendMessage = () => {
    if (!inputMessage.trim()) return;
    sendMessageMutation.mutate(inputMessage);
  };

  // Handle quick reply
  const handleQuickReply = (reply: string) => {
    sendMessageMutation.mutate(reply);
  };

  // Initial greeting if no messages
  useEffect(() => {
    if (messages && messages.length === 0 && pet) {
      // Send an initial AI message
      apiRequest('POST', '/api/chat', {
        userId: user.id,
        petId: pet.id,
        message: `Hello ${user.name || user.username}! How can I help you and ${pet.name} today?`,
        isUserMessage: false
      }).then(() => {
        queryClient.invalidateQueries({ queryKey: ['/api/chat/user', user.id, 'pet', pet.id] });
      });
    }
  }, [messages, user, pet]);

  // Loading state
  if (isLoading || !pet) {
    return (
      <div className="p-6 pb-20">
        <div className="flex items-center mb-6">
          <button 
            className="h-10 w-10 rounded-full flex items-center justify-center bg-gray-100 mr-3"
            onClick={() => navigate('/')}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <h1 className="text-xl font-semibold text-gray-900">Pet Doctor AI</h1>
        </div>
        
        <div className="animate-pulse">
          <div className="h-20 bg-gray-200 rounded-xl mb-4"></div>
          <div className="h-16 w-3/4 bg-gray-200 rounded-xl mb-4"></div>
          <div className="h-16 w-3/4 ml-auto bg-gray-200 rounded-xl mb-4"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="pb-20">
      <div className="p-6">
        <div className="flex items-center mb-6">
          <button 
            className="h-10 w-10 rounded-full flex items-center justify-center bg-gray-100 mr-3"
            onClick={() => navigate('/')}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <h1 className="text-xl font-semibold text-gray-900">Pet Doctor AI</h1>
        </div>
        
        <div className="mb-4 bg-secondary bg-opacity-10 p-4 rounded-xl">
          <div className="flex">
            <div className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center mr-3 flex-shrink-0">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
              </svg>
            </div>
            <div>
              <h3 className="font-medium text-secondary mb-1">AI Pet Doctor Assistant</h3>
              <p className="text-sm text-gray-700">Ask me anything about pet training, health, or behavior. I'm here to help 24/7!</p>
            </div>
          </div>
        </div>
        
        {/* Chat Messages */}
        <div className="space-y-4">
          {messages && messages.map((message: Message) => (
            message.isUserMessage ? (
              // User Message
              <div key={message.id} className="flex items-start justify-end">
                <div className="bg-primary text-white rounded-xl p-3 max-w-[85%] chat-bubble-user">
                  <p>{message.message}</p>
                </div>
                <div className="h-8 w-8 rounded-full bg-gray-200 flex items-center justify-center ml-2 flex-shrink-0">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                  </svg>
                </div>
              </div>
            ) : (
              // AI Message
              <div key={message.id} className="flex items-start">
                <div className="h-8 w-8 rounded-full bg-secondary flex items-center justify-center mr-2 flex-shrink-0">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                  </svg>
                </div>
                <div className="bg-gray-100 rounded-xl p-3 max-w-[85%] chat-bubble-ai">
                  <p className="text-gray-800 whitespace-pre-line">{message.message}</p>
                </div>
              </div>
            )
          ))}
          <div ref={messagesEndRef} />
        </div>
        
        {/* Quick Reply Options - show only after AI's last message */}
        {messages && messages.length > 0 && !messages[messages.length - 1].isUserMessage && (
          <div className="flex flex-wrap gap-2 justify-center mt-4">
            <button 
              className="bg-gray-100 hover:bg-gray-200 text-gray-800 px-3 py-2 rounded-full text-sm transition duration-200"
              onClick={() => handleQuickReply("Can you give me breed-specific advice?")}
            >
              Breed-specific advice
            </button>
            <button 
              className="bg-gray-100 hover:bg-gray-200 text-gray-800 px-3 py-2 rounded-full text-sm transition duration-200"
              onClick={() => handleQuickReply("What toys do you recommend?")}
            >
              Toy recommendations
            </button>
            <button 
              className="bg-gray-100 hover:bg-gray-200 text-gray-800 px-3 py-2 rounded-full text-sm transition duration-200"
              onClick={() => handleQuickReply("Help with training exercises")}
            >
              Training exercises
            </button>
          </div>
        )}
      </div>
      
      {/* Chat Input */}
      <ChatInput 
        value={inputMessage}
        onChange={setInputMessage}
        onSend={handleSendMessage}
        isLoading={sendMessageMutation.isPending}
      />
    </div>
  );
};

export default AIChatScreen;
