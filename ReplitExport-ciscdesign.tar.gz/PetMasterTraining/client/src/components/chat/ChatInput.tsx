import { KeyboardEvent, useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { LoadingSpinner } from '@/components/ui/animations';

interface ChatInputProps {
  value: string;
  onChange: (value: string) => void;
  onSend: () => void;
  isLoading: boolean;
}

const ChatInput = ({ value, onChange, onSend, isLoading }: ChatInputProps) => {
  const [isFocused, setIsFocused] = useState(false);
  const [showEmoji, setShowEmoji] = useState(false);
  
  // Handle enter key press to send message
  const handleKeyPress = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      onSend();
    }
  };
  
  // Close emoji picker when clicking outside
  useEffect(() => {
    const handleClickOutside = () => {
      if (showEmoji) setShowEmoji(false);
    };
    
    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, [showEmoji]);
  
  // Common emoji suggestions
  const quickEmojis = ['🐶', '🐱', '👍', '❤️', '🎾', '🦴'];
  
  // Add emoji to input
  const addEmoji = (emoji: string) => {
    onChange(value + emoji);
  };

  return (
    <motion.div 
      className="fixed bottom-16 left-0 right-0 p-4 bg-white border-t border-gray-200 mx-auto max-w-md"
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.3 }}
    >
      <div className="relative">
        {/* Emoji quick picker */}
        <AnimatePresence>
          {showEmoji && (
            <motion.div 
              className="absolute bottom-full mb-2 bg-white rounded-xl shadow-lg p-2 border border-gray-200 w-full"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 10 }}
              transition={{ duration: 0.2 }}
            >
              <div className="flex flex-wrap gap-2 justify-around">
                {quickEmojis.map(emoji => (
                  <motion.button
                    key={emoji}
                    className="text-2xl p-2 hover:bg-gray-100 rounded-full"
                    whileHover={{ scale: 1.2 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={(e) => {
                      e.stopPropagation();
                      addEmoji(emoji);
                    }}
                  >
                    {emoji}
                  </motion.button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        
        <div className="flex items-center">
          <motion.div 
            className={`flex-1 bg-gray-100 rounded-xl flex items-center overflow-hidden ${isFocused ? 'ring-2 ring-primary ring-opacity-50' : ''}`}
            animate={{ boxShadow: isFocused ? '0px 4px 20px rgba(0, 0, 0, 0.1)' : '0px 2px 4px rgba(0, 0, 0, 0.05)' }}
            transition={{ duration: 0.3 }}
          >
            <input 
              type="text" 
              className="flex-1 px-4 py-3 bg-transparent focus:outline-none" 
              placeholder="Ask Pet Doctor..."
              value={value}
              onChange={(e) => onChange(e.target.value)}
              onKeyPress={handleKeyPress}
              onFocus={() => setIsFocused(true)}
              onBlur={() => setIsFocused(false)}
              disabled={isLoading}
            />
            <motion.button 
              className="p-3 text-gray-500"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={(e) => {
                e.stopPropagation();
                setShowEmoji(!showEmoji);
              }}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.828 14.828a4 4 0 01-5.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </motion.button>
          </motion.div>
          
          <motion.button 
            className={`ml-2 h-12 w-12 bg-primary rounded-full flex items-center justify-center text-white shadow-sm ${isLoading ? 'opacity-70' : 'hover:bg-blue-600'}`}
            onClick={onSend}
            disabled={isLoading}
            whileHover={!isLoading ? { scale: 1.05, boxShadow: '0px 5px 15px rgba(0, 0, 0, 0.1)' } : {}}
            whileTap={!isLoading ? { scale: 0.95 } : {}}
            initial={{ boxShadow: '0px 2px 5px rgba(0, 0, 0, 0.1)' }}
          >
            {isLoading ? (
              <LoadingSpinner size={20} color="text-white" />
            ) : (
              <motion.svg 
                xmlns="http://www.w3.org/2000/svg" 
                className="h-6 w-6" 
                fill="none" 
                viewBox="0 0 24 24" 
                stroke="currentColor"
                animate={{ x: [0, 5, 0] }}
                transition={{ duration: 1, repeat: Infinity, repeatType: "reverse" }}
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
              </motion.svg>
            )}
          </motion.button>
        </div>
      </div>
      
      {/* Voice input option - future feature */}
      {value === '' && !isLoading && (
        <motion.div 
          className="mt-2 flex justify-center items-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          <button className="text-xs text-gray-500 flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
            </svg>
            Tap to speak
          </button>
        </motion.div>
      )}
    </motion.div>
  );
};

export default ChatInput;
