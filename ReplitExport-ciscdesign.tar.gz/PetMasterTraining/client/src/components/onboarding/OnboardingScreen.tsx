import { useState } from 'react';
import PetProfileForm from './PetProfileForm';
import { User, Pet } from '@/App';

interface OnboardingScreenProps {
  user: User;
  onComplete: (pet: Pet) => void;
}

const OnboardingScreen = ({ user, onComplete }: OnboardingScreenProps) => {
  const [step, setStep] = useState(1);
  const totalSteps = 3;

  // For this implementation, we'll only use the first step
  // In a real app, you might have multiple onboarding steps

  return (
    <div className="min-h-screen flex flex-col">
      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-xl font-semibold">Pet Profile</h1>
          <div className="text-sm text-gray-500">Step {step} of {totalSteps}</div>
        </div>
        
        {/* Progress Bar */}
        <div className="h-2 bg-gray-200 rounded-full mb-8">
          <div 
            className="h-2 bg-primary rounded-full" 
            style={{width: `${(step / totalSteps) * 100}%`}}
          ></div>
        </div>
        
        {/* Pet Profile Form */}
        <PetProfileForm userId={user.id} onComplete={(pet) => {
          onComplete(pet);
          // In a real app with multiple steps:
          // if (step < totalSteps) {
          //   setStep(step + 1);
          // } else {
          //   onComplete(pet);
          // }
        }} />
      </div>
    </div>
  );
};

export default OnboardingScreen;
