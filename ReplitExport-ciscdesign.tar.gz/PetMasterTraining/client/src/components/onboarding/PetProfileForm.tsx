import { useState } from 'react';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Pet } from '@/App';

interface PetProfileFormProps {
  userId: number;
  onComplete: (pet: Pet) => void;
}

const petProfileSchema = z.object({
  name: z.string().min(1, { message: 'Pet name is required' }),
  type: z.string().min(1, { message: 'Pet type is required' }),
  breed: z.string().optional(),
  age: z.number().min(0).optional(),
  ageUnit: z.string().optional(),
  trainingLevel: z.string().default('beginner'),
  healthNotes: z.string().optional(),
  imageUrl: z.string().optional(),
});

const PetProfileForm = ({ userId, onComplete }: PetProfileFormProps) => {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [selectedPetType, setSelectedPetType] = useState<string | null>(null);

  const form = useForm<z.infer<typeof petProfileSchema>>({
    resolver: zodResolver(petProfileSchema),
    defaultValues: {
      name: '',
      type: '',
      breed: '',
      age: 0,
      ageUnit: 'months',
      trainingLevel: 'beginner',
      healthNotes: '',
      imageUrl: '',
    },
  });

  const onSubmit = async (values: z.infer<typeof petProfileSchema>) => {
    setIsLoading(true);
    try {
      const res = await apiRequest('POST', '/api/pets', {
        ...values,
        userId,
      });
      const petData: Pet = await res.json();
      toast({
        title: 'Pet profile created',
        description: `${petData.name} has been added to your profile`,
      });
      onComplete(petData);
    } catch (error) {
      console.error('Pet profile creation error:', error);
      toast({
        title: 'Failed to create pet profile',
        description: error instanceof Error ? error.message : 'Please try again',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const selectPetType = (type: string) => {
    setSelectedPetType(type);
    form.setValue('type', type);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)}>
        <div className="mb-6">
          <div className="flex justify-center mb-4">
            <div className="relative">
              <div className="w-24 h-24 bg-gray-200 rounded-full flex items-center justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
              </div>
              <button 
                type="button" 
                className="absolute bottom-0 right-0 bg-primary text-white p-1.5 rounded-full shadow-sm"
                onClick={() => toast({
                  title: "Feature coming soon",
                  description: "Image upload will be available in the next update"
                })}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                </svg>
              </button>
            </div>
          </div>
          
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem className="mb-4">
                <FormLabel>Pet Name</FormLabel>
                <FormControl>
                  <Input placeholder="e.g., Buddy" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <div className="mb-4">
            <FormLabel>Pet Type</FormLabel>
            <div className="grid grid-cols-2 gap-3">
              <div 
                className={`border ${selectedPetType === 'dog' ? 'border-primary' : 'border-gray-300'} hover:border-primary rounded-xl p-4 cursor-pointer transition duration-200 flex items-center`}
                onClick={() => selectPetType('dog')}
              >
                <div className={`h-8 w-8 ${selectedPetType === 'dog' ? 'bg-primary' : 'bg-gray-200'} rounded-full flex items-center justify-center mr-3`}>
                  {selectedPetType === 'dog' && (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  )}
                </div>
                <span className="font-medium">Dog</span>
              </div>
              
              <div 
                className={`border ${selectedPetType === 'cat' ? 'border-primary' : 'border-gray-300'} hover:border-primary rounded-xl p-4 cursor-pointer transition duration-200 flex items-center`}
                onClick={() => selectPetType('cat')}
              >
                <div className={`h-8 w-8 ${selectedPetType === 'cat' ? 'bg-primary' : 'bg-gray-200'} rounded-full flex items-center justify-center mr-3`}>
                  {selectedPetType === 'cat' && (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  )}
                </div>
                <span className="font-medium">Cat</span>
              </div>
            </div>
            {form.formState.errors.type && (
              <p className="text-sm font-medium text-destructive mt-2">{form.formState.errors.type.message}</p>
            )}
          </div>
          
          <FormField
            control={form.control}
            name="breed"
            render={({ field }) => (
              <FormItem className="mb-4">
                <FormLabel>Breed</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select breed" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {selectedPetType === 'dog' ? (
                      <>
                        <SelectItem value="Labrador Retriever">Labrador Retriever</SelectItem>
                        <SelectItem value="German Shepherd">German Shepherd</SelectItem>
                        <SelectItem value="Golden Retriever">Golden Retriever</SelectItem>
                        <SelectItem value="French Bulldog">French Bulldog</SelectItem>
                        <SelectItem value="Beagle">Beagle</SelectItem>
                        <SelectItem value="Poodle">Poodle</SelectItem>
                        <SelectItem value="Other">Other</SelectItem>
                      </>
                    ) : (
                      <>
                        <SelectItem value="Siamese">Siamese</SelectItem>
                        <SelectItem value="Persian">Persian</SelectItem>
                        <SelectItem value="Maine Coon">Maine Coon</SelectItem>
                        <SelectItem value="Bengal">Bengal</SelectItem>
                        <SelectItem value="Ragdoll">Ragdoll</SelectItem>
                        <SelectItem value="Other">Other</SelectItem>
                      </>
                    )}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <div className="mb-4">
            <FormLabel>Age</FormLabel>
            <div className="grid grid-cols-2 gap-3">
              <FormField
                control={form.control}
                name="age"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Input 
                        type="number" 
                        placeholder="Age" 
                        {...field}
                        onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="ageUnit"
                render={({ field }) => (
                  <FormItem>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Unit" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="months">Months</SelectItem>
                        <SelectItem value="years">Years</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </div>
          
          <FormField
            control={form.control}
            name="trainingLevel"
            render={({ field }) => (
              <FormItem className="mb-4">
                <FormLabel>Current Training Level</FormLabel>
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div 
                    className={`border ${field.value === 'beginner' ? 'border-primary bg-primary bg-opacity-10 text-primary' : 'border-gray-300'} rounded-xl py-2 px-1 cursor-pointer`}
                    onClick={() => field.onChange('beginner')}
                  >
                    Beginner
                  </div>
                  <div 
                    className={`border ${field.value === 'intermediate' ? 'border-primary bg-primary bg-opacity-10 text-primary' : 'border-gray-300'} rounded-xl py-2 px-1 cursor-pointer`}
                    onClick={() => field.onChange('intermediate')}
                  >
                    Intermediate
                  </div>
                  <div 
                    className={`border ${field.value === 'advanced' ? 'border-primary bg-primary bg-opacity-10 text-primary' : 'border-gray-300'} rounded-xl py-2 px-1 cursor-pointer`}
                    onClick={() => field.onChange('advanced')}
                  >
                    Advanced
                  </div>
                </div>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        
        <Button 
          type="submit" 
          className="w-full"
          disabled={isLoading}
        >
          {isLoading ? 'Creating profile...' : 'Continue'}
        </Button>
      </form>
    </Form>
  );
};

export default PetProfileForm;
