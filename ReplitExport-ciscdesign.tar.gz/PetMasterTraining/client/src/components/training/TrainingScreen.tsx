import { useParams, useLocation } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import TrainingModuleDetail from './TrainingModuleDetail';

interface TrainingScreenParams {
  moduleId?: string;
}

const TrainingScreen = () => {
  const params = useParams<TrainingScreenParams>();
  const [_, navigate] = useLocation();

  // Fetch all training modules
  const { data: trainingModules, isLoading: modulesLoading } = useQuery({
    queryKey: ['/api/training/modules'],
    queryFn: async () => {
      return fetch('/api/training/modules').then(res => res.json());
    },
  });

  // Redirect to first module if no moduleId is provided
  if (!params.moduleId && trainingModules && trainingModules.length > 0) {
    navigate(`/training/${trainingModules[0].id}`);
    return (
      <div className="p-6 flex justify-center items-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  // Show loading state
  if (modulesLoading || !trainingModules) {
    return (
      <div className="p-6">
        <div className="animate-pulse">
          <div className="flex items-center mb-6">
            <div className="h-10 w-10 bg-gray-200 rounded-full mr-3"></div>
            <div className="h-6 bg-gray-200 rounded w-1/2"></div>
          </div>
          <div className="h-40 bg-gray-200 rounded-xl mb-6"></div>
          <div className="h-6 bg-gray-200 rounded w-1/4 mb-3"></div>
          <div className="h-32 bg-gray-200 rounded-xl mb-6"></div>
          <div className="h-6 bg-gray-200 rounded w-1/4 mb-3"></div>
          <div className="h-32 bg-gray-200 rounded-xl"></div>
        </div>
      </div>
    );
  }

  // If no modules exist
  if (trainingModules.length === 0) {
    return (
      <div className="p-6">
        <div className="flex items-center mb-6">
          <button 
            className="h-10 w-10 rounded-full flex items-center justify-center bg-gray-100 mr-3"
            onClick={() => navigate('/')}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <h1 className="text-xl font-semibold text-gray-900">Training</h1>
        </div>
        <div className="bg-gray-100 rounded-xl p-8 text-center">
          <p className="text-gray-600">No training modules available yet.</p>
        </div>
      </div>
    );
  }

  // Find the module to display
  const moduleId = params.moduleId ? parseInt(params.moduleId) : trainingModules[0].id;
  const currentModule = trainingModules.find(module => module.id === moduleId);

  // If moduleId doesn't match any modules, show error
  if (!currentModule) {
    return (
      <div className="p-6">
        <div className="flex items-center mb-6">
          <button 
            className="h-10 w-10 rounded-full flex items-center justify-center bg-gray-100 mr-3"
            onClick={() => navigate('/')}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <h1 className="text-xl font-semibold text-gray-900">Training</h1>
        </div>
        <div className="bg-gray-100 rounded-xl p-8 text-center">
          <p className="text-gray-600">Training module not found.</p>
          <button 
            className="mt-4 px-4 py-2 bg-primary text-white rounded-lg"
            onClick={() => navigate('/')}
          >
            Go to Home
          </button>
        </div>
      </div>
    );
  }

  return <TrainingModuleDetail module={currentModule} />;
};

export default TrainingScreen;
