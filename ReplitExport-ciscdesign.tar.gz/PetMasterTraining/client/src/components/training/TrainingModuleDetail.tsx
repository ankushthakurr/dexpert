import { useState } from 'react';
import { useLocation } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { Check } from 'lucide-react';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface TrainingModuleDetailProps {
  module: any;
}

const TrainingModuleDetail = ({ module }: TrainingModuleDetailProps) => {
  const [_, navigate] = useLocation();
  const { toast } = useToast();
  const [checklist, setChecklist] = useState<{ id: string; title: string; completed: boolean }[]>([]);

  // Fetch lessons for the current module
  const { data: lessons, isLoading: lessonsLoading } = useQuery({
    queryKey: [`/api/training/modules/${module.id}/lessons`],
    queryFn: async () => {
      return fetch(`/api/training/modules/${module.id}/lessons`).then(res => res.json());
    },
  });

  // Find the first lesson (for the main video/content)
  const mainLesson = lessons && lessons.length > 0 ? lessons[0] : null;

  // Toggle checklist item
  const toggleChecklistItem = async (index: number) => {
    if (!mainLesson) return;

    const updatedChecklist = [...checklist];
    updatedChecklist[index].completed = !updatedChecklist[index].completed;
    setChecklist(updatedChecklist);

    // Calculate progress percentage
    const completedItems = updatedChecklist.filter(item => item.completed).length;
    const progressPercentage = Math.round((completedItems / updatedChecklist.length) * 100);

    try {
      // Get user info from localStorage
      const userJson = localStorage.getItem('user');
      const petJson = localStorage.getItem('pet');
      
      if (!userJson || !petJson) {
        toast({
          title: "Authentication error",
          description: "Please log in again",
          variant: "destructive"
        });
        return;
      }

      const user = JSON.parse(userJson);
      const pet = JSON.parse(petJson);

      // Update progress in the backend
      await apiRequest('POST', '/api/progress', {
        userId: user.id,
        petId: pet.id,
        moduleId: module.id,
        lessonId: mainLesson.id,
        progress: progressPercentage,
        checklist: updatedChecklist,
      });

      // Invalidate related queries to refresh data
      queryClient.invalidateQueries({ queryKey: [`/api/progress/user/${user.id}/pet/${pet.id}`] });
      queryClient.invalidateQueries({ queryKey: ['/api/progress/user', user.id, 'pet', pet.id] });

      toast({
        title: "Progress updated",
        description: `Training progress: ${progressPercentage}%`,
      });
    } catch (error) {
      console.error('Error updating progress:', error);
      toast({
        title: "Failed to update progress",
        description: "Please try again",
        variant: "destructive"
      });
    }
  };

  // Initialize checklist when lesson data is loaded
  useState(() => {
    if (mainLesson && mainLesson.instructions) {
      // Convert instructions to checklist items if not already a checklist
      if (Array.isArray(mainLesson.instructions)) {
        setChecklist(
          mainLesson.instructions.map((instruction: string, index: number) => ({
            id: `item-${index}`,
            title: instruction,
            completed: false
          }))
        );
      }
    }
  });

  // Show loading state
  if (lessonsLoading || !mainLesson) {
    return (
      <div className="p-6">
        <div className="flex items-center mb-6">
          <button 
            className="h-10 w-10 rounded-full flex items-center justify-center bg-gray-100 mr-3"
            onClick={() => navigate('/')}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <h1 className="text-xl font-semibold text-gray-900">{module.title}</h1>
        </div>
        <div className="animate-pulse">
          <div className="h-40 bg-gray-200 rounded-xl mb-6"></div>
          <div className="h-6 bg-gray-200 rounded w-1/4 mb-3"></div>
          <div className="h-32 bg-gray-200 rounded-xl mb-6"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex items-center mb-6">
        <button 
          className="h-10 w-10 rounded-full flex items-center justify-center bg-gray-100 mr-3"
          onClick={() => navigate('/')}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </button>
        <h1 className="text-xl font-semibold text-gray-900">{module.title}</h1>
      </div>
      
      {/* Training Video Section */}
      <div className="rounded-xl overflow-hidden mb-6 bg-black relative">
        <div className="aspect-video bg-gray-900 flex items-center justify-center">
          <button className="h-16 w-16 rounded-full bg-white bg-opacity-75 flex items-center justify-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </button>
        </div>
        <div className="absolute bottom-0 left-0 right-0 flex items-center justify-between p-3">
          <div className="text-white text-sm font-medium">{mainLesson.title}</div>
          <div className="text-white text-sm">
            {mainLesson.duration ? `${Math.floor(mainLesson.duration / 60)}:${(mainLesson.duration % 60).toString().padStart(2, '0')}` : '00:00'}
          </div>
        </div>
      </div>
      
      {/* Instructions */}
      <div className="mb-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-3">Instructions</h2>
        <div className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm">
          <ol className="list-decimal pl-5 space-y-3 text-gray-700">
            {mainLesson.instructions && Array.isArray(mainLesson.instructions) && mainLesson.instructions.map((instruction: string, index: number) => (
              <li key={index}>{instruction}</li>
            ))}
          </ol>
        </div>
      </div>
      
      {/* Checklist */}
      <div className="mb-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-3">Daily Practice Checklist</h2>
        <div className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm">
          <div className="space-y-3">
            {checklist.map((item, index) => (
              <div 
                key={item.id} 
                className="flex items-center cursor-pointer"
                onClick={() => toggleChecklistItem(index)}
              >
                <div className={`h-6 w-6 border-2 border-primary rounded mr-3 flex items-center justify-center ${item.completed ? 'bg-primary' : ''}`}>
                  {item.completed && (
                    <Check className="h-4 w-4 text-white" />
                  )}
                </div>
                <span className="text-gray-700">{item.title}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
      
      {/* Tips */}
      {mainLesson.tips && mainLesson.tips.length > 0 && (
        <div className="mb-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-3">Tips from Trainers</h2>
          <div className="bg-yellow-50 rounded-xl border border-yellow-200 p-4">
            <div className="flex">
              <div className="h-10 w-10 rounded-full bg-yellow-100 flex items-center justify-center mr-3 flex-shrink-0">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-yellow-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                </svg>
              </div>
              <div>
                {mainLesson.tips.map((tip: { title: string; description: string }, index: number) => (
                  <div key={index}>
                    <h3 className="font-medium text-yellow-800 mb-1">{tip.title}</h3>
                    <p className="text-sm text-yellow-700">{tip.description}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Next Steps - Display next lessons if available */}
      {lessons && lessons.length > 1 && (
        <div>
          <div className="flex justify-between items-center mb-3">
            <h2 className="text-lg font-semibold text-gray-900">What's Next</h2>
          </div>
          
          <div className="flex space-x-4 overflow-x-auto pb-2">
            {lessons.slice(1, 3).map((lesson: any) => (
              <div key={lesson.id} className="bg-white rounded-xl border border-gray-200 shadow-sm p-4 w-48 flex-shrink-0">
                <div className={`h-10 w-10 ${lesson.id === mainLesson.id + 1 ? 'bg-primary' : 'bg-gray-200'} rounded-full flex items-center justify-center mb-3`}>
                  {lesson.id === mainLesson.id + 1 ? (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                    </svg>
                  ) : (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                    </svg>
                  )}
                </div>
                <h3 className="font-medium text-gray-900 mb-1">{lesson.title}</h3>
                <p className="text-sm text-gray-600 mb-3">{lesson.description}</p>
                <div className="flex items-center text-xs text-gray-500">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <span>
                    {lesson.duration ? `${Math.floor(lesson.duration / 60)} min lesson` : 'Coming soon'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default TrainingModuleDetail;
