interface PlanCardProps {
  plan: {
    id: string;
    name: string;
    description: string;
    price: number;
    popular: boolean;
    features: string[];
  };
  isSelected: boolean;
  isCurrentPlan: boolean;
  onSelect: () => void;
}

const PlanCard = ({ plan, isSelected, isCurrentPlan, onSelect }: PlanCardProps) => {
  return (
    <div 
      className={`border-2 rounded-xl bg-white ${isSelected ? 'border-primary' : 'border-gray-200'}`}
      onClick={!isCurrentPlan ? onSelect : undefined}
    >
      <div className="p-4">
        <div className="flex justify-between items-start mb-3">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">{plan.name}</h3>
            <p className="text-sm text-gray-600">{plan.description}</p>
          </div>
          {plan.popular && (
            <div className="bg-primary text-white text-xs font-medium py-1 px-2 rounded-full">
              POPULAR
            </div>
          )}
        </div>
        
        <div className="flex items-baseline mb-4">
          <span className="text-2xl font-bold text-gray-900">${plan.price}</span>
          <span className="text-gray-600 ml-1">/month</span>
        </div>
        
        <ul className="space-y-2 mb-4">
          {plan.features.map((feature, index) => (
            <li key={index} className="flex items-center text-gray-700">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-success mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              {feature}
            </li>
          ))}
        </ul>
      </div>
      
      <div className="border-t border-gray-200 p-4">
        <button 
          className={`w-full font-medium py-3 px-4 rounded-xl transition duration-200 ${
            isCurrentPlan 
              ? 'bg-gray-100 text-gray-400 cursor-not-allowed' 
              : isSelected 
                ? 'bg-primary hover:bg-blue-700 text-white' 
                : 'bg-white hover:bg-gray-50 text-gray-700 border border-gray-300'
          }`}
          disabled={isCurrentPlan}
        >
          {isCurrentPlan ? 'Current Plan' : isSelected ? 'Selected' : 'Select Plan'}
        </button>
      </div>
    </div>
  );
};

export default PlanCard;
