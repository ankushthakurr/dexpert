import { useLocation } from 'wouter';
import { useState, useMemo } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { User } from '@/App';
import PlanCard from './PlanCard';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { differenceInDays } from 'date-fns';

interface SubscriptionScreenProps {
  user: User;
  setUser: (user: User) => void;
}

interface Plan {
  id: string;
  name: string;
  description: string;
  price: number;
  popular: boolean;
  features: string[];
}

const SubscriptionScreen = ({ user, setUser }: SubscriptionScreenProps) => {
  const [_, navigate] = useLocation();
  const { toast } = useToast();
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  // Calculate days remaining in trial
  const daysRemaining = useMemo(() => {
    if (!user.trialEndDate) return 0;
    
    const endDate = new Date(user.trialEndDate);
    const today = new Date();
    const days = differenceInDays(endDate, today);
    
    return Math.max(0, days);
  }, [user.trialEndDate]);

  // Trial progress as percentage
  const trialProgress = Math.max(0, Math.min(100, ((7 - daysRemaining) / 7) * 100));

  // Define available plans
  const plans: Plan[] = [
    {
      id: 'basic',
      name: 'Basic Plan',
      description: 'Essential training tools',
      price: 10,
      popular: true,
      features: [
        'All basic training modules',
        'AI chat assistant',
        'Progress tracking',
        'Community forums'
      ]
    },
    {
      id: 'advanced',
      name: 'Advanced Plan',
      description: 'Professional training support',
      price: 25,
      popular: false,
      features: [
        'All Basic Plan features',
        'Weekly live trainer session',
        'Premium training content',
        'Priority support',
        'Additional sessions ($10/session)'
      ]
    }
  ];

  // Select plan mutation
  const selectPlanMutation = useMutation({
    mutationFn: async (plan: string) => {
      setIsProcessing(true);
      return apiRequest('POST', '/api/subscription/select', {
        userId: user.id,
        plan
      });
    },
    onSuccess: async (response) => {
      const updatedUser = await response.json();
      
      // Update user in context and localStorage
      setUser(updatedUser);
      localStorage.setItem('user', JSON.stringify(updatedUser));
      
      toast({
        title: 'Subscription Updated',
        description: `You are now on the ${updatedUser.subscriptionPlan} plan`,
      });
      
      setIsProcessing(false);
      setTimeout(() => navigate('/'), 1000);
    },
    onError: (error) => {
      setIsProcessing(false);
      toast({
        title: 'Failed to update subscription',
        description: error instanceof Error ? error.message : 'Please try again',
        variant: 'destructive',
      });
    }
  });

  const handleSelectPlan = (planId: string) => {
    setSelectedPlan(planId);
  };

  const handleConfirmPlan = () => {
    if (selectedPlan) {
      selectPlanMutation.mutate(selectedPlan);
    }
  };

  return (
    <div className="p-6">
      <div className="flex items-center mb-6">
        <button 
          className="h-10 w-10 rounded-full flex items-center justify-center bg-gray-100 mr-3"
          onClick={() => navigate('/')}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </button>
        <h1 className="text-xl font-semibold text-gray-900">Subscription Plans</h1>
      </div>
      
      {/* Free Trial Banner */}
      <div className="bg-gradient-to-r from-primary to-secondary rounded-xl p-4 text-white mb-6">
        <div className="flex items-start">
          <div className="h-12 w-12 bg-white bg-opacity-20 rounded-full flex items-center justify-center mr-3 flex-shrink-0">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <div>
            <h3 className="font-semibold mb-1">Your Free Trial</h3>
            <p className="text-sm text-white text-opacity-90 mb-2">
              {daysRemaining > 0 
                ? `${daysRemaining} days remaining of your 7-day trial` 
                : 'Your free trial has ended'}
            </p>
            <div className="h-1.5 bg-white bg-opacity-20 rounded-full mb-2">
              <div 
                className="h-1.5 bg-white rounded-full" 
                style={{ width: `${trialProgress}%` }}
              ></div>
            </div>
            <p className="text-xs text-white text-opacity-80">Full access to all features</p>
          </div>
        </div>
      </div>
      
      {/* Subscription Options */}
      <div className="space-y-4 mb-6">
        {plans.map(plan => (
          <PlanCard
            key={plan.id}
            plan={plan}
            isSelected={selectedPlan === plan.id}
            isCurrentPlan={user.subscriptionPlan === plan.id}
            onSelect={() => handleSelectPlan(plan.id)}
          />
        ))}
      </div>
      
      {/* Select Plan Button */}
      {selectedPlan && (
        <button 
          className={`w-full mb-6 font-medium py-3 px-4 rounded-xl transition duration-200 ${
            isProcessing 
              ? 'bg-gray-300 text-gray-600 cursor-not-allowed' 
              : 'bg-primary hover:bg-blue-700 text-white shadow-sm'
          }`}
          onClick={handleConfirmPlan}
          disabled={isProcessing}
        >
          {isProcessing ? 'Processing...' : 'Confirm Subscription'}
        </button>
      )}
      
      {/* FAQ Section */}
      <div>
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Frequently Asked Questions</h2>
        
        <Accordion type="single" collapsible className="space-y-3">
          <AccordionItem value="item-1" className="border border-gray-200 rounded-xl overflow-hidden">
            <AccordionTrigger className="px-4 py-3 hover:no-underline">
              <span className="font-medium text-gray-900">Can I cancel anytime?</span>
            </AccordionTrigger>
            <AccordionContent className="px-4 pb-3 pt-0">
              <p className="text-gray-600">Yes, you can cancel your subscription at any time. Your subscription will remain active until the end of your current billing period.</p>
            </AccordionContent>
          </AccordionItem>
          
          <AccordionItem value="item-2" className="border border-gray-200 rounded-xl overflow-hidden">
            <AccordionTrigger className="px-4 py-3 hover:no-underline">
              <span className="font-medium text-gray-900">How do live sessions work?</span>
            </AccordionTrigger>
            <AccordionContent className="px-4 pb-3 pt-0">
              <p className="text-gray-600">With the Advanced Plan, you get one weekly session with a certified trainer via video call. You can book additional sessions for $10 each.</p>
            </AccordionContent>
          </AccordionItem>
          
          <AccordionItem value="item-3" className="border border-gray-200 rounded-xl overflow-hidden">
            <AccordionTrigger className="px-4 py-3 hover:no-underline">
              <span className="font-medium text-gray-900">What breeds are supported?</span>
            </AccordionTrigger>
            <AccordionContent className="px-4 pb-3 pt-0">
              <p className="text-gray-600">PetTrainer Pro supports all dog and cat breeds. Our training programs are adaptable to various breeds with specific tips for common breed-specific behaviors.</p>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </div>
    </div>
  );
};

export default SubscriptionScreen;
