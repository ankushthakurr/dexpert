import { FC, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface AchievementBadgeProps {
  title: string;
  description: string;
  icon?: string;
  color?: string;
  earned?: boolean;
  earnedDate?: string;
  onClick?: () => void;
}

const AchievementBadge: FC<AchievementBadgeProps> = ({
  title,
  description,
  icon,
  color = 'bg-yellow-500',
  earned = false,
  earnedDate,
  onClick
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  
  const handleClick = () => {
    setIsExpanded(!isExpanded);
    if (onClick) onClick();
  };

  return (
    <div className="mb-3">
      <motion.div
        className={`rounded-xl ${earned ? color : 'bg-gray-200'} p-4 cursor-pointer transition-shadow`}
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        onClick={handleClick}
        layout
      >
        <div className="flex items-center">
          <div className={`rounded-full ${earned ? 'bg-white bg-opacity-20' : 'bg-gray-300'} h-12 w-12 flex items-center justify-center mr-3`}>
            {icon ? (
              <span className="text-white text-xl">{icon}</span>
            ) : (
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
              </svg>
            )}
          </div>
          <div className="flex-1">
            <h3 className={`font-semibold ${earned ? 'text-white' : 'text-gray-500'}`}>{title}</h3>
            
            <AnimatePresence>
              {isExpanded && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <p className={`text-sm mt-1 ${earned ? 'text-white text-opacity-80' : 'text-gray-400'}`}>
                    {description}
                  </p>
                  
                  {earned && earnedDate && (
                    <p className="text-xs mt-2 text-white text-opacity-60">
                      Earned: {new Date(earnedDate).toLocaleDateString()}
                    </p>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
          
          <motion.div
            animate={{ rotate: isExpanded ? 180 : 0 }}
            transition={{ duration: 0.3 }}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 ${earned ? 'text-white' : 'text-gray-400'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
            </svg>
          </motion.div>
        </div>
        
        {!earned && (
          <motion.div 
            className="mt-2 bg-white bg-opacity-10 rounded-lg p-2 text-xs text-gray-500 font-medium"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            Complete required training to unlock this achievement
          </motion.div>
        )}
      </motion.div>
    </div>
  );
};

export default AchievementBadge;