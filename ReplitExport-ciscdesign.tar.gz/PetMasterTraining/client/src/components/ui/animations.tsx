import { FC } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useSpring, animated } from 'react-spring';

// Framer Motion animations
export const fadeIn = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { duration: 0.5 } }
};

export const slideInFromBottom = {
  hidden: { y: 50, opacity: 0 },
  visible: { y: 0, opacity: 1, transition: { type: 'spring', stiffness: 300, damping: 30 } }
};

export const slideInFromRight = {
  hidden: { x: 100, opacity: 0 },
  visible: { x: 0, opacity: 1, transition: { type: 'spring', stiffness: 300, damping: 30 } }
};

export const slideInFromLeft = {
  hidden: { x: -100, opacity: 0 },
  visible: { x: 0, opacity: 1, transition: { type: 'spring', stiffness: 300, damping: 30 } }
};

export const popIn = {
  hidden: { scale: 0.8, opacity: 0 },
  visible: { scale: 1, opacity: 1, transition: { type: 'spring', stiffness: 500, damping: 30 } }
};

export const staggerChildren = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

// Animation components
interface AnimatedContainerProps {
  children: React.ReactNode;
  animation?: 'fadeIn' | 'slideInFromBottom' | 'slideInFromRight' | 'slideInFromLeft' | 'popIn';
  delay?: number;
  className?: string;
}

export const AnimatedContainer: FC<AnimatedContainerProps> = ({ 
  children, 
  animation = 'fadeIn',
  delay = 0,
  className = ''
}) => {
  const getVariant = () => {
    switch (animation) {
      case 'fadeIn': return fadeIn;
      case 'slideInFromBottom': return slideInFromBottom;
      case 'slideInFromRight': return slideInFromRight;
      case 'slideInFromLeft': return slideInFromLeft;
      case 'popIn': return popIn;
      default: return fadeIn;
    }
  };

  return (
    <motion.div
      className={className}
      variants={getVariant()}
      initial="hidden"
      animate="visible"
      transition={{
        delay
      }}
    >
      {children}
    </motion.div>
  );
};

// Staggered container that animates children in sequence
interface StaggeredContainerProps {
  children: React.ReactNode;
  className?: string;
  delay?: number;
  staggerDelay?: number;
}

export const StaggeredContainer: FC<StaggeredContainerProps> = ({ 
  children, 
  className = '',
  delay = 0,
  staggerDelay = 0.1
}) => {
  return (
    <motion.div
      className={className}
      variants={{
        hidden: { opacity: 0 },
        visible: {
          opacity: 1,
          transition: {
            delayChildren: delay,
            staggerChildren: staggerDelay
          }
        }
      }}
      initial="hidden"
      animate="visible"
    >
      {children}
    </motion.div>
  );
};

// Animated list item that works with StaggeredContainer
interface StaggeredItemProps {
  children: React.ReactNode;
  className?: string;
}

export const StaggeredItem: FC<StaggeredItemProps> = ({ children, className = '' }) => {
  return (
    <motion.div
      className={className}
      variants={{
        hidden: { y: 20, opacity: 0 },
        visible: {
          y: 0,
          opacity: 1,
          transition: {
            type: 'spring',
            stiffness: 300,
            damping: 24
          }
        }
      }}
    >
      {children}
    </motion.div>
  );
};

// Loading spinner component
interface LoadingSpinnerProps {
  size?: number;
  color?: string;
  thickness?: number;
}

export const LoadingSpinner: FC<LoadingSpinnerProps> = ({ 
  size = 24, 
  color = 'text-primary',
  thickness = 4
}) => {
  return (
    <svg 
      className={`animate-spin ${color}`} 
      width={size} 
      height={size} 
      xmlns="http://www.w3.org/2000/svg" 
      fill="none" 
      viewBox="0 0 24 24"
    >
      <circle 
        className="opacity-25" 
        cx="12" 
        cy="12" 
        r="10" 
        stroke="currentColor" 
        strokeWidth={thickness}
      />
      <path 
        className="opacity-75" 
        fill="currentColor" 
        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
      />
    </svg>
  );
};

// Bouncy text animation
interface BouncyTextProps {
  text: string;
  className?: string;
  delay?: number;
}

export const BouncyText: FC<BouncyTextProps> = ({ 
  text, 
  className = '',
  delay = 0
}) => {
  return (
    <div className={`flex ${className}`}>
      {text.split('').map((char, index) => (
        <motion.span
          key={index}
          initial={{ y: 0 }}
          animate={{ y: [0, -10, 0] }}
          transition={{
            delay: delay + index * 0.05,
            duration: 0.6,
            repeat: 0,
            repeatType: 'loop',
            ease: 'easeInOut'
          }}
        >
          {char === ' ' ? '\u00A0' : char}
        </motion.span>
      ))}
    </div>
  );
};

// Growing progress bar
interface ProgressBarProps {
  progress: number; // 0 to 100
  className?: string;
  height?: number;
  color?: string;
  backgroundColor?: string;
  animated?: boolean;
}

export const ProgressBar: FC<ProgressBarProps> = ({ 
  progress, 
  className = '',
  height = 8,
  color = 'bg-primary',
  backgroundColor = 'bg-gray-200',
  animated = true
}) => {
  const springProps = useSpring({
    width: `${progress}%`,
    config: { tension: 300, friction: 20 }
  });

  if (!animated) {
    return (
      <div 
        className={`${backgroundColor} rounded-full overflow-hidden ${className}`} 
        style={{ height }}
      >
        <div 
          className={`${color} h-full`} 
          style={{ width: `${progress}%` }}
        />
      </div>
    );
  }

  return (
    <div 
      className={`${backgroundColor} rounded-full overflow-hidden ${className}`} 
      style={{ height }}
    >
      <animated.div 
        className={`${color} h-full`} 
        style={springProps}
      />
    </div>
  );
};

// Fade transition for conditional rendering
interface FadeTransitionProps {
  show: boolean;
  children: React.ReactNode;
  className?: string;
}

export const FadeTransition: FC<FadeTransitionProps> = ({ 
  show, 
  children,
  className = ''
}) => {
  return (
    <AnimatePresence>
      {show && (
        <motion.div
          className={className}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
        >
          {children}
        </motion.div>
      )}
    </AnimatePresence>
  );
};

// Page transition wrapper
export const PageTransition: FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 20 }}
      transition={{ duration: 0.3 }}
    >
      {children}
    </motion.div>
  );
};

// Pulse animation for attention
interface PulseProps {
  children: React.ReactNode;
  pulsing?: boolean;
  className?: string;
}

export const Pulse: FC<PulseProps> = ({ 
  children, 
  pulsing = true,
  className = ''
}) => {
  return (
    <motion.div
      className={className}
      animate={pulsing ? { scale: [1, 1.05, 1] } : { scale: 1 }}
      transition={{ 
        duration: 2, 
        repeat: pulsing ? Infinity : 0,
        repeatType: 'loop'
      }}
    >
      {children}
    </motion.div>
  );
};

// Success checkmark animation
export const SuccessCheckmark: FC<{ size?: number, color?: string }> = ({ 
  size = 100,
  color = '#4CAF50'
}) => {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 100 100"
    >
      <motion.circle
        cx="50"
        cy="50"
        r="45"
        fill="none"
        stroke={color}
        strokeWidth="4"
        initial={{ pathLength: 0, opacity: 0 }}
        animate={{ pathLength: 1, opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      />
      <motion.path
        d="M30 50 L45 65 L70 35"
        fill="none"
        stroke={color}
        strokeWidth="6"
        strokeLinecap="round"
        strokeLinejoin="round"
        initial={{ pathLength: 0, opacity: 0 }}
        animate={{ pathLength: 1, opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.8 }}
      />
    </svg>
  );
};

// Shake animation (useful for error states)
interface ShakeProps {
  children: React.ReactNode;
  shake: boolean;
  className?: string;
  onComplete?: () => void;
}

export const Shake: FC<ShakeProps> = ({ 
  children, 
  shake,
  className = '',
  onComplete
}) => {
  return (
    <motion.div
      className={className}
      animate={shake ? { x: [0, -10, 10, -10, 10, 0] } : {}}
      transition={{ duration: 0.5 }}
      onAnimationComplete={onComplete}
    >
      {children}
    </motion.div>
  );
};