import { FC } from 'react';
import { motion } from 'framer-motion';
import { Pet } from '@/App';

interface PetAvatarProps {
  pet: Pet;
  size?: 'small' | 'medium' | 'large' | 'xlarge';
  animated?: boolean;
  className?: string;
  onClick?: () => void;
}

const PetAvatar: FC<PetAvatarProps> = ({ 
  pet, 
  size = 'medium',
  animated = true,
  className = '',
  onClick
}) => {
  const sizeMap = {
    small: 'h-12 w-12 text-base',
    medium: 'h-16 w-16 text-xl',
    large: 'h-24 w-24 text-2xl',
    xlarge: 'h-32 w-32 text-3xl'
  };

  // Background color based on pet type
  const getBgColor = () => {
    if (pet.type === 'dog') {
      return 'bg-blue-500 dark:bg-blue-600';
    }
    if (pet.type === 'cat') {
      return 'bg-amber-500 dark:bg-amber-600';
    }
    return 'bg-primary';
  };

  // Define animations
  const hoverAnimation = animated ? {
    scale: 1.05,
    boxShadow: '0px 5px 15px rgba(0, 0, 0, 0.1)'
  } : {};

  const tapAnimation = animated ? {
    scale: 0.95
  } : {};

  // Set border style for different levels
  const getBorderStyle = () => {
    if (!pet.trainingLevel) return '';
    
    switch(pet.trainingLevel.toLowerCase()) {
      case 'beginner':
        return 'border-2 border-green-400';
      case 'intermediate':
        return 'border-2 border-blue-400';
      case 'advanced':
        return 'border-2 border-purple-400';
      default:
        return '';
    }
  };

  return (
    <motion.div
      className={`${sizeMap[size]} ${getBgColor()} ${getBorderStyle()} rounded-full flex items-center justify-center text-white overflow-hidden ${className} ${onClick ? 'cursor-pointer' : ''}`}
      whileHover={hoverAnimation}
      whileTap={tapAnimation}
      transition={{ type: 'spring', stiffness: 300, damping: 15 }}
      onClick={onClick}
    >
      {pet.imageUrl ? (
        <img 
          src={pet.imageUrl} 
          alt={`${pet.name}'s profile`}
          className="w-full h-full object-cover" 
        />
      ) : (
        <span className="font-bold">{pet.name.charAt(0).toUpperCase()}</span>
      )}
    </motion.div>
  );
};

export default PetAvatar;