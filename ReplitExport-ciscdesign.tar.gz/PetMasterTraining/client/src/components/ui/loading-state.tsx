import { FC } from 'react';
import { motion } from 'framer-motion';

interface LoadingStateProps {
  text?: string;
  fullScreen?: boolean;
  size?: 'small' | 'medium' | 'large';
}

const LoadingState: FC<LoadingStateProps> = ({ 
  text = 'Loading...', 
  fullScreen = false, 
  size = 'medium'
}) => {
  const sizeMap = {
    small: 'h-4 w-4',
    medium: 'h-8 w-8',
    large: 'h-12 w-12'
  };

  const containerClasses = fullScreen 
    ? 'fixed inset-0 flex items-center justify-center bg-white bg-opacity-90 z-50' 
    : 'flex flex-col items-center justify-center p-6';

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const loadingDot = {
    hidden: { y: 0, opacity: 0 },
    show: {
      y: [0, -15, 0],
      opacity: 1,
      transition: {
        y: {
          repeat: Infinity,
          duration: 0.6,
        }
      }
    }
  };

  return (
    <div className={containerClasses}>
      <motion.div
        className="flex flex-col items-center"
        variants={container}
        initial="hidden"
        animate="show"
      >
        <div className="flex space-x-2 mb-3">
          {[0, 1, 2].map((dot) => (
            <motion.div
              key={dot}
              className={`rounded-full bg-primary ${sizeMap[size]}`}
              variants={loadingDot}
              style={{ 
                animationDelay: `${dot * 0.1}s`
              }}
            />
          ))}
        </div>
        
        {text && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="text-gray-600 font-medium"
          >
            {text}
          </motion.div>
        )}
      </motion.div>
    </div>
  );
};

export default LoadingState;