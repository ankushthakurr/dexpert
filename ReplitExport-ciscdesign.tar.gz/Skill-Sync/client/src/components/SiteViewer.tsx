import { WebsiteContent } from "@shared/schema";
import { Helmet } from "react-helmet-async";
import { Button } from "@/components/ui/button";
import { Check, Star, Mail, MapPin, Phone, ArrowRight, Menu, X } from "lucide-react";
import { useState } from "react";
import { motion } from "framer-motion";

// Helper to get icon component dynamically (simplified for this demo)
const IconMap: Record<string, any> = {
  check: Check,
  star: Star,
  arrow: ArrowRight,
  default: Star
};

export function SiteViewer({ content, siteName }: { content: WebsiteContent; siteName: string }) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const theme = content.theme;

  // Dynamic style injection based on AI theme selection
  const themeStyles = {
    fontFamily: theme.fontFamily === 'serif' ? 'serif' : 'sans-serif',
    '--site-primary': theme.primaryColor || '#4F46E5',
  } as React.CSSProperties;

  return (
    <div style={themeStyles} className="font-sans text-slate-800 bg-white">
      <Helmet>
        <title>{siteName} | {content.hero.headline}</title>
        <meta name="description" content={content.hero.subheadline} />
      </Helmet>

      {/* Generated Site Navigation */}
      <nav className="sticky top-0 z-30 bg-white/90 backdrop-blur shadow-sm border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="font-bold text-xl" style={{ color: 'var(--site-primary)' }}>
              {siteName}
            </div>
            
            {/* Desktop Menu */}
            <div className="hidden md:flex gap-8 items-center">
              <a href="#about" className="hover:text-[var(--site-primary)] transition-colors">About</a>
              <a href="#services" className="hover:text-[var(--site-primary)] transition-colors">Services</a>
              <a href="#features" className="hover:text-[var(--site-primary)] transition-colors">Features</a>
              <a href="#faq" className="hover:text-[var(--site-primary)] transition-colors">FAQ</a>
              <Button style={{ backgroundColor: 'var(--site-primary)' }}>Contact Us</Button>
            </div>

            {/* Mobile Menu Toggle */}
            <div className="md:hidden">
              <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
                {mobileMenuOpen ? <X /> : <Menu />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-white border-b border-gray-100 p-4 space-y-4">
             <a href="#about" className="block p-2 hover:bg-gray-50 rounded">About</a>
             <a href="#services" className="block p-2 hover:bg-gray-50 rounded">Services</a>
             <a href="#features" className="block p-2 hover:bg-gray-50 rounded">Features</a>
             <Button className="w-full" style={{ backgroundColor: 'var(--site-primary)' }}>Contact Us</Button>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="relative py-20 lg:py-32 overflow-hidden">
        <div className="absolute inset-0 bg-slate-50 -z-10"></div>
        {/* Placeholder for optional background image */}
        {content.hero.backgroundImage && (
           <div className="absolute inset-0 opacity-10 bg-cover bg-center -z-10" style={{ backgroundImage: `url(${content.hero.backgroundImage})` }}></div>
        )}
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-6xl font-bold tracking-tight text-slate-900 mb-6"
          >
            {content.hero.headline}
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl text-slate-600 mb-10 max-w-2xl mx-auto"
          >
            {content.hero.subheadline}
          </motion.p>
          <motion.div
             initial={{ opacity: 0, y: 20 }}
             animate={{ opacity: 1, y: 0 }}
             transition={{ delay: 0.2 }}
          >
            <Button size="lg" className="rounded-full px-8 text-lg" style={{ backgroundColor: 'var(--site-primary)' }}>
              {content.hero.cta}
            </Button>
          </motion.div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-6">{content.about.title}</h2>
              <div className="prose prose-slate text-lg text-slate-600 leading-relaxed">
                {content.about.content}
              </div>
            </div>
            <div className="relative">
              {/* Using a placeholder if no specific image provided from AI */}
              {/* Unsplash abstract tech image */}
              <img 
                src="https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&q=80&w=800" 
                alt="About us" 
                className="rounded-2xl shadow-2xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold">{content.services[0]?.title || "Our Services"}</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {content.services[0]?.items.map((item, i) => (
              <motion.div 
                key={i}
                whileHover={{ y: -5 }}
                className="bg-white p-8 rounded-xl shadow-lg border border-slate-100"
              >
                <div className="w-12 h-12 rounded-lg bg-blue-50 flex items-center justify-center mb-6" style={{ color: 'var(--site-primary)' }}>
                  <Star className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold mb-3">{item.title}</h3>
                <p className="text-slate-600">{item.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
           <div className="grid md:grid-cols-2 gap-x-12 gap-y-16">
             {content.features.map((feature, i) => (
               <div key={i} className="flex gap-4">
                 <div className="flex-shrink-0 mt-1">
                   <div className="w-6 h-6 rounded-full flex items-center justify-center text-white" style={{ backgroundColor: 'var(--site-primary)' }}>
                     <Check className="w-4 h-4" />
                   </div>
                 </div>
                 <div>
                   <h3 className="text-lg font-bold mb-2">{feature.title}</h3>
                   <p className="text-slate-600">{feature.description}</p>
                 </div>
               </div>
             ))}
           </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-slate-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-16">What People Say</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {content.testimonials.map((t, i) => (
              <div key={i} className="bg-slate-800 p-8 rounded-xl border border-slate-700">
                <p className="text-slate-300 italic mb-6">"{t.quote}"</p>
                <div>
                  <div className="font-bold">{t.name}</div>
                  <div className="text-sm text-slate-400">{t.role}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-white text-center">
        <div className="max-w-4xl mx-auto px-4">
          <h2 className="text-4xl font-bold mb-6">{content.ctaSection.title}</h2>
          <p className="text-xl text-slate-600 mb-10">{content.ctaSection.subtitle}</p>
          <Button size="lg" className="rounded-full px-12 text-lg h-14" style={{ backgroundColor: 'var(--site-primary)' }}>
            {content.ctaSection.buttonText}
          </Button>
        </div>
      </section>

      {/* Site Footer */}
      <footer className="bg-slate-50 py-12 border-t border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-slate-500 text-sm">
          <div className="flex justify-center gap-8 mb-8">
            <span className="flex items-center gap-2"><MapPin className="w-4 h-4"/> Location</span>
            <span className="flex items-center gap-2"><Phone className="w-4 h-4"/> Call Us</span>
            <span className="flex items-center gap-2"><Mail className="w-4 h-4"/> Email Us</span>
          </div>
          <p>© {new Date().getFullYear()} {siteName}. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
