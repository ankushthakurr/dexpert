import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { HelmetProvider } from "react-helmet-async";
import { Layout } from "@/components/Layout";
import NotFound from "@/pages/not-found";

// Page Imports
import Home from "@/pages/Home";
import Generator from "@/pages/Generator";
import SiteViewerPage from "@/pages/SiteViewerPage";
import Features from "@/pages/Features";
import Pricing from "@/pages/Pricing";
import Examples from "@/pages/Examples";
import About from "@/pages/About";
import Contact from "@/pages/Contact";
import Privacy from "@/pages/Privacy";
import Terms from "@/pages/Terms";

function Router() {
  return (
    <Switch>
      {/* Platform Pages - Wrapped in Main Layout */}
      <Route path="/" component={() => <Layout><Home /></Layout>} />
      <Route path="/generator" component={() => <Layout><Generator /></Layout>} />
      <Route path="/features" component={() => <Layout><Features /></Layout>} />
      <Route path="/pricing" component={() => <Layout><Pricing /></Layout>} />
      <Route path="/examples" component={() => <Layout><Examples /></Layout>} />
      <Route path="/about" component={() => <Layout><About /></Layout>} />
      <Route path="/contact" component={() => <Layout><Contact /></Layout>} />
      <Route path="/privacy" component={() => <Layout><Privacy /></Layout>} />
      <Route path="/terms" component={() => <Layout><Terms /></Layout>} />

      {/* Generated Site Viewer - Uses its own internal layout logic inside Layout wrapper */}
      <Route path="/site/:slug" component={() => <Layout><SiteViewerPage /></Layout>} />

      {/* 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <HelmetProvider>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </QueryClientProvider>
    </HelmetProvider>
  );
}

export default App;
