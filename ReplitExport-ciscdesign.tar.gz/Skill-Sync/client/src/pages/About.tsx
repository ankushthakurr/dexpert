import { Card } from "@/components/ui/card";
import { Rocket, Heart, Users } from "lucide-react";

export default function About() {
  return (
    <div className="py-20 bg-white min-h-screen">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-4xl font-display font-bold mb-8 text-center">About Us</h1>
        
        <div className="prose prose-lg mx-auto text-slate-600 mb-16">
          <p className="lead text-xl mb-6">
            LetsGenrateWithAI is on a mission to democratize web design. We believe that every business, no matter how small, deserves a world-class online presence.
          </p>
          <p>
            Founded by Pankaj Thakur in Las Vegas, we combined cutting-edge artificial intelligence with professional design principles to create a tool that builds websites in seconds, not weeks.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-16">
          <Card className="p-6 text-center border-none shadow-lg bg-slate-50">
            <Rocket className="w-10 h-10 text-primary mx-auto mb-4" />
            <h3 className="font-bold mb-2">Innovation</h3>
            <p className="text-sm text-slate-500">Pushing the boundaries of what AI can create.</p>
          </Card>
          <Card className="p-6 text-center border-none shadow-lg bg-slate-50">
            <Heart className="w-10 h-10 text-primary mx-auto mb-4" />
            <h3 className="font-bold mb-2">Simplicity</h3>
            <p className="text-sm text-slate-500">Making complex tech accessible to everyone.</p>
          </Card>
          <Card className="p-6 text-center border-none shadow-lg bg-slate-50">
            <Users className="w-10 h-10 text-primary mx-auto mb-4" />
            <h3 className="font-bold mb-2">Community</h3>
            <p className="text-sm text-slate-500">Supporting thousands of creators worldwide.</p>
          </Card>
        </div>

        <div className="bg-primary/5 rounded-2xl p-8 text-center">
          <h2 className="text-2xl font-bold mb-4">Contact Us</h2>
          <div className="text-slate-600 space-y-2">
             <p><strong>Owner:</strong> Pankaj Thakur</p>
             <p><strong>Address:</strong> 304 Navada, Las Vegas 801709</p>
             <p><strong>Email:</strong> info@letsgenratewidai.com</p>
             <p><strong>Phone:</strong> 9873763204</p>
          </div>
        </div>
      </div>
    </div>
  );
}
