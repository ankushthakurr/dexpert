import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { api } from "@shared/routes";
import { z } from "zod";
import { useGenerateSite } from "@/hooks/use-sites";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card } from "@/components/ui/card";
import { Loader2, Wand2, ArrowRight } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

// Schema for the form
const formSchema = api.sites.generate.input;

export default function Generator() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const generateMutation = useGenerateSite();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      siteName: "",
      businessType: "",
      description: "",
      contactInfo: {
        ownerName: "",
        phone: "",
        email: "",
        address: "",
      },
    },
  });

  const onSubmit = (data: z.infer<typeof formSchema>) => {
    generateMutation.mutate(data, {
      onSuccess: (res) => {
        toast({
          title: "Website Generated!",
          description: "Redirecting you to your new site...",
        });
        // Small delay to show success state
        setTimeout(() => {
          setLocation(`/site/${res.slug}`);
        }, 1000);
      },
      onError: (error) => {
        toast({
          title: "Generation Failed",
          description: error.message,
          variant: "destructive",
        });
      },
    });
  };

  const isPending = generateMutation.isPending;

  return (
    <div className="min-h-[calc(100vh-80px)] bg-slate-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-10">
          <h1 className="text-4xl font-display font-bold text-slate-900 mb-4">Create Your Website</h1>
          <p className="text-slate-600">
            Tell us about your business, and our AI will build a complete website in seconds.
          </p>
        </div>

        <Card className="p-6 md:p-8 shadow-xl border-slate-200/60 bg-white/80 backdrop-blur-sm">
          {isPending ? (
            <div className="py-20 text-center">
              <motion.div 
                animate={{ rotate: 360 }}
                transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full mx-auto mb-8"
              />
              <h3 className="text-2xl font-bold text-slate-900 mb-2">Generating Your Website...</h3>
              <p className="text-slate-500 max-w-sm mx-auto">
                Our AI is writing content, selecting images, and structuring your layout. This usually takes about 30 seconds.
              </p>
              
              <div className="mt-8 space-y-2 max-w-xs mx-auto text-sm text-slate-400">
                 <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1 }}>Analyzing business type...</motion.div>
                 <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 3 }}>Drafting hero copy...</motion.div>
                 <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 5 }}>Designing layout...</motion.div>
              </div>
            </div>
          ) : (
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="siteName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Website Name</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g. Acme Consulting" {...field} className="h-12" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="businessType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Business Type</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g. Digital Agency, Bakery" {...field} className="h-12" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Business Description</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Describe your services, target audience, and key selling points..." 
                          className="min-h-[120px] resize-none p-4"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="pt-4 border-t border-slate-100">
                  <h3 className="text-lg font-medium mb-4 text-slate-900">Contact Information</h3>
                  <div className="grid md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="contactInfo.ownerName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Owner Name</FormLabel>
                          <FormControl>
                            <Input placeholder="John Doe" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="contactInfo.phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Phone</FormLabel>
                          <FormControl>
                            <Input placeholder="+1 (555) 000-0000" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="contactInfo.email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input placeholder="hello@company.com" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="contactInfo.address"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Address</FormLabel>
                          <FormControl>
                            <Input placeholder="123 Main St, City" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>

                <Button 
                  type="submit" 
                  disabled={isPending}
                  className="w-full h-14 text-lg font-semibold rounded-xl bg-gradient-to-r from-primary to-purple-600 hover:opacity-90 transition-opacity"
                >
                  <Wand2 className="mr-2 w-5 h-5" />
                  Generate Website
                </Button>
              </form>
            </Form>
          )}
        </Card>
      </div>
    </div>
  );
}
