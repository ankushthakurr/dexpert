import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowRight, Wand2, Zap, Layout as LayoutIcon, Globe, Shield } from "lucide-react";
import { motion } from "framer-motion";

export default function Home() {
  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <section className="relative pt-20 pb-32 overflow-hidden">
        {/* Abstract Background Shapes */}
        <div className="absolute top-0 left-0 w-full h-full overflow-hidden -z-10">
          <div className="absolute top-[-10%] right-[-5%] w-[500px] h-[500px] bg-primary/20 rounded-full blur-3xl animate-float"></div>
          <div className="absolute bottom-[-10%] left-[-10%] w-[600px] h-[600px] bg-purple-500/20 rounded-full blur-3xl animate-float" style={{ animationDelay: "2s" }}></div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/50 backdrop-blur border border-primary/20 text-primary text-sm font-medium mb-8 shadow-sm">
              <span className="flex h-2 w-2 rounded-full bg-primary animate-pulse"></span>
              AI Website Builder V2.0 is Live
            </div>
            
            <h1 className="text-5xl md:text-7xl font-display font-bold tracking-tight text-slate-900 mb-6 leading-[1.1]">
              Build your website in <br/>
              <span className="text-gradient">seconds with AI</span>
            </h1>
            
            <p className="text-xl md:text-2xl text-slate-600 mb-10 max-w-3xl mx-auto leading-relaxed">
              No coding required. Just describe your business, and our advanced AI will generate a stunning, fully-functional website for you instantly.
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link href="/generator">
                <Button size="lg" className="h-14 px-8 rounded-full text-lg shadow-xl shadow-primary/25 hover:shadow-primary/40 hover:-translate-y-1 transition-all">
                  Start Generating <Wand2 className="ml-2 w-5 h-5" />
                </Button>
              </Link>
              <Link href="/examples">
                <Button size="lg" variant="outline" className="h-14 px-8 rounded-full text-lg bg-white/50 backdrop-blur border-slate-300 hover:bg-white">
                  View Examples
                </Button>
              </Link>
            </div>
          </motion.div>

          {/* Platform Preview */}
          <motion.div 
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 0.8 }}
            className="mt-20 relative mx-auto max-w-5xl"
          >
            <div className="rounded-xl bg-slate-900/5 p-2 ring-1 ring-inset ring-slate-900/10 lg:rounded-2xl lg:p-4">
              <img 
                src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=2426" 
                alt="App Interface" 
                className="rounded-lg shadow-2xl ring-1 ring-slate-900/10"
              />
            </div>
            {/* Decorative floating cards */}
            <div className="absolute -right-12 top-1/3 glass-card p-4 rounded-xl hidden lg:block animate-float" style={{ animationDelay: '1s' }}>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center text-green-600">
                  <Zap className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-sm font-bold">Fast Generation</div>
                  <div className="text-xs text-slate-500">Under 60 seconds</div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-24 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-display font-bold mb-4">Everything you need to succeed</h2>
            <p className="text-slate-600 max-w-2xl mx-auto">
              We don't just generate text. We build structure, layout, and style tailored to your brand identity.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: Wand2,
                title: "AI-Powered Generation",
                description: "Our advanced algorithms understand your business context and write compelling copy."
              },
              {
                icon: LayoutIcon,
                title: "Responsive Layouts",
                description: "Every site is mobile-first and looks perfect on tablets and desktops automatically."
              },
              {
                icon: Globe,
                title: "SEO Optimized",
                description: "Generated with proper meta tags, hierarchy, and performance best practices built-in."
              },
              {
                icon: Shield,
                title: "Secure Hosting",
                description: "Your site is served via secure global CDNs for maximum speed and reliability."
              },
              {
                icon: Zap,
                title: "Instant Launch",
                description: "Go from idea to live URL in under a minute. No deployment headaches."
              },
              {
                icon: ArrowRight,
                title: "Easy Customization",
                description: "Don't like a section? Regenerate it or tweak the content instantly."
              }
            ].map((feature, i) => (
              <motion.div 
                key={i}
                whileHover={{ y: -5 }}
                className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100 hover:shadow-lg transition-all"
              >
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center text-primary mb-6">
                  <feature.icon className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold mb-3 font-display">{feature.title}</h3>
                <p className="text-slate-600 leading-relaxed">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-primary rounded-3xl p-12 md:p-20 text-center text-white relative overflow-hidden">
            {/* Background pattern */}
            <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)', backgroundSize: '32px 32px' }}></div>
            
            <h2 className="text-4xl md:text-5xl font-display font-bold mb-6 relative z-10">Ready to launch your website?</h2>
            <p className="text-primary-foreground/80 text-xl mb-10 max-w-2xl mx-auto relative z-10">
              Join thousands of business owners who launched their online presence with LetsGenrateWithAI.
            </p>
            <Link href="/generator">
              <Button size="lg" variant="secondary" className="h-14 px-10 rounded-full text-primary font-bold text-lg hover:bg-white relative z-10">
                Create My Website
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
