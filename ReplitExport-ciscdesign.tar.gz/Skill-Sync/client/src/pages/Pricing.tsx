import { Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Link } from "wouter";

export default function Pricing() {
  const plans = [
    {
      name: "Starter",
      price: "Free",
      description: "Perfect for testing ideas",
      features: [
        "1 AI Generated Website",
        "Standard Hosting",
        "Subdomain (site.letsgenrate.com)",
        "Basic SEO",
        "Community Support"
      ],
      cta: "Start for Free",
      popular: false
    },
    {
      name: "Pro",
      price: "$19",
      period: "/month",
      description: "For serious businesses",
      features: [
        "Unlimited Generations",
        "Premium Hosting (CDN)",
        "Custom Domain Connection",
        "Advanced SEO Tools",
        "Remove Watermark",
        "Priority Support"
      ],
      cta: "Get Pro",
      popular: true
    },
    {
      name: "Agency",
      price: "$49",
      period: "/month",
      description: "For web designers",
      features: [
        "10+ Client Sites",
        "White Label Dashboard",
        "Export Code (React/HTML)",
        "API Access",
        "Team Collaboration",
        "24/7 Dedicated Support"
      ],
      cta: "Contact Sales",
      popular: false
    }
  ];

  return (
    <div className="py-24 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-display font-bold mb-4">Simple, Transparent Pricing</h1>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto">
            Start for free, upgrade when you're ready to launch your business to the world.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan, i) => (
            <Card 
              key={i} 
              className={`p-8 relative ${plan.popular ? 'border-primary shadow-xl scale-105 z-10' : 'border-slate-200'}`}
            >
              {plan.popular && (
                <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-primary text-white text-sm font-bold px-4 py-1 rounded-full">
                  Most Popular
                </div>
              )}
              
              <div className="text-center mb-8">
                <h3 className="text-lg font-bold text-slate-900 mb-2">{plan.name}</h3>
                <div className="flex items-end justify-center gap-1 mb-2">
                  <span className="text-4xl font-bold text-slate-900">{plan.price}</span>
                  {plan.period && <span className="text-slate-500 mb-1">{plan.period}</span>}
                </div>
                <p className="text-slate-500 text-sm">{plan.description}</p>
              </div>

              <ul className="space-y-4 mb-8">
                {plan.features.map((feature, idx) => (
                  <li key={idx} className="flex items-center gap-3 text-sm text-slate-700">
                    <Check className="w-5 h-5 text-primary shrink-0" />
                    {feature}
                  </li>
                ))}
              </ul>

              <Link href="/generator">
                <Button 
                  className="w-full h-12 rounded-xl" 
                  variant={plan.popular ? "default" : "outline"}
                >
                  {plan.cta}
                </Button>
              </Link>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
