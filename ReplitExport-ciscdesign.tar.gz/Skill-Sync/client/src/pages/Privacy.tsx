export default function Privacy() {
  return (
    <div className="py-20 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 prose prose-slate">
      <h1>Privacy Policy</h1>
      <p>Last updated: {new Date().toLocaleDateString()}</p>
      
      <h3>1. Introduction</h3>
      <p>Welcome to letsgenratewithai.com. We respect your privacy and are committed to protecting your personal data.</p>

      <h3>2. Data We Collect</h3>
      <p>When you use our AI generator, we collect the business information you provide (name, email, business details) solely for the purpose of generating your website.</p>

      <h3>3. How We Use Data</h3>
      <p>We use your data to:</p>
      <ul>
        <li>Generate website content using AI models</li>
        <li>Create your user account</li>
        <li>Send you important updates about your service</li>
      </ul>

      <h3>4. AI Processing</h3>
      <p>Your input data is processed by our AI algorithms to generate content. We do not use your personal data to train public AI models without your consent.</p>
      
      <h3>5. Contact Us</h3>
      <p>For privacy concerns, contact us at info@letsgenratewidai.com</p>
    </div>
  );
}
