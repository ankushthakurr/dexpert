import { useSites } from "@/hooks/use-sites";
import { Card } from "@/components/ui/card";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Loader2, ExternalLink } from "lucide-react";

export default function Examples() {
  const { data: sites, isLoading } = useSites();

  return (
    <div className="py-20 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-display font-bold mb-4">Example Websites</h1>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto">
            Check out what others have built using our AI website generator.
          </p>
        </div>

        {isLoading ? (
          <div className="flex justify-center">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : (
          <div className="grid md:grid-cols-3 gap-8">
            {sites?.map((site) => (
              <Card key={site.id} className="overflow-hidden hover:shadow-xl transition-shadow border-slate-200">
                {/* Mock Browser Header */}
                <div className="bg-slate-100 border-b border-slate-200 p-2 flex gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-red-400"></div>
                  <div className="w-2.5 h-2.5 rounded-full bg-yellow-400"></div>
                  <div className="w-2.5 h-2.5 rounded-full bg-green-400"></div>
                </div>
                
                {/* Preview Thumbnail (Using a generic placeholder if no screenshot service) */}
                <div className="aspect-video bg-slate-200 relative group">
                  <div className="absolute inset-0 flex items-center justify-center bg-white/90 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity">
                    <Link href={`/site/${site.slug}`}>
                      <Button>View Website <ExternalLink className="ml-2 w-4 h-4"/></Button>
                    </Link>
                  </div>
                  {/* Abstract preview content */}
                  <div className="p-8 flex flex-col items-center justify-center h-full text-center">
                    <h3 className="text-2xl font-bold text-slate-800 mb-2">{site.siteName}</h3>
                    <span className="text-sm text-slate-500 bg-white px-3 py-1 rounded-full border border-slate-200">
                      {site.businessType}
                    </span>
                  </div>
                </div>
                
                <div className="p-4 bg-white">
                  <div className="flex justify-between items-center">
                    <h3 className="font-bold truncate">{site.siteName}</h3>
                    <span className="text-xs text-slate-500">
                      {new Date(site.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                </div>
              </Card>
            ))}

            {/* Empty state if no sites */}
            {sites?.length === 0 && (
              <div className="col-span-full text-center py-20 text-slate-500">
                No examples yet. Be the first to create one!
                <div className="mt-4">
                  <Link href="/generator">
                    <Button>Create Website</Button>
                  </Link>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
