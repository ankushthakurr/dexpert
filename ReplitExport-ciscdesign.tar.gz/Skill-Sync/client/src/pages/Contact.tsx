import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { MapPin, Mail, Phone } from "lucide-react";

export default function Contact() {
  return (
    <div className="py-20 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 gap-12 bg-white rounded-2xl shadow-xl overflow-hidden">
          
          {/* Contact Info */}
          <div className="bg-primary p-12 text-white">
            <h1 className="text-3xl font-bold mb-6">Get in Touch</h1>
            <p className="text-primary-foreground/80 mb-12 text-lg">
              Have questions about our AI builder? Need help with your website? Our team is here to assist you.
            </p>

            <div className="space-y-8">
              <div className="flex items-start gap-4">
                <MapPin className="w-6 h-6 shrink-0 opacity-80" />
                <div>
                  <h3 className="font-semibold mb-1">Visit Us</h3>
                  <p className="text-primary-foreground/80">304 Navada, Las Vegas 801709</p>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <Mail className="w-6 h-6 shrink-0 opacity-80" />
                <div>
                  <h3 className="font-semibold mb-1">Email Us</h3>
                  <p className="text-primary-foreground/80">info@letsgenratewidai.com</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <Phone className="w-6 h-6 shrink-0 opacity-80" />
                <div>
                  <h3 className="font-semibold mb-1">Call Us</h3>
                  <p className="text-primary-foreground/80">9873763204</p>
                </div>
              </div>
            </div>

            <div className="mt-12 pt-12 border-t border-white/20">
              <p className="text-sm opacity-60">Owner: Pankaj Thakur</p>
            </div>
          </div>

          {/* Contact Form */}
          <div className="p-12">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">Send us a Message</h2>
            <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-700">First Name</label>
                  <Input placeholder="John" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-700">Last Name</label>
                  <Input placeholder="Doe" />
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">Email</label>
                <Input placeholder="john@example.com" type="email" />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">Message</label>
                <Textarea placeholder="How can we help you?" className="min-h-[150px]" />
              </div>

              <Button className="w-full h-12 text-lg">Send Message</Button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
