import { useRoute } from "wouter";
import { useSite } from "@/hooks/use-sites";
import { SiteViewer } from "@/components/SiteViewer";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function SiteViewerPage() {
  const [, params] = useRoute("/site/:slug");
  const slug = params?.slug || "";
  const { data: site, isLoading, error } = useSite(slug);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <Loader2 className="w-12 h-12 text-primary animate-spin" />
      </div>
    );
  }

  if (error || !site) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-slate-50 text-center px-4">
        <h1 className="text-3xl font-bold text-slate-900 mb-4">Site Not Found</h1>
        <p className="text-slate-600 mb-8">The website you are looking for doesn't exist or has been removed.</p>
        <Link href="/">
          <Button>Return Home</Button>
        </Link>
      </div>
    );
  }

  return <SiteViewer content={site.content} siteName={site.siteName} />;
}
