import { Layout } from "@/components/Layout";
import { Card } from "@/components/ui/card";
import { 
  Bot, Layout as LayoutIcon, Image, Type, 
  Smartphone, Search, Globe, Code2 
} from "lucide-react";

export default function Features() {
  const features = [
    {
      icon: Bot,
      title: "AI Copywriting",
      description: "Our AI generates professional, engaging content tailored to your specific industry and audience."
    },
    {
      icon: LayoutIcon,
      title: "Smart Layouts",
      description: "Automatically structured pages that follow UX best practices for maximum conversion."
    },
    {
      icon: Image,
      title: "Stock Image Selection",
      description: "We automatically select relevant, high-quality stock photography to match your brand."
    },
    {
      icon: Type,
      title: "Typography Pairs",
      description: "Beautiful font combinations pre-selected by designers for readability and style."
    },
    {
      icon: Smartphone,
      title: "Mobile Responsive",
      description: "All websites are fully responsive and look great on phones, tablets, and desktops."
    },
    {
      icon: Search,
      title: "SEO Ready",
      description: "Built-in meta tags, semantic HTML, and fast loading speeds to help you rank."
    },
    {
      icon: Globe,
      title: "Custom Domain",
      description: "Connect your own domain name easily or use our free subdomain hosting."
    },
    {
      icon: Code2,
      title: "Clean Code",
      description: "Generated code is clean, semantic, and maintainable React/Tailwind code."
    }
  ];

  return (
    <div className="py-20 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-display font-bold mb-4">Powerful Features</h1>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto">
            Everything you need to build a professional online presence without writing a single line of code.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, i) => (
            <Card key={i} className="p-6 hover:shadow-lg transition-shadow border-slate-200">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center text-primary mb-4">
                <feature.icon className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold mb-2">{feature.title}</h3>
              <p className="text-slate-600 text-sm leading-relaxed">{feature.description}</p>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
