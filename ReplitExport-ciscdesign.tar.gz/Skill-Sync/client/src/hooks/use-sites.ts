import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { z } from "zod";

// Type definitions inferred from the API contract
type GenerateSiteInput = z.infer<typeof api.sites.generate.input>;
type GenerateSiteResponse = z.infer<typeof api.sites.generate.responses[200]>;
type SiteListResponse = z.infer<typeof api.sites.list.responses[200]>;
type SiteGetResponse = z.infer<typeof api.sites.get.responses[200]>;

// Hook to generate a new website
export function useGenerateSite() {
  return useMutation({
    mutationFn: async (data: GenerateSiteInput) => {
      // Input validation before sending
      const validatedData = api.sites.generate.input.parse(data);
      
      const res = await fetch(api.sites.generate.path, {
        method: api.sites.generate.method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(validatedData),
        credentials: "include",
      });

      if (!res.ok) {
        if (res.status === 500) {
           const error = api.sites.generate.responses[500].parse(await res.json());
           throw new Error(error.message);
        }
        throw new Error('Failed to generate site');
      }

      return api.sites.generate.responses[200].parse(await res.json());
    }
  });
}

// Hook to get a specific site by slug
export function useSite(slug: string) {
  return useQuery({
    queryKey: [api.sites.get.path, slug],
    queryFn: async () => {
      const url = buildUrl(api.sites.get.path, { slug });
      const res = await fetch(url, { credentials: "include" });
      
      if (res.status === 404) return null;
      if (!res.ok) throw new Error('Failed to fetch site');
      
      return api.sites.get.responses[200].parse(await res.json());
    },
    enabled: !!slug,
  });
}

// Hook to list all generated sites (for Examples page)
export function useSites() {
  return useQuery({
    queryKey: [api.sites.list.path],
    queryFn: async () => {
      const res = await fetch(api.sites.list.path, { credentials: "include" });
      if (!res.ok) throw new Error('Failed to list sites');
      return api.sites.list.responses[200].parse(await res.json());
    },
  });
}
