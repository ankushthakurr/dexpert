## Packages
framer-motion | Complex animations for the "generating" state and page transitions
react-helmet-async | SEO meta tags for the generated sites and main platform
clsx | Utility for conditional class names
tailwind-merge | Utility for merging tailwind classes

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
