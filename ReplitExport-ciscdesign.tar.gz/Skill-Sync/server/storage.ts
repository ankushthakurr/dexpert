import { db } from "./db";
import {
  generatedSites,
  type InsertGeneratedSite,
  type GeneratedSite
} from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  createSite(site: InsertGeneratedSite): Promise<GeneratedSite>;
  getSiteBySlug(slug: string): Promise<GeneratedSite | undefined>;
  getAllSites(): Promise<GeneratedSite[]>;
}

export class DatabaseStorage implements IStorage {
  async createSite(site: InsertGeneratedSite): Promise<GeneratedSite> {
    const [newSite] = await db
      .insert(generatedSites)
      .values(site)
      .returning();
    return newSite;
  }

  async getSiteBySlug(slug: string): Promise<GeneratedSite | undefined> {
    const [site] = await db
      .select()
      .from(generatedSites)
      .where(eq(generatedSites.slug, slug));
    return site;
  }

  async getAllSites(): Promise<GeneratedSite[]> {
    return db
      .select()
      .from(generatedSites)
      .orderBy(desc(generatedSites.id));
  }
}

export const storage = new DatabaseStorage();
