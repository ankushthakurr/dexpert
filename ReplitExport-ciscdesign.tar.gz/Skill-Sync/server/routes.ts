import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import OpenAI from "openai";
import { InsertGeneratedSite } from "@shared/schema";

// Initialize OpenAI client using Replit AI integration env vars
const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // --- API Routes ---

  app.post(api.sites.generate.path, async (req, res) => {
    try {
      const input = api.sites.generate.input.parse(req.body);

      // 1. Generate content using OpenAI
      const prompt = `
        You are a world-class web designer and copywriter.
        Generate a COMPLETE, PROFESSIONAL website structure for a client.
        
        Client Details:
        - Name: ${input.siteName}
        - Business Type: ${input.businessType}
        - Description: ${input.description}
        - Contact: ${JSON.stringify(input.contactInfo)}

        Return ONLY valid JSON matching this TypeScript interface:
        {
          hero: {
            headline: string;
            subheadline: string;
            cta: string;
            backgroundImage: string; // Describe a high-quality, professional image for this business
          };
          about: {
            title: string;
            content: string; // 2-3 paragraphs, persuasive
            image: string; // Image description
          };
          services: {
            title: string;
            items: Array<{ title: string; description: string; icon: string }>; // icon should be a valid Lucide icon name (e.g. 'Activity', 'Users', etc.)
          }[];
          testimonials: Array<{ name: string; quote: string; role: string }>;
          features: Array<{ title: string; description: string }>;
          faq: Array<{ question: string; answer: string }>;
          ctaSection: {
            title: string;
            subtitle: string;
            buttonText: string;
          };
          theme: {
            primaryColor: string; // Hex code, professional and fitting for the industry
            fontFamily: string;
            style: "modern" | "classic" | "playful" | "minimalist";
          };
        }

        Tone: Professional, persuasive, conversion-focused.
        Design: Ultra-modern, premium.
        NO robotic text. Make it sound handcrafted.
      `;

      const completion = await openai.chat.completions.create({
        model: "gpt-5.1",
        messages: [
          { role: "system", content: "You are a senior full-stack engineer and UI/UX designer." },
          { role: "user", content: prompt }
        ],
        response_format: { type: "json_object" }
      });

      const contentJson = completion.choices[0].message.content;
      if (!contentJson) throw new Error("Failed to generate content");
      
      const generatedContent = JSON.parse(contentJson);

      // 2. Save to DB
      const slug = input.siteName.toLowerCase().replace(/[^a-z0-9]+/g, '-') + '-' + Math.floor(Math.random() * 1000);
      
      const newSiteData: InsertGeneratedSite = {
        siteName: input.siteName,
        businessType: input.businessType,
        description: input.description,
        contactInfo: input.contactInfo,
        generatedContent: generatedContent,
        slug: slug,
        createdAt: new Date().toISOString()
      };

      const site = await storage.createSite(newSiteData);

      res.status(200).json({
        id: site.id,
        slug: site.slug,
        content: site.generatedContent
      });

    } catch (err) {
      console.error("Generation error:", err);
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      res.status(500).json({ message: "Failed to generate website" });
    }
  });

  app.get(api.sites.get.path, async (req, res) => {
    try {
      const site = await storage.getSiteBySlug(req.params.slug);
      if (!site) {
        return res.status(404).json({ message: "Site not found" });
      }
      res.json(site);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get(api.sites.list.path, async (req, res) => {
    try {
      const sites = await storage.getAllSites();
      res.json(sites);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  return httpServer;
}
