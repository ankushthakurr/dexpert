import { z } from 'zod';
import { insertGeneratedSiteSchema, generatedSites } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  sites: {
    generate: {
      method: 'POST' as const,
      path: '/api/generate',
      input: z.object({
        siteName: z.string().min(1, "Website Name is required"),
        businessType: z.string().min(1, "Business Type is required"),
        description: z.string().min(10, "Description must be at least 10 characters"),
        contactInfo: z.object({
          ownerName: z.string().min(1, "Owner Name is required"),
          phone: z.string().min(1, "Phone is required"),
          email: z.string().email("Invalid email"),
          address: z.string().min(1, "Address is required"),
        }),
      }),
      responses: {
        200: z.object({
          id: z.number(),
          slug: z.string(),
          content: z.custom<any>(), // WebsiteContent
        }),
        500: errorSchemas.internal,
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/sites/:slug',
      responses: {
        200: z.custom<typeof generatedSites.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    list: {
      method: 'GET' as const,
      path: '/api/sites',
      responses: {
        200: z.array(z.custom<typeof generatedSites.$inferSelect>()),
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
