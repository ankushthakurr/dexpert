import { pgTable, text, serial, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const generatedSites = pgTable("generated_sites", {
  id: serial("id").primaryKey(),
  siteName: text("site_name").notNull(),
  businessType: text("business_type").notNull(),
  description: text("description").notNull(),
  contactInfo: jsonb("contact_info").notNull(), // { address, phone, email, ownerName }
  generatedContent: jsonb("generated_content").notNull(), // The full JSON structure of the generated site
  slug: text("slug").notNull().unique(), // unique URL identifier
  createdAt: text("created_at").notNull(), // ISO string
});

export const insertGeneratedSiteSchema = createInsertSchema(generatedSites).omit({ 
  id: true,
  createdAt: true 
});

export type InsertGeneratedSite = z.infer<typeof insertGeneratedSiteSchema>;
export type GeneratedSite = typeof generatedSites.$inferSelect;

// Types for the AI generation prompt/response
export interface WebsiteGenerationRequest {
  siteName: string;
  businessType: string;
  description: string;
  contactInfo: {
    ownerName: string;
    phone: string;
    email: string;
    address: string;
  };
}

export interface WebsiteContent {
  hero: {
    headline: string;
    subheadline: string;
    cta: string;
    backgroundImage: string; // url or description for image gen
  };
  about: {
    title: string;
    content: string;
    image: string;
  };
  services: {
    title: string;
    items: Array<{ title: string; description: string; icon: string }>;
  }[];
  testimonials: Array<{ name: string; quote: string; role: string }>;
  features: Array<{ title: string; description: string }>;
  faq: Array<{ question: string; answer: string }>;
  ctaSection: {
    title: string;
    subtitle: string;
    buttonText: string;
  };
  theme: {
    primaryColor: string;
    fontFamily: string;
    style: "modern" | "classic" | "playful" | "minimalist";
  };
}
